export type RelationInfo = {
    id: number;
    name: string;
    symbol: string;
    rows: number;
    cols: number;
}

type RelationPair = {
    relationId: number;
    source: string;
    target: string;
}

export type Relation = {
    relationInfo: RelationInfo;
    // source: string[];
    // target: string[];
    // properties: any;
    // relationPairs: RelationPair[];
}

export type FCAResponse = {
    latticeImage: Blob;
    xml: string;
}

export type EditCommand = {
    relationId: number;
    name?: string;
    symbol: string;
}


export type RelationCommand = {
    name?: string;
    symbol: string;
    sourceData: string;
    targetData: string;
    generateRelation: boolean;
    density?: number;
    relationData?: string;
}

export type CalculationCommand = {
    calculation: string;
}

export type CalculationResponse = {
    resultSymbol?: string;
    booleanResult?: boolean;
}