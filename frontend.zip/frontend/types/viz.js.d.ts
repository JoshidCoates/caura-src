declare module 'viz.js' {
    var Viz: any;
    export = Viz;
}