declare module 'viz.js/full.render.js' {
    var render: any;
    var Module: any;
    export {render,Module};
}