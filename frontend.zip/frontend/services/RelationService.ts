import axios from 'axios';
import {Relation, RelationCommand, CalculationCommand, EditCommand, FCAResponse} from "../types/RelationTypes";
import editRelation from "../components/EditRelation";

const RELATION_API_BASE_URL = 'http://localhost:8080/api/v1/relation';

class RelationService {
    // getRelation(id: number) {
    //     return axios.get(RELATION_API_BASE_URL + '/' + id);
    // }

    resetRelations() {
        return axios.post(RELATION_API_BASE_URL + '/reset');
    }

    setRelationType(relationType: string) {
        return axios.post(RELATION_API_BASE_URL + '/relation-type?relationType=' + relationType);
    }

    getAllRelations() {
        return axios.get(RELATION_API_BASE_URL);
    }

    deleteRelation(relationId: number) {
        return axios.delete(RELATION_API_BASE_URL + '/' + relationId);
    }

    editRelation(editCommand: EditCommand) {
        return axios.patch(RELATION_API_BASE_URL, editCommand);
    }

    getImage(relationId: number) {
        return axios.get(RELATION_API_BASE_URL + '/img/' + relationId, {responseType: 'blob'});
    }

    getDownloadTxt(relationId: number) {
        return axios.get(RELATION_API_BASE_URL + '/txt/' + relationId);
    }

    saveRelation(relationCommand: RelationCommand) {
        return axios.post(RELATION_API_BASE_URL, relationCommand);
    }

    performFCA(relationId: number) {
        return axios.get(RELATION_API_BASE_URL + '/fca/' + relationId, {responseType: 'blob'});
    }

    getXml(relationId: number) {
        return axios.get(RELATION_API_BASE_URL + '/xml/' + relationId);
    }

    performCalculation(calculationCommand: CalculationCommand) {
         return axios.post(RELATION_API_BASE_URL + '/calculation', calculationCommand);
    }

    getProperties(relationId: number) {
        return axios.get(RELATION_API_BASE_URL + '/properties/' + relationId);
    }

    performRCA(contexts: number[], objToObjRelations: number[], scalingOperators: string[], performLabelReduction: boolean) {
        console.log({ contexts, objToObjRelations, scalingOperators });
        return axios.post(RELATION_API_BASE_URL + '/rca', { contexts, objToObjRelations, scalingOperators, performLabelReduction });
    }

    getPoset(posetId: number) {
        return axios.get(RELATION_API_BASE_URL + '/poset/' + posetId, {responseType: 'blob'});
    }

    generateIdentity(relationId: number, generateSourceIdentity: boolean, relationType: string) {
        return axios.post(RELATION_API_BASE_URL + '/identity', { relationId, generateSourceIdentity, relationType });
    }
    generateConcepts(relationId: number, relationType: string) {
        return axios.post(RELATION_API_BASE_URL + '/concepts', { relationId, relationType });
    }

}

export default new RelationService();