import type { NextPage } from 'next'
import Head from 'next/head'
import Image from 'next/image'
import RelationService from "../services/RelationService";
import ListRelation from '../components/ListRelations';
import {Relation} from "../types/RelationTypes";
import React from "react";
import Layout from "../components/Layout";

// type Props = {
//   relations: Relation[];
// }

const Home: NextPage = () => {

  return (
    <div className="container">
      <Head>
        <title>CAURA</title>
        <meta name="description" content="" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main className="fixed w-full h-full">
        <Layout/>
      </main>
    </div>
  )
}

// export async function getServerSideProps() {
//   const relationsResponse = await RelationService.getAllRelations();
//     const relations = relationsResponse.data;
//   return {
//     props: {
//       relations
//     },
//   }
// }

export default Home
