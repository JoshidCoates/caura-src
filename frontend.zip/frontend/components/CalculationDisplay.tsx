import React, {FC, useEffect, useRef, useState} from 'react';


import {Box, Button, CircularProgress, Divider, Skeleton, Tab, Tabs, Tooltip, Typography} from "@mui/material";
import {CalculationResponse, Relation, RelationInfo} from "../types/RelationTypes";
import CalculationBox from "./CalculationBox";
import FCABox from "./FCABox";
import RCABox from "./RCABox";
import RelationService from "../services/RelationService";
import {height, width} from "@mui/system";
import {Download, OpenInNew} from "@mui/icons-material";

type Props = {
    calculation: string;
    loadRelations(): void;
}


const CalculationDisplay: FC<Props> = ({calculation, loadRelations}) => {
    const [result, setResult] = useState<string | null>(null);
    const [beforeShowLoad, setBeforeShowLoad] = useState(true);
    const [time, setTime] = useState<number | null>(null);

    useEffect(() => {
        const startTime = new Date().getTime();
        const timer = setTimeout(() => setBeforeShowLoad(false), 50);

        RelationService.performCalculation({ calculation }).then(
            response => {
                const calculationResult: CalculationResponse = response.data;
                console.log(calculationResult)
                if (calculationResult.resultSymbol !== '\u0000') {
                    setResult(calculation + ' saved as relation ' + calculationResult.resultSymbol);
                    loadRelations();
                } else {
                    setResult(calculation + ': ' + calculationResult.booleanResult + ' ');
                }
                loadRelations();
                const endTime = new Date().getTime();
                setTime(Math.round((endTime - startTime) / 10) / 100);
            }
        ).catch(e => {
            console.log(e)
            if (e.response.data.status === 400) {
                setResult('Invalid Operation ')
            } else if (e.response.data.status === 404) {
                setResult('Relation Not Found ')
            } else {
                setResult('Unknown Error ');
            }
            const endTime = new Date().getTime();
            setTime(Math.round((endTime - startTime) / 10) / 100);
        });
        return () => clearTimeout(timer);
    }, [calculation]);

    return (
        <div className="">{
            result ? (
                    <div className="px-5 pb-1">
                        <div className="w-full flex items-center -mb-4">
                            <div className="flex items-center"><p className="font-bold mr-1">Perform Calculation:</p><p>{calculation}</p></div>
                            <div className="flex-grow"></div>
                            <div className="italic">~{time}s</div>
                        </div>
                        <div className="p-2 flex justify-center">
                            <div className="flex items-center"><p>{result.slice(0,-1)}</p><p className="ml-1 font-bold">{result.slice(-1)}</p></div>
                        </div>
                    </div>
                )
                :
                (!beforeShowLoad &&
                    <div className="flex justify-center p-5">
                        <CircularProgress />
                    </div>
                )
        }
            <Divider flexItem/>
        </div>
    );
}

export default CalculationDisplay;