import React, {FC, ReactElement} from 'react';
import {RelationInfo} from "../types/RelationTypes";
import {Button, Tooltip} from "@mui/material";
import DeleteIcon from '@mui/icons-material/Delete';
import {Download, Edit, GridOn, ViewList} from "@mui/icons-material";
import RelationService from "../services/RelationService";
import RelationDisplay from "./RelationDisplay";
import EditRelation from "./EditRelation";
import PropertiesDisplay from "./PropertiesDisplay";

type Props = {
    relation: RelationInfo;
    loadRelations(): void;
    addToFeed(element: ReactElement): void;

}


const RelationBox: FC<Props> = ({relation, loadRelations, addToFeed}) => {
    const [editRelationOpen, setEditRelationOpen] = React.useState(false);
    const canShow = () => relation.rows <= 1000 && relation.cols <= 1000;
    // const canShow = () => true;
    const deleteRelation = async () => {
        await RelationService.deleteRelation(relation.id);
        loadRelations();
    }

    const show = async () => {
        // addToFeed(<div>{new Date().getTime()}</div>)
        addToFeed(<RelationDisplay relation={relation} key={new Date().getTime()}></RelationDisplay>)
    }

    const properties = async () => {
        // addToFeed(<div>{new Date().getTime()}</div>)
        addToFeed(<PropertiesDisplay relation={relation} key={new Date().getTime()}></PropertiesDisplay>)
    }

    const download = async () => {
        const response = await RelationService.getDownloadTxt(relation.id);
        const txt: string  = response.data;
        const file = new Blob([txt], {type: 'text/plain'});
        const element = document.createElement("a");
        element.href = URL.createObjectURL(file);
        element.download = relation.name + ".txt";
        document.body.appendChild(element);
        element.click();
    }

    const handleClickEditOpen = () => {
        setEditRelationOpen(true);
    };

    const handleEditClose = () => {
        setEditRelationOpen(false);
    };

    return (
        <div className="px-1">
            <div className="flex px-2">
                <p className="font-bold">{relation.symbol}</p>
                <p className="mx-3">{relation.name}</p>
                <p className="flex-grow"/>
                <p>{relation.rows}×{relation.cols}</p>
            </div>
            <div className="flex mb-1.5 items-center justify-center">
                <Tooltip
                    arrow
                    disableInteractive
                    title={canShow() ? '' : 'Cannot show relations with a dimension greater than 1000'}
                >
                    <span>
                        <Button
                            disabled={!canShow()}
                            variant="outlined"
                            startIcon={<GridOn/>}
                            onClick={show}
                        >Show</Button>
                    </span>
                </Tooltip>
                <Button className="mx-2" variant="outlined" startIcon={<Edit/>} onClick={handleClickEditOpen}>Edit</Button>
                <Button variant="outlined" color="error" startIcon={<DeleteIcon/>} onClick={deleteRelation}>Delete</Button>
            </div>
            <div className="flex mb-4 items-center justify-center">
                <Button className="mr-2" variant="outlined" startIcon={<ViewList/>} onClick={properties}>Properties</Button>
                <Button className="" variant="outlined" startIcon={<Download/>} onClick={download}>Download</Button>
            </div>
            <EditRelation relation={relation} onClose={handleEditClose} open={editRelationOpen} loadRelations={loadRelations} />
        </div>
    );
}

export default RelationBox;