import React, {FC, ReactElement} from 'react';

import AddIcon from '@mui/icons-material/Add';

import {Divider, Fab, FormControl, InputLabel, MenuItem, Select, SelectChangeEvent, Tooltip} from "@mui/material";
import AddRelation from "./AddRelation";
import {RelationInfo} from "../types/RelationTypes";
import RelationBox from './RelationBox';
import {Info, InfoOutlined} from "@mui/icons-material";

type Props = {
    relations: RelationInfo[];
    loadRelations(): void;
    relationType: string;
    handleRelationType(event: SelectChangeEvent): void;
    addToFeed(element: ReactElement): void;
}


const RelationPanel: FC<Props> = ({relations, loadRelations, relationType, handleRelationType, addToFeed}) => {
    const [addRelationOpen, setAddRelationOpen] = React.useState(false);

    const [symbol, setSymbol] = React.useState('');
    const handleSymbol = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSymbol(event.target.value);
    };

    const getDefaultSymbol = (): string => {
        const usedSymbols = relations.map(r => r.symbol);
        for (let letterIdx = 0; letterIdx < 26; letterIdx++) {
            const currentSymbol = String.fromCharCode(65 + letterIdx);
            if (!usedSymbols.includes(currentSymbol)) {
                return currentSymbol;
            }
        }
        return '!';
    }

    const handleClickOpen = () => {
        setSymbol(getDefaultSymbol())
        setAddRelationOpen(true);
    };

    const handleClose = () => {
        setAddRelationOpen(false);
    };

    return (
        <div className="flex flex-col items-center p-2 w-[328px]">
            <h2 className="-mt-0.5">CAURA</h2>
            <p className="italic text-sm -mt-4 text-center">Concept Analysis Using Relation Algebra</p>
            <Divider flexItem/>
            <div className="w-full flex items-center px-6 py-4">
                <FormControl fullWidth>
                    <InputLabel id="relation-type-label">Processing Engine</InputLabel>
                    <Select
                        labelId="relation-type-label"
                        id="relation-type-select"
                        value={relationType}
                        label="Processing Engine"
                        onChange={handleRelationType}
                    >
                        <MenuItem value={'SHARED_SET_RELATION'}>Butcher</MenuItem>
                        <MenuItem value={'PAIR_RELATION'}>Starlight</MenuItem>
                        <MenuItem value={'EO_SHARED_SET_RELATION'}>Noir</MenuItem>
                        <MenuItem value={'EO_PAIR_RELATION'}>Liberty</MenuItem>
                    </Select>
                </FormControl>
                <Tooltip title={<div>
                    <div>Changing the engine removes all relations</div>
                    <div>Butcher: Shared Set</div>
                    <div>Starlight: Basic</div>
                    <div>Noir: Shared Set Extended Operations</div>
                    <div>Liberty: Basic Extended Operations</div>
                </div>} className="ml-3 -mr-2"><InfoOutlined color="secondary"></InfoOutlined></Tooltip>
            </div>
            <Divider flexItem/>
            <div className="overflow-auto">
                {
                    relations.map((relation: RelationInfo, idx: number) =>
                        <div>
                            <RelationBox loadRelations={loadRelations} relation={relation} addToFeed={addToFeed}/>
                            <Divider/>
                        </div>
                    )
                }
            </div>
            <Tooltip
                arrow
                disableInteractive
                title="Add Relation"
            >
                <Fab className="min-h-[56px] mx-auto mt-2" onClick={handleClickOpen} color="primary" aria-label="add">
                    <AddIcon/>
                </Fab>
            </Tooltip>
            <AddRelation loadRelations={loadRelations} relations={relations} symbol={symbol} handleSymbol={handleSymbol} onClose={handleClose}
                         open={addRelationOpen}/>
        </div>
    );
}

export default RelationPanel;