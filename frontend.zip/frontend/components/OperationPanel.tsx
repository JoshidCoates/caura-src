import React, {FC, ReactElement, useEffect} from 'react';


import {Box, Divider, Tab, Tabs, Tooltip, Typography} from "@mui/material";
import {RelationInfo} from "../types/RelationTypes";
import CalculationBox from "./CalculationBox";
import FCABox from "./FCABox";
import RCABox from "./RCABox";

type Props = {
    relations: RelationInfo[];
    loadRelations(): void;
    relationType: string;
    addToFeed(element: ReactElement): void;

}

interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
}


function TabPanel(props: TabPanelProps) {
    const {children, value, index, ...other} = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`tabpanel-${index}`}
            aria-labelledby={`operation-tab-${index}`}
            {...other}
        >
            {value === index && (
                <div className="p-6">
                    {children}
                </div>
            )}
        </div>
    );
}

function a11yProps(index: number) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}


const OperationPanel: FC<Props> = ({relations, loadRelations, relationType, addToFeed}) => {
    const [openTab, setOpenTab] = React.useState(0);
    const handleChangeTab = (event: React.SyntheticEvent, newValue: number) => {
        setOpenTab(newValue);
    };

    useEffect(() => {
        if (relationType !== 'EO_PAIR_RELATION' && openTab == 2) setOpenTab(0);
    }, [relationType])

    const canPerformRCA = () => relationType === 'EO_PAIR_RELATION' || relationType === 'EO_SHARED_SET_RELATION';

    return (
        <div>
            <Box sx={{borderBottom: 1, borderColor: 'divider'}}>
                <Tabs centered value={openTab} onChange={handleChangeTab} aria-label="operation tabs">
                    <Tab label="Calculator" {...a11yProps(0)} />
                    <Tab disabled={false}
                         style={{ pointerEvents: "auto" }}
                         label={
                             <Tooltip
                                 arrow
                                 disableInteractive
                                 title={''}
                             >
                                 <span>FCA</span>
                             </Tooltip>
                         }
                         {...a11yProps(1)}
                    />
                    <Tab disabled={!canPerformRCA()}
                         style={{ pointerEvents: "auto" }}
                         label={
                             <Tooltip
                                 arrow
                                 disableInteractive
                                 title={canPerformRCA() ? '' : 'Requires the Noir or Liberty processing engine'}
                             >
                                 <span>RCA</span>
                             </Tooltip>
                         }
                         {...a11yProps(2)}
                    />
                </Tabs>
            </Box>
            <TabPanel value={openTab} index={0}>
                <CalculationBox relations={relations} loadRelations={loadRelations} addToFeed={addToFeed}/>
            </TabPanel>
            <TabPanel value={openTab} index={1}>
                <FCABox addToFeed={addToFeed} relations={relations} loadRelations={loadRelations}/>
            </TabPanel>
            <TabPanel value={openTab} index={2}>
                <RCABox addToFeed={addToFeed} relations={relations} loadRelations={loadRelations}/>
            </TabPanel>
            <Divider/>
        </div>
    );
}

export default OperationPanel;