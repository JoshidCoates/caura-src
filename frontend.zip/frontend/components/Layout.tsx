import React, {FC, ReactElement, useEffect, useRef} from 'react';

import RelationPanel from "./RelationPanel";
import {Relation} from "../types/RelationTypes";
import RelationService from "../services/RelationService";
import {Divider, SelectChangeEvent} from "@mui/material";
import OperationPanel from "./OperationPanel";
import MatrixCanvas from "./MatrixCanvas";
import {element} from "prop-types";


const Layout: FC = () => {
    const [relations, setRelations] = React.useState([]);
    const [feed, setFeed] = React.useState<ReactElement[]>([]);
    const topOfFeed = useRef(null);
    const loadRelations = () => {
        RelationService.getAllRelations().then((relationsResponse: any) => {
            setRelations(relationsResponse.data);
        });
    }
    useEffect(() => {
        loadRelations();
    }, []);

    const [relationType, setRelationType] = React.useState('SHARED_SET_RELATION');

    const handleRelationType = async (event: SelectChangeEvent) => {
        const newValue = event.target.value as string;
        await RelationService.setRelationType(newValue);
        // todo probably need to add loading here
        setRelationType(newValue);
        loadRelations();
        setFeed([]);
    };

    const addToFeed = (element: ReactElement) => {
        setFeed(prevFeed => [element, ...prevFeed]);
        // @ts-ignore
        topOfFeed.current.scrollIntoView();
        // console.log(feed)
    }

    return (
        <div className="h-full w-full flex">
            <RelationPanel
                relations={relations}
                loadRelations={loadRelations}
                relationType={relationType}
                handleRelationType={handleRelationType}
                addToFeed={addToFeed}
            />
            <Divider flexItem orientation="vertical"/>
            <div className="flex flex-col flex-grow">
                <OperationPanel relations={relations} loadRelations={loadRelations} relationType={relationType} addToFeed={addToFeed}/>
                <div className="overflow-y-auto overflow-x-hidden">
                    <div ref={topOfFeed}></div>
                    {feed}
                    {/*{feed.map((component, index) => React.cloneElement(component, { key: index }))}*/}
                </div>
                {/*<MatrixCanvas></MatrixCanvas>*/}
                {/*<div className="flex-grow"/>*/}
            </div>
        </div>
    );
}

export default Layout;