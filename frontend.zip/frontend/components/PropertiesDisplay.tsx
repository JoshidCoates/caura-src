import React, {FC, useEffect, useRef, useState} from 'react';


import {
    Box,
    Button,
    CircularProgress,
    Divider, IconButton, List, ListItem, ListItemText, Paper,
    Skeleton,
    Tab, Table, TableBody, TableCell,
    TableContainer, TableHead, TableRow,
    Tabs,
    Tooltip,
    Typography
} from "@mui/material";
import {CalculationResponse, Relation, RelationInfo} from "../types/RelationTypes";
import CalculationBox from "./CalculationBox";
import FCABox from "./FCABox";
import RCABox from "./RCABox";
import RelationService from "../services/RelationService";
import {height, width} from "@mui/system";
import {Check, Download, ExpandMore, OpenInNew} from "@mui/icons-material";

type Props = {
    relation: RelationInfo;
}


const PropertiesDisplay: FC<Props> = ({relation}) => {
    const [properties, setProperties] = useState<any | null>(null);
    const [displayedProperties, setDisplayedProperties] = useState<any | null>(null);
    const [beforeShowLoad, setBeforeShowLoad] = useState(true);
    const [time, setTime] = useState<number | null>(null);
    const [showLoadMore, setShowLoadMore] = useState(true);

    useEffect(() => {
        const startTime = new Date().getTime();
        const timer = setTimeout(() => setBeforeShowLoad(false), 50);

        RelationService.getProperties(relation.id).then(
            response => {
                const properties = Object.entries(response.data);
                setProperties(properties);
                if (properties.length > 15) {
                    setDisplayedProperties(properties.slice(0, 12));
                } else {
                    setDisplayedProperties(properties.slice(0, 4));
                }
                const endTime = new Date().getTime();
                setTime(Math.round((endTime - startTime) / 10) / 100);
            }
        );
        return () => clearTimeout(timer);
    }, [relation]);

    const loadMoreProperties = () => {
        setShowLoadMore(false);
        setDisplayedProperties(properties);
    }

    return (
        <div className="">{
            displayedProperties ? (
                    <div className="px-5 pb-1">
                        <div className="w-full flex items-center -mb-4">
                            <div className="flex items-center"><p className="font-bold mr-1">Properties:</p>
                                <p>{relation.name}</p></div>
                            <div className="flex-grow"></div>
                            <div className="italic">~{time}s</div>
                        </div>
                        <div className="p-2 flex flex-col items-center justify-center">
                            {/*<TableContainer className="w-auto">*/}
                            {/*    <Table size="small" aria-label="properties table">*/}
                            {/*        /!*<TableHead>*!/*/}
                            {/*        /!*    <TableRow>*!/*/}
                            {/*        /!*        <TableCell>Property</TableCell>*!/*/}
                            {/*        /!*        <TableCell align="right">Has property?</TableCell>*!/*/}
                            {/*        /!*    </TableRow>*!/*/}
                            {/*        /!*</TableHead>*!/*/}
                            {/*        <TableBody>*/}
                            {/*            {displayedProperties.map((property: any) => (*/}
                            {/*                <TableRow*/}
                            {/*                    key={property[0]}*/}
                            {/*                >*/}
                            {/*                    <TableCell component="th" scope="row">*/}
                            {/*                        {property[0]}*/}
                            {/*                    </TableCell>*/}

                            {/*                    <TableCell*/}
                            {/*                        className="border-l border-r border-t-0 border-solid border-zinc-200">{}</TableCell>*/}
                            {/*                </TableRow>*/}
                            {/*            ))}*/}
                            {/*            {showLoadMore &&*/}
                            {/*                <TableRow><Button onClick={loadMoreProperties}>Load more</Button></TableRow>}*/}
                            {/*        </TableBody>*/}
                            {/*    </Table>*/}
                            {/*</TableContainer>*/}
                            <List dense>
                                {displayedProperties.map((property: any, index: number) => (
                                    <ListItem className={`${index === 0 ? '' : 'border-t-0'} border border-solid border-zinc-200 py-0`}
                                              secondaryAction={
                                                  property[1] === true ?
                                                      <Check/> : <></>
                                              }>
                                        <ListItemText
                                            primary={property[0]}
                                            className="mr-4 my-2"
                                        />
                                        <Divider orientation="vertical" className="mr-2" flexItem></Divider>
                                    </ListItem>
                                ))}
                                {showLoadMore && <ListItem className="border border-t-0 border-solid border-zinc-200 py-0">
                                    <Button onClick={loadMoreProperties} className="mx-auto flex items-center"><div className="pt-0.5">Show more</div><ExpandMore/></Button>
                                </ListItem>}
                            </List>
                        </div>
                    </div>
                )
                :
                (!beforeShowLoad &&
                    <div className="flex justify-center p-5">
                        <CircularProgress/>
                    </div>
                )
        }
            <Divider flexItem/>
        </div>
    );
}

export default PropertiesDisplay;