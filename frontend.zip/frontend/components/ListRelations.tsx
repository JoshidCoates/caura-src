import React, {FC, useEffect} from 'react';
import {Relation} from "../types/RelationTypes";
import NewRelation from "./NewRelation";
import Calculation from "./Calculation";
import RelationView from "./RelationView";
import RelationService from "../services/RelationService";
import ShowRelation from "./ShowRelation";
// import Viz from 'viz.js';
// import { Graphviz } from 'graphviz-react';
import { Module, render } from 'viz.js/full.render.js';
import workerURL from 'viz.js/full.render.js';
// type Props = {
//     showRelation(idx: number): void;
// }
import dynamic from 'next/dynamic';

const Graphviz = dynamic(() => import('graphviz-react'), { ssr: false });

const ListRelations: FC = () => {
    const [relationType, setRelationType] = React.useState('PAIR_RELATION');
    const [relations, setRelations] = React.useState([]);
    const [currentRelation, setCurrentRelation] = React.useState<Relation | undefined>();
    const [currentGraph, setCurrentGraph] = React.useState<String | undefined>();
    const showRelation = (idx: number) => {
        setCurrentRelation(relations[idx]);
    }
    const loadRelations = () => {
        RelationService.getAllRelations().then((relationsResponse: any) => {
            setRelations(relationsResponse.data);
            setCurrentRelation(undefined);
        });
    }
    useEffect(() => {
        loadRelations();
    }, []);
    const changeRelationType = (event: any) => {
        event.preventDefault();
        setRelationType(event.target.type.value);
        loadRelations();
    }
    // console.log(Module);
    // console.log(render);
    // console.log(Viz.Viz);
    // console.log(workerURL);

    // let viz = new Viz({ workerURL: 'node_modules/viz.js/full.render.js' });
    // let viz = new Viz({ Module, render });

    const showGraph = (dot: string) => {
        setCurrentGraph(dot);
        // viz.renderString('digraph { a -> b }')
        //     .then((result: any) => {
        //         console.log(result);
        //     })
        //     .catch((error: any) => {
        //         // Create a new Viz instance (@see Caveats page for more info)
        //         viz = new Viz({ Module, render });
        //
        //         // Possibly display the error
        //         console.error(error);
        //     });
    }
    return (
        <div className="w-full flex">
            <div className="w-1/3">
                <h2>Relations</h2>
                <form onSubmit={changeRelationType}>
                    <label htmlFor="type">Change processing engine: </label>
                    <select name="type" defaultValue={'PAIR_RELATION'} className="mr-3">
                        <option value="EO_PAIR_RELATION">Experimental Pairwise</option>
                        <option value="PAIR_RELATION">Pairwise</option>
                        <option value="MATRIX_RELATION">Matrix</option>
                    </select>
                    <button type="submit">Go</button>
                </form>
                <RelationView relations={relations} showRelation={showRelation} loadRelations={loadRelations}
                              relationType={relationType} showGraph={showGraph}/>
                <NewRelation loadRelations={loadRelations}/>
                <Calculation relationType={relationType} loadRelations={loadRelations}/>
            </div>
            {currentRelation && <div className="w-1/2">
                <ShowRelation relation={currentRelation}/>
            </div>}
            {currentGraph && <Graphviz dot={`${currentGraph}`}/>}

        </div>

    );
}

export default ListRelations;