import React, {FC} from 'react';

type Props = {
    onClose(): void;
    open: boolean;
}

import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle, Divider,
    Fab, FormControl, FormControlLabel, FormLabel, RadioGroup, Radio,
    TextField, Checkbox, FormGroup, Link
} from "@mui/material";
import {Upload} from "@mui/icons-material";
import RelationService from "../services/RelationService";


const FCAHelp: FC<Props> = ({ onClose, open }) => {
    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>FCA Help</DialogTitle>
            <DialogContent>
                <DialogContentText>Choose a relation to perform Formal Concept Analysis (FCA) on. The concepts in the AOC-poset are calculated and stored in an XML file using a format similar to LIRMM's <Link target="_blank" href="https://www.lirmm.fr/aoc-poset-builder/">AOC-poset builder</Link>. For small relations, the AOC-poset in generated as an image. Learn more about Formal Concept Analysis (FCA) <Link target="_blank" href="https://en.wikipedia.org/wiki/Formal_concept_analysis">here</Link>.</DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Close</Button>
            </DialogActions>
        </Dialog>
    );
}

export default FCAHelp;