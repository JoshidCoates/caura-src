import React, {FC, useState} from 'react';
import RelationService from "../services/RelationService";
import {useRouter} from 'next/router';

type Props = {
    loadRelations(): void;
}

const ListRelations: FC<Props> = ({ loadRelations }) => {
    const [customFormat, setCustomFormat] = useState(true);
    const [customData, setCustomData] = useState(true);
    const [errorMessage, setErrorMessage] = useState('');
    const [homogeneousChecked, setHomogeneousChecked] = useState(false);
    const saveRelation = async (event: any) => {
        console.log("fsave 1");
        console.log(Date.now());
        setErrorMessage('');
        event.preventDefault();
        try {
            const name = event.target.name.value;
            const symbol = event.target.symbol.value;
            let sourceData = event.target.source?.value;
            if (!sourceData) {
                let rowSize = homogeneousChecked ? event.target.size.value : event.target.rows.value;
                sourceData = Array.from(Array(parseInt(rowSize)).keys()).toString();
            }
            let targetData = event.target.target?.value;
            if (!targetData) {
                if (homogeneousChecked) {
                    targetData = Array.from(Array(parseInt(event.target.size.value)).keys()).toString();
                } else {
                    targetData = Array.from(Array(parseInt(event.target.cols.value))).map((e, i) => {
                        var result = '';
                        do {
                            result = (i % 26 + 10).toString(36) + result;
                            i = Math.floor(i / 26) - 1;
                        } while (i >= 0)
                        return result;
                    }).toString();
                }
            }

            // console.log(targetData)
            console.log("fsave 2");
            console.log(Date.now());

            const relationData = event.target.data?.value;
            let density;
            let generateRelation = false;
            if (!customData) {
                density = event.target.density.value;
                generateRelation = true;
            }


            await RelationService.saveRelation({
                name,
                symbol,
                sourceData,
                targetData,
                generateRelation,
                density,
                relationData,
            });
            console.log("fsave 3");
            console.log(Date.now());
            // @ts-ignore
            document.getElementById("new-relation-form").reset();
            loadRelations();
            console.log("fsave 4");
            console.log(Date.now());
        } catch (e) {
            console.log(e);
            setErrorMessage('Bad Format');
        }
    };
    const switchHomogeneous = () => {
        setHomogeneousChecked(!homogeneousChecked);
    }
    const switchCustomFormat = () => {
        setCustomFormat(!customFormat);
    }
    const switchCustomData = () => {
        setCustomData(!customData);
    }
    // todo button to show/hide rows+cols
    return (
        <form onSubmit={saveRelation} id="new-relation-form" className="flex flex-col">
            <label htmlFor="name">Name:</label>
            <input type="text" name="name"/>
            <label htmlFor="symbol">Symbol:</label>
            <input type="text" required minLength={1} maxLength={1} name="symbol"/>
            {customFormat && <>
                <label htmlFor="source">Source:</label>
                <input type="text" required name="source"/>
                <label htmlFor="target">Target:</label>
                <input type="text" required name="target"/></>}
            {!customFormat && <>
                <label htmlFor="homogeneous">Homogeneous</label>
                <input type="checkbox" name="homogeneous" checked={ homogeneousChecked }  onChange={ switchHomogeneous }/>
                { !homogeneousChecked && <>
                    <label htmlFor="rows">No of Rows:</label>
                    <input type="number" required min={1} name="rows"/>
                    <label htmlFor="cols">No of Cols:</label>
                    <input type="text" required min={1} name="cols"/>
                </>}
                { homogeneousChecked && <>
                    <label htmlFor="size">Size:</label>
                    <input type="number" required min={1} name="size"/>
                    </>}
            </>}
            <button
                onClick={switchCustomFormat} type="button">{customFormat ? 'Generate Source and Target' : 'Define Source and Target'}</button>
            { customData && <>
                <label htmlFor="data">Data:</label>
                <textarea name="data"/>
            </>}
            { !customData && <>
                <label htmlFor="density">Density:</label>
                <input type="number" required defaultValue={0.5} step="any" min={0} max={1} name="density"/>
            </>}
            <button
                onClick={switchCustomData} type="button">{customData ? 'Generate Data' : 'Define Data'}</button>
            <button className="" type="submit">Add Relation</button>
            <div className="text-red-500">{errorMessage}</div>
        </form>
    );
}

export default ListRelations;