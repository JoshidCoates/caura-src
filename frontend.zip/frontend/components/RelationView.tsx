import React, {FC} from 'react';
import {Relation, RelationInfo} from "../types/RelationTypes";
import RelationService from "../services/RelationService";
import { useRouter } from 'next/router';

type Props = {
    relations: RelationInfo[];
    showRelation(idx: number): void;
    loadRelations(): void;
    showGraph(dot: string): void;
    relationType: string;
}

const RelationView: FC<Props> = ({ relations, showRelation, showGraph, loadRelations, relationType }) => {
    console.log(relations)
    const resetRelations = async (event: any) => {
        event.preventDefault();
        await RelationService.resetRelations();
        loadRelations();
    };
    const generateIdentity = async (relationId: number, generateSource: boolean) => {
        await RelationService.generateIdentity(relationId, generateSource, relationType);
        loadRelations();
    };
    const generateConcepts = async (relationId: number) => {
        const response = await RelationService.generateConcepts(relationId, relationType);
        const dot = response.data.dot;
        const xml = response.data.xml;
        const file = new Blob([xml], {type: 'text/plain'});
        const element = document.createElement("a");
        element.href = URL.createObjectURL(file);
        element.download = relationId + ".xml";
        document.body.appendChild(element); // Required for this to work in FireFox
        element.click();
        showGraph(dot);
        loadRelations();
    };
    return (
        <div>
            <table className="my-2">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Symbol</th>
                    <th>Size</th>
                </tr>
                </thead>
                <tbody>
                {
                    relations.map((relation: RelationInfo, idx: number) =>
                        <tr key={relation.id} onClick={() => showRelation(idx)} className="hover:bg-gray-100 cursor-pointer">
                            <td>{relation.name}</td>
                            <td>{relation.symbol}</td>
                            <td>{relation.rows}x{relation.cols}</td>
                            <td>
                                <button onClick={() => generateIdentity(relation.id, true)}>Save Source Id</button>
                            </td>
                            <td>
                                <button onClick={() => generateIdentity(relation.id, false)}>Save Target Id</button>
                            </td>
                            <td>
                                <button onClick={() => generateConcepts(relation.id)}>Generate Concepts</button>
                            </td>
                        </tr>
                    )
                }
                </tbody>
            </table>
            <form onSubmit={resetRelations} className="flex flex-col mt-3">
                <button className="" type="submit">Reset Relations</button>
            </form>
        </div>
    );
}

export default RelationView;