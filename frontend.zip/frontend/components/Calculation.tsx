import React, {FC, useState} from 'react';
import RelationService from "../services/RelationService";
import { useRouter } from 'next/router';
import {CalculationResponse} from "../types/RelationTypes";

type Props = {
    relationType: string;
    loadRelations(): void;
}

const Calculation: FC<Props> = ({ relationType, loadRelations }) => {
    const [calc, setCalc] = useState('');
    const [result, setResult] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    const performCalculation = async (event: any) => {
        // event.preventDefault();
        // setErrorMessage('');
        // setResult('');
        // try {
        //     const response = await RelationService.performCalculation({
        //         calculation: event.target.calc.value,
        //         relationType,
        //     });
        //     const calculationResult: CalculationResponse = response.data;
        //     if (calculationResult.relationResult) {
        //         loadRelations();
        //     } else {
        //         setResult(calc + ': ' + calculationResult.booleanResult);
        //     }
        //     setCalc('')
        // } catch (e: any) {
        //     console.log(e);
        //     setErrorMessage('Bad Format');
        // }
    };
    const handleTextChange = (event: any) => {
        let text = event.target.value;
        text = text.replaceAll('u', '∪');
        text = text.replaceAll('n', '∩');
        text = text.replaceAll('^', 'Δ');
        text = text.replaceAll('+', '†');
        text = text.replaceAll('-1', '⁻¹');
        text = text.replaceAll('d', 'ᵈ');
        text = text.replaceAll('<', '⊆');
        setCalc(text);
    }
    return (
        <form onSubmit={performCalculation} className="flex flex-col mt-3">
            <label htmlFor="calc">Calculation:</label>
            <input type="text" required value={calc} placeholder="∪ ∩ ~ | \ / Δ † ⁻¹ ᵈ ⊆ = - syq cqp" onChange={handleTextChange} name="calc"/>
            <button className="" type="submit">Calculate</button>
            <div>
                {result}
            </div>
            <div className="text-red-500">
                {errorMessage}
            </div>
        </form>
    );
}

export default Calculation;