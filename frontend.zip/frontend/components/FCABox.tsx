import React, {FC, ReactElement} from 'react';
import {RelationInfo} from "../types/RelationTypes";
import {
    Button,
    Divider,
    Fab,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    SelectChangeEvent,
    TextField,
    Tooltip
} from "@mui/material";
import DeleteIcon from '@mui/icons-material/Delete';
import {Download, GridOn, Help, HelpOutline, InfoOutlined, QuestionMark, Upload} from "@mui/icons-material";
import RelationService from "../services/RelationService";
import AddIcon from "@mui/icons-material/Add";
import AddRelation from "./AddRelation";
import CalculationHelp from "./CalculationHelp";
import RelationBox from "./RelationBox";
import FCAHelp from "./FCAHelp";
import RelationDisplay from "./RelationDisplay";
import {renderIntoDocument} from "react-dom/test-utils";
import FCADisplay from "./FCADisplay";

type Props = {
    relations: RelationInfo[];
    loadRelations(): void;
    addToFeed(element: ReactElement): void;
}


const FCABox: FC<Props> = ({relations, loadRelations, addToFeed}) => {
    const [helpOpen, setHelpOpen] = React.useState(false);
    const handleClickHelpOpen = () => {
        setHelpOpen(true);
    };
    const handleHelpClose = () => {
        setHelpOpen(false);
    };

    const [chosenRelation, setChosenRelation] = React.useState('');

    const handleChosenRelation = (event: SelectChangeEvent) => {
        const newValue = event.target.value as string;
        setChosenRelation(newValue);
    };

    const perform = async () => {
        // addToFeed(<div>{new Date().getTime()}</div>)
        const relation = relations.find(r => r.id === parseInt(chosenRelation));
        if (relation) {
            addToFeed(<FCADisplay relation={relation} key={new Date().getTime()}></FCADisplay>)

        } else {
            // todo show relation not picked error
        }
    }


    return (
        <div className="min-h-[60px]">
            <FCAHelp open={helpOpen} onClose={handleHelpClose}/>
            <div className="flex items-center">
                <FormControl fullWidth>
                    <InputLabel id="relation-type-label">Relation</InputLabel>
                    <Select
                        labelId="fca-relation-label"
                        id="fca-relation-select"
                        value={chosenRelation}
                        label="Relation"
                        onChange={handleChosenRelation}
                    >
                        {
                            relations.map((relation: RelationInfo, idx: number) =>
                                <MenuItem value={relation.id}>{relation.name}</MenuItem>
                            )
                        }
                    </Select>
                </FormControl>
                <Button className="mx-3" variant="contained" onClick={perform}>
                    Go
                </Button>
                <Button className="ml-3 shrink-0" variant="outlined" endIcon={<InfoOutlined />} onClick={handleClickHelpOpen} color="secondary">Help</Button>

            </div>
        </div>
    );
}

export default FCABox;