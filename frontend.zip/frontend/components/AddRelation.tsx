import React, {FC} from 'react';

type Props = {
    onClose(): void;
    open: boolean;
    loadRelations(): void;
    relations: RelationInfo[];
    symbol: string;
    handleSymbol(event: React.ChangeEvent<HTMLInputElement>): void;
}

import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle, Divider,
    Fab, FormControl, FormControlLabel, FormLabel, RadioGroup, Radio,
    TextField, Checkbox, FormGroup, Tooltip
} from "@mui/material";
import {InfoOutlined, Upload} from "@mui/icons-material";
import RelationService from "../services/RelationService";
import {RelationInfo} from "../types/RelationTypes";


const AddRelation: FC<Props> = ({ onClose, open, loadRelations, relations, symbol, handleSymbol }) => {

    const uploadMultipleFiles = async (files: any, newSymbols: string[]) => {
        const file = files[0];
        const { name } = file;

        const nameToUse = name.split('.')[0];
        // let nameToUse: string = name.split('.')[0];
        // nameToUse = nameToUse[0].toUpperCase() + nameToUse.slice(1);

        const reader = new FileReader();
        reader.readAsText(file);
        reader.onload = async (e: any) => {
            // console.log(reader.result)
            // @ts-ignore
            const txt = e.target.result.trim().replaceAll("\r\n", "\n").replaceAll("\r", "\n");
            let parts = txt.split(/\[[A-Za-z0-9_-]*\]\n/);
            if (!parts[0].length) parts = parts.slice(1);
            const source = parts[1].replaceAll('\n', ',').slice(0,-1);
            const target = parts[2].replaceAll('\n', ',').slice(0,-1);
            const relationData = parts[3];
            console.log(nameToUse)
            console.log(newSymbols[0])
            console.log(relationData)
            await RelationService.saveRelation({
                name: nameToUse,
                symbol: newSymbols[0],
                sourceData: source,
                targetData: target,
                generateRelation: false,
                relationData: relationData,
            });
            // console.log(i)
            console.log("done")
            if (files.length > 1) {
                uploadMultipleFiles(files.slice(1), newSymbols.slice(1));
            } else {
                loadRelations();
            }
            // if (i == files.length - 1) {
            //     loadRelations();
            // }
        };
    };


    const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!e.target.files) {
            return;
        }

        const files = Array.prototype.slice.call(e.target.files);
        // console.log(e.target.files)
        // console.log(files)

        if (files.length > 1) {
            const newSymbols = getNewSymbols(files.length);
            await uploadMultipleFiles(files, newSymbols);
            // loadRelations();
            // resetFields();
            handleClose();
        } else {
            const file = files[0];
            const { name } = file;

            let nameToUse: string = name.split('.')[0];
            // nameToUse = nameToUse[0].toUpperCase() + nameToUse.slice(1);

            setName(nameToUse);
            setSourceTargetRadio('manual');
            setDataRadio('manual');

            const reader = new FileReader();
            reader.readAsText(file);
            reader.onload = () => {
                // @ts-ignore
                const txt = reader.result.trim().replaceAll("\r\n", "\n").replaceAll("\r", "\n");
                let parts = txt.split(/\[[A-Za-z0-9_-]*\]\n/);
                if (!parts[0].length) parts = parts.slice(1);
                const size = parts[0].split('\n');
                setRows(size[0]);
                setCols(size[1]);
                const source = parts[1].replaceAll('\n', ',').slice(0,-1);
                setSource(source);
                const target = parts[2].replaceAll('\n', ',').slice(0,-1);
                setTarget(target);
                setHomogeneous(source === target);
                setData(parts[3]);
            };
        }
    };

    const getNewSymbols = (num: number): string[] => {
        const usedSymbols = relations.map(r => r.symbol);
        const newSymbols = [];
        for (let letterIdx = 0; letterIdx < 26; letterIdx++) {
            const currentSymbol = String.fromCharCode(65 + letterIdx);
            if (!usedSymbols.includes(currentSymbol)) {
                newSymbols.push(currentSymbol);
                if (newSymbols.length === num) return newSymbols;
            }
        }
        return [];
    }

    const [sourceTargetRadio, setSourceTargetRadio] = React.useState('manual');
    const handleSourceTargetRadio = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSourceTargetRadio((event.target as HTMLInputElement).value);
        updateSourceAndTarget(homogeneous, parseInt(rows), parseInt(cols));
    };

    const [name, setName] = React.useState('');
    const handleName = (event: React.ChangeEvent<HTMLInputElement>) => {
        setName(event.target.value);
    };

    const updateSourceAndTarget = (homogeneous: boolean, rows: number, cols: number) => {
        if (homogeneous) {
            setSource(isNaN(rows) ? '' : Array.from(Array(cols)).map((e, i) => {
                var result = '';
                do {
                    result = (i % 26 + 10).toString(36) + result;
                    i = Math.floor(i / 26) - 1;
                } while (i >= 0)
                return result;
            }).toString());
            setTarget(isNaN(cols) ? '' : Array.from(Array(cols)).map((e, i) => {
                var result = '';
                do {
                    result = (i % 26 + 10).toString(36) + result;
                    i = Math.floor(i / 26) - 1;
                } while (i >= 0)
                return result;
            }).toString());
        } else {
            setSource(isNaN(rows) ? '' : Array.from(Array(rows)).map((e, i) => {
                var result = '';
                do {
                    result = (i % 26 + 10).toString(36) + result;
                    i = Math.floor(i / 26) - 1;
                } while (i >= 0)
                return result;
            }).toString());
            setTarget(isNaN(cols) ? '' : Array.from(Array(cols).keys()).toString())
        }
    }

    const [source, setSource] = React.useState('');
    const handleSource = (event: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = event.target.value;
        const trimmed = newValue.replaceAll(',', ' ').trim();
        setHomogeneous(trimmed === target.replaceAll(',', ' ').trim());
        setRows(trimmed.split(/\s+/).length.toString());
        setSource(newValue);
    };

    const [target, setTarget] = React.useState('');
    const handleTarget = (event: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = event.target.value;
        const trimmed = newValue.replaceAll(',', ' ').trim();
        setHomogeneous(trimmed === source.replaceAll(',', ' ').trim());
        setCols(trimmed.split(/\s+/).length.toString());
        setTarget(newValue);
    };

    const [rows, setRows] = React.useState('');
    const handleRows = (event: React.ChangeEvent<HTMLInputElement>) => {
        const newValue: number = parseInt(event.target.value);
        if (homogeneous) {
            setCols(newValue.toString());
            updateSourceAndTarget(homogeneous, newValue, newValue);
        } else {
            updateSourceAndTarget(homogeneous, newValue, parseInt(cols));
        }
        setRows(newValue.toString());
    }

    const [cols, setCols] = React.useState('');
    const handleCols = (event: React.ChangeEvent<HTMLInputElement>) => {
        const newValue: number = parseInt(event.target.value);
        if (homogeneous) {
            setRows(newValue.toString());
            updateSourceAndTarget(homogeneous, newValue, newValue);
        } else {
            updateSourceAndTarget(homogeneous, parseInt(rows), newValue);
        }
        setCols(newValue.toString());
    };

    const [homogeneous, setHomogeneous] = React.useState(false);
    const handleHomogeneous = (event: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = event.target.checked;
        setHomogeneous(newValue);
        if (newValue) {
            setCols(rows);
            updateSourceAndTarget(newValue, parseInt(rows), parseInt(rows));
        } else {
            updateSourceAndTarget(newValue, parseInt(rows), parseInt(cols));
        }
    };

    const [dataRadio, setDataRadio] = React.useState('manual');
    const handleDataRadio = (event: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = (event.target as HTMLInputElement).value;
        if (newValue === 'manual') setDensity('');
        setDataRadio(newValue);
    };

    const [data, setData] = React.useState('');
    const handleData = (event: React.ChangeEvent<HTMLInputElement>) => {
        setData(event.target.value);
    };

    const [density, setDensity] = React.useState('');
    const handleDensity = (event: React.ChangeEvent<HTMLInputElement>) => {
        setDensity(event.target.value);
    };

    const resetFields = () => {
        setName('');
        setSourceTargetRadio('manual');
        setSource('');
        setTarget('');
        setRows('');
        setCols('');
        setHomogeneous(false);
        setDataRadio('manual');
        setData('');
        setDensity('');
        setShowError(false);
    }

    const handleCancel = () => {
        handleClose();
        resetFields();
    };

    const [showError, setShowError] = React.useState(false);

    const handleAdd = () => {
        RelationService.saveRelation({
            name,
            symbol,
            sourceData: source,
            targetData: target,
            generateRelation: dataRadio === 'auto',
            density: parseFloat(density),
            relationData: data,
        }).then(() => {
            loadRelations();
            resetFields();
            handleClose();
        }).catch(e => {
            setShowError(true);
        });
    };

    const handleClose = () => {
        setShowError(false);
        onClose();
    };

    return (
        <Dialog open={open} onClose={handleClose}>
            <DialogTitle>Add Relation</DialogTitle>
            <DialogContent>
                <div className="flex items-center">
                    <Button component="label" variant="outlined" startIcon={<Upload />}>
                        Upload
                        <input
                            type="file"
                            multiple
                            hidden
                            onChange={handleFileUpload}
                        />
                    </Button>
                    <Tooltip title={<div>
                        <div>Text files should be of this form:</div>
                        <div>[Size]</div>
                        <div>5</div>
                        <div>5</div>
                        <div>[Source]</div>
                        <div>a</div>
                        <div>b</div>
                        <div>c</div>
                        <div>[Target]</div>
                        <div>a</div>
                        <div>b</div>
                        <div>c</div>
                        <div>[Relation]</div>
                        <div>010</div>
                        <div>110</div>
                        <div>100</div>
                        <div>The labels in square brackets are irrelevant.</div>
                    </div>} className="ml-2">
                        <InfoOutlined color="secondary" fontSize="small"/>
                    </Tooltip>
                </div>
                <TextField
                    margin="dense"
                    fullWidth
                    autoFocus
                    id="name"
                    label="Name"
                    variant="standard"
                    value={name}
                    onChange={handleName}
                />
                <TextField
                    margin="dense"
                    id="symbol"
                    label="Symbol"
                    variant="standard"
                    value={symbol}
                    onChange={handleSymbol}
                />
                <Divider textAlign="left" className="mt-4 mb-1">
                    <div className="flex items-center">
                        <div>Source and Target</div>
                        <Tooltip title={<div>
                            <div>Enter as a list of space or comma separated values, e.g.</div>
                            <div>a,b,c,d,e</div>
                            <div>Or choose a size to generate basic identifiers.</div>
                            <div>Homogeneous ensures the source and target are equal.</div>
                        </div>} className="ml-1">
                            <InfoOutlined color="secondary" fontSize="small"/>
                        </Tooltip>
                    </div>
                </Divider>
                <FormControl>
                    <RadioGroup
                        row
                        name="source-target-radio"
                        value={sourceTargetRadio}
                        onChange={handleSourceTargetRadio}
                        className="select-none"
                    >
                        <FormControlLabel value="manual" control={<Radio />} label="Manually Enter" />
                        <FormControlLabel value="auto" control={<Radio />} label="Automatically Generate" />
                    </RadioGroup>
                </FormControl>
                <TextField
                    disabled={sourceTargetRadio === 'auto'}
                    margin="dense"
                    fullWidth
                    id="source"
                    label="Source Elements"
                    variant="standard"
                    value={source}
                    onChange={handleSource}
                />
                <TextField
                    disabled={sourceTargetRadio === 'auto'}
                    margin="dense"
                    fullWidth
                    id="target"
                    label="Target Elements"
                    variant="standard"
                    value={target}
                    onChange={handleTarget}
                />
                <div className={`flex items-end ${sourceTargetRadio == 'manual' ? 'disabled-color' : ''}`}>
                    <p className="mr-2">Size:</p>
                    <TextField
                        disabled={sourceTargetRadio === 'manual'}
                        margin="dense"
                        id="rows"
                        label="Source Size"
                        variant="standard"
                        type="number"
                        InputLabelProps={{
                            shrink: true,
                        }}
                        value={rows}
                        onChange={handleRows}
                    />
                    <p className="mx-2">×</p>
                    <TextField
                        disabled={sourceTargetRadio === 'manual'}
                        margin="dense"
                        id="cols"
                        label="Target Size"
                        variant="standard"
                        type="number"
                        InputLabelProps={{
                            shrink: true,
                        }}
                        value={cols}
                        onChange={handleCols}
                    />
                </div>
                <FormGroup>
                    <FormControlLabel
                        control={<Checkbox
                            disabled={sourceTargetRadio === 'manual'}
                            checked={homogeneous}
                            onChange={handleHomogeneous}
                        />}
                        className="select-none"
                        label="Homogeneous"
                    />
                </FormGroup>
                <br/>
                <Divider textAlign="left" className="mb-1">
                    <div className="flex items-center">
                        <div>Relation Data</div>
                        <Tooltip title={<div>
                                            <div>Enter as a grid, e.g.</div>
                                            <div>010</div>
                                            <div>110</div>
                                            <div>100</div>
                                            <div>Or enter pairs, e.g.</div>
                                            <div>a b</div>
                                            <div>b a</div>
                                            <div>b b</div>
                                            <div>c a</div>
                                            <div>Or auto generate at a set density.</div>
                                        </div>} className="ml-1">
                            <InfoOutlined color="secondary" fontSize="small"/>
                        </Tooltip>
                    </div>
                </Divider>
                <FormControl>
                    <RadioGroup
                        row
                        name="data-radio"
                        value={dataRadio}
                        onChange={handleDataRadio}
                        className="select-none"
                    >
                        <FormControlLabel value="manual" control={<Radio />} label="Manually Enter" />
                        <FormControlLabel value="auto" control={<Radio />} label="Automatically Generate" />
                    </RadioGroup>
                </FormControl>
                <TextField
                    disabled={dataRadio === 'auto'}
                    fullWidth
                    id="data"
                    label="Relation Data"
                    multiline
                    rows={4}
                    variant="standard"
                    value={data}
                    onChange={handleData}
                />
                <TextField
                    disabled={dataRadio === 'manual'}
                    margin="dense"
                    id="density"
                    label="Density (0-1)"
                    variant="standard"
                    type="number"
                    InputLabelProps={{
                        shrink: true,
                    }}
                    value={density}
                    onChange={handleDensity}
                />
                { showError && <div className="mt-1 text-red-500">Bad Format</div>}
            </DialogContent>
            <DialogActions>
                <Button onClick={handleCancel}>Cancel</Button>
                <Button onClick={handleAdd}>Add</Button>
            </DialogActions>
        </Dialog>
    );
}

export default AddRelation;