import React, {FC, useEffect, useRef, useState} from 'react';


import {Box, Button, CircularProgress, Divider, Skeleton, Tab, Tabs, Tooltip, Typography} from "@mui/material";
import {CalculationResponse, Relation, RelationInfo} from "../types/RelationTypes";
import CalculationBox from "./CalculationBox";
import FCABox from "./FCABox";
import RCABox from "./RCABox";
import RelationService from "../services/RelationService";
import {height, width} from "@mui/system";
import {Download, OpenInNew} from "@mui/icons-material";

type Props = {
    contexts: number[];
    objToObjRelations: number[];
    scalingOperators: string[];
    performLabelReduction: boolean;
}


type ContextData = {
    name: string;
    xml: string;
    poset: any;
}

type RCAStep = {
    contexts: ContextData[];
}

const RCADisplay: FC<Props> = ({contexts, objToObjRelations, scalingOperators, performLabelReduction}) => {
    const [beforeShowLoad, setBeforeShowLoad] = useState(true);
    const [time, setTime] = useState<number | null>(null);
    const [data, setData] = useState<RCAStep[]>([]);

    useEffect(() => {
        const startTime = new Date().getTime();
        const timer = setTimeout(() => setBeforeShowLoad(false), 50);

        RelationService.performRCA(contexts, objToObjRelations, scalingOperators, performLabelReduction).then(
            async response => {
                console.log(response.data)
                const newData: RCAStep[] = [];
                for (let result of response.data.results) {
                    const imageRes = await RelationService.getPoset(result.posetId);
                    const src = URL.createObjectURL(imageRes.data);
                    if (newData[result.step]) {
                        newData[result.step].contexts.push({
                            name: result.name,
                            xml: result.xml,
                            poset: src,
                        });
                    } else {
                        newData[result.step] = {
                            contexts: [
                                {
                                    name: result.name,
                                    xml: result.xml,
                                    poset: src
                                }
                            ]
                        };
                    }
                    console.log(newData)
                }
                setData(newData);
                const endTime = new Date().getTime();
                setTime(Math.round((endTime - startTime) / 10) / 100);
            }
        ).catch(e => {
            console.log(e)
        });
        return () => clearTimeout(timer);
    }, [contexts]);

    const openImage = (src: any) => {
        if (src) window.open(src);
    }

    const downloadXML = async (fileName: string, xml: string) => {
        if (xml) {
            const file = new Blob([xml], {type: 'text/plain'});
            const element = document.createElement("a");
            element.href = URL.createObjectURL(file);
            element.download = fileName + ".xml";
            document.body.appendChild(element);
            element.click();
        }
    }

    return (
        <div className="">{
            data.length ? (
                    <div className="px-5 pb-1">
                        <div className="w-full flex items-center -mb-4">
                            <div className="flex"><p className="font-bold mr-1">RCA</p></div>
                            <div className="flex-grow"></div>
                            <div className="italic">~{time}s</div>
                        </div>
                        {
                            data.map((rcaStep, stepIdx) => (
                                <div className="flex flex-col items-center mb-2">
                                    <div className="">Step {stepIdx}</div>
                                    <div className="flex flex-col">
                                        {
                                            rcaStep.contexts.map((contextData: ContextData) => (
                                                <div className="p-2 -ml-32 flex justify-center items-center">
                                                    <div className="min-w-[150px] text-right">{contextData.name}</div>
                                                    <Button className="ml-3" variant="outlined" endIcon={<OpenInNew/>} onClick={() => openImage(contextData.poset)}>View AOC-poset</Button>
                                                    <Button className="ml-3" variant="outlined" startIcon={<Download/>} onClick={() => downloadXML(`Step ${stepIdx} ${contextData.name}`, contextData.xml)}>Download XML</Button>
                                                </div>
                                            ))
                                        }
                                    </div>
                                </div>
                            ))
                        }
                    </div>
                )
                :
                (!beforeShowLoad &&
                    <div className="flex justify-center p-5">
                        <CircularProgress />
                    </div>
                )
        }
            <Divider flexItem/>
        </div>
    );
}

export default RCADisplay;