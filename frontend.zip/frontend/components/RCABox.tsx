import React, {FC, ReactElement, useState} from 'react';
import {RelationInfo} from "../types/RelationTypes";
import {
    Button,
    Checkbox,
    Fab,
    FormControl, FormControlLabel, FormGroup,
    InputLabel, ListItemText,
    MenuItem,
    OutlinedInput,
    Select, SelectChangeEvent,
    TextField,
    Tooltip
} from "@mui/material";
import DeleteIcon from '@mui/icons-material/Delete';
import {Download, GridOn, Help, HelpOutline, InfoOutlined, QuestionMark, Upload} from "@mui/icons-material";
import RelationService from "../services/RelationService";
import AddIcon from "@mui/icons-material/Add";
import AddRelation from "./AddRelation";
import CalculationHelp from "./CalculationHelp";
import RCAHelp from "./RCAHelp";
import FCADisplay from "./FCADisplay";
import RCADisplay from "./RCADisplay";

type Props = {
    relations: RelationInfo[];
    loadRelations(): void;
    addToFeed(element: ReactElement): void;
}

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
        },
    },
};

const RCABox: FC<Props> = ({relations, loadRelations, addToFeed}) => {
    const [helpOpen, setHelpOpen] = React.useState(false);
    const handleClickHelpOpen = () => {
        setHelpOpen(true);
    };
    const handleHelpClose = () => {
        setHelpOpen(false);
    };

    const [kRelation, setKRelation] = React.useState<string[]>([]);
    const handleKRelationChange = (event: SelectChangeEvent<typeof kRelation>) => {
        const {
            target: { value },
        } = event;
        setKRelation(
            typeof value === 'string' ? value.split(',') : value,
        );
    };

    const [rRelation, setRRelation] = React.useState<string[]>([]);
    const handleRRelationChange = (event: SelectChangeEvent<typeof kRelation>) => {
        const {
            target: { value },
        } = event;
        let newValue: string[] = typeof value === 'string' ? value.split(',') : value;
        setRRelation(newValue);
        setScalingOperators(Array(24).fill('EXISTENTIAL'))
    };

    const perform = async () => {
        const contexts: number[] = relations.filter(r => kRelation.includes(r.name)).map(r => r.id);
        const objToObjRelations: number[] = relations.filter(r => rRelation.includes(r.name)).map(r => r.id);
        addToFeed(<RCADisplay contexts={contexts} objToObjRelations={objToObjRelations} scalingOperators={scalingOperators} performLabelReduction={labelReduction} key={new Date().getTime()}></RCADisplay>);
        setKRelation([]);
        setRRelation([]);
        setScalingOperators([]);
    }

    const [scalingOperators, setScalingOperators] = useState<string[]>([]);

    const handleOperator = async (event: SelectChangeEvent, idx: number) => {
        const newValue = event.target.value as string;

        let newScalingOperators = [...scalingOperators];
        newScalingOperators[idx] = newValue;
        setScalingOperators(newScalingOperators);
    };

    const [labelReduction, setLabelReduction] = React.useState(false);
    const handleLabelReduction = (event: React.ChangeEvent<HTMLInputElement>) => {
        const newValue = event.target.checked;
        setLabelReduction(newValue);
    };

    // const [allSteps, setAllSteps] = React.useState(false);
    // const handleAllSteps = (event: React.ChangeEvent<HTMLInputElement>) => {
    //     const newValue = event.target.checked;
    //     setAllSteps(newValue);
    // };

    return (
        <div className="min-h-[60px]">
            <RCAHelp open={helpOpen} onClose={handleHelpClose}/>
            <div className="flex items-center">
                <FormControl fullWidth>
                    <InputLabel id="k-relations-checkbox-label">Object-Attribute Relations</InputLabel>
                    <Select
                        labelId="k-relations-checkbox-label"
                        id="k-relations-checkbox"
                        multiple
                        value={kRelation}
                        onChange={handleKRelationChange}
                        input={<OutlinedInput label="Object-Attribute Relations" />}
                        renderValue={(selected) => selected.join(', ')}
                        MenuProps={MenuProps}
                    >
                        {relations.map((relation) => (
                            <MenuItem disabled={rRelation.includes(relation.name)} key={relation.id} value={relation.name}>
                                <Checkbox checked={kRelation.indexOf(relation.name) > -1} />
                                <ListItemText primary={relation.name} />
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>
                <FormControl fullWidth className="ml-3">
                    <InputLabel id="r-relations-checkbox-label">Object-Object Relations</InputLabel>
                    <Select
                        labelId="r-relations-checkbox-label"
                        id="r-relations-checkbox"
                        multiple
                        value={rRelation}
                        onChange={handleRRelationChange}
                        input={<OutlinedInput label="Object-Object Relations" />}
                        renderValue={(selected) => selected.join(', ')}
                        MenuProps={MenuProps}
                    >
                        {relations.map((relation) => (
                            <MenuItem disabled={kRelation.includes(relation.name)} key={relation.id} value={relation.name}>
                                <Checkbox checked={rRelation.indexOf(relation.name) > -1} />
                                <ListItemText primary={relation.name} />
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>
                <Button className="mx-3" variant="contained" onClick={perform}>
                    Go
                </Button>
                <Button className="ml-3 shrink-0" variant="outlined" endIcon={<InfoOutlined />} onClick={handleClickHelpOpen} color="secondary">Help</Button>
            </div>
            <div className="py-2">
                {/*<FormGroup>*/}
                {/*    <FormControlLabel*/}
                {/*        control={<Checkbox*/}
                {/*            checked={allSteps}*/}
                {/*            onChange={handleAllSteps}*/}
                {/*        />}*/}
                {/*        className="select-none"*/}
                {/*        label="Calculate All Steps Now"*/}
                {/*    />*/}
                {/*</FormGroup>*/}
                <div className="flex items-center">
                    <FormGroup>
                        <FormControlLabel
                            control={<Checkbox
                                checked={labelReduction}
                                onChange={handleLabelReduction}
                            />}
                            className="select-none"
                            label="Perform Label Reduction"
                        />
                    </FormGroup>
                    <Tooltip title={<div>
                        Do not show attributes in the final step's AOC-posets that refer to sub-concepts of concepts referred to by other attributes in the concept.
                    </div>} className="-ml-2"><InfoOutlined color="secondary" fontSize="small"></InfoOutlined></Tooltip>
                </div>
                <div className="flex flex-wrap">
                    {rRelation.map((rRel, i) => (
                        <FormControl fullWidth className="mx-3 mt-3 max-w-[300px]">
                            <InputLabel id={`scaling-operator-label${i}`}>{rRel} Scaling Operator</InputLabel>
                            <Select
                                labelId={`scaling-operator-label${i}`}
                                value={scalingOperators[i]}
                                onChange={e => handleOperator(e, i)}
                                label={`${rRel} Scaling Operator`}
                            >
                                <MenuItem value={'EXISTENTIAL'}>Existential</MenuItem>
                                <MenuItem value={'UNIVERSAL_STRICT'}>Universal Strict</MenuItem>
                            </Select>
                        </FormControl>
                    ))
                    }
                </div>
            </div>
        </div>
    );
}

export default RCABox;