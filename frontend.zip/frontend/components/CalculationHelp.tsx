import React, {FC} from 'react';

type Props = {
    onClose(): void;
    open: boolean;
}

import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle, Divider,
    Fab, FormControl, FormControlLabel, FormLabel, RadioGroup, Radio,
    TextField, Checkbox, FormGroup, TableContainer, Paper, Table, TableHead, TableRow, TableCell, TableBody
} from "@mui/material";
import {Upload} from "@mui/icons-material";
import RelationService from "../services/RelationService";


const CalculationHelp: FC<Props> = ({ onClose, open }) => {
    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>Calculation Help</DialogTitle>
            <DialogContent>
                <DialogContentText>Use each relation's symbol in conjunction with the operations listed below. Example: (~A ; (B ∪ C))ᵀ = D. Equality and Inclusion gives a True/False value. The other operations save the resultant relation.</DialogContentText>
                <TableContainer className="mt-2">
                    <Table size="small">
                        <TableHead>
                            <TableRow>
                                <TableCell align="center">Symbol</TableCell>
                                <TableCell align="center">Operation</TableCell>
                                <TableCell align="center">How to input</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">~A</TableCell>
                                <TableCell align="center">Complement</TableCell>
                                <TableCell align="center">~A or !A or A'</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">Aᵀ</TableCell>
                                <TableCell align="center">Inverse</TableCell>
                                <TableCell align="center">A^T or A^-1</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A ∪ B</TableCell>
                                <TableCell align="center">Union</TableCell>
                                <TableCell align="center">A u B</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A ∩ B</TableCell>
                                <TableCell align="center">Intersection</TableCell>
                                <TableCell align="center">A n B</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A ; B</TableCell>
                                <TableCell align="center">Composition</TableCell>
                                <TableCell align="center">A ; B or A | B</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A = B</TableCell>
                                <TableCell align="center">Equality</TableCell>
                                <TableCell align="center">A = B</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A ⊆ B</TableCell>
                                <TableCell align="center">Inclusion</TableCell>
                                <TableCell align="center">A {'<='} B</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A ⊂ B</TableCell>
                                <TableCell align="center">Proper Inclusion</TableCell>
                                <TableCell align="center">A {'<<'} B</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">sid(A)</TableCell>
                                <TableCell align="center">Source Identity</TableCell>
                                <TableCell align="center">sid(A)</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">tid(A)</TableCell>
                                <TableCell align="center">Target Identity</TableCell>
                                <TableCell align="center">tid(A)</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A - B</TableCell>
                                <TableCell align="center">Difference</TableCell>
                                <TableCell align="center">A - B</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A Δ B</TableCell>
                                <TableCell align="center">Symmetric Difference</TableCell>
                                <TableCell align="center">A /\ B</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A † B</TableCell>
                                <TableCell align="center">Sum</TableCell>
                                <TableCell align="center">A + B</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">Aᵈ</TableCell>
                                <TableCell align="center">Dual</TableCell>
                                <TableCell align="center">A^d</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A⁺</TableCell>
                                <TableCell align="center">Transitive Closure</TableCell>
                                <TableCell align="center">A^+</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A*</TableCell>
                                <TableCell align="center">Reflexive Transitive Closure</TableCell>
                                <TableCell align="center">A*</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A \ B</TableCell>
                                <TableCell align="center">Left Residual</TableCell>
                                <TableCell align="center">A \ B</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">A / B</TableCell>
                                <TableCell align="center">Right Residual</TableCell>
                                <TableCell align="center">A / B</TableCell>
                            </TableRow>
                            <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                <TableCell align="center">syq(A,B)</TableCell>
                                <TableCell align="center">Symmetric Quotient</TableCell>
                                <TableCell align="center">syq(A,B)</TableCell>
                            </TableRow>
                        </TableBody>
                    </Table>
                </TableContainer>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Close</Button>
            </DialogActions>
        </Dialog>
    );
}

export default CalculationHelp;