import React, {FC} from 'react';
import {Relation} from "../types/RelationTypes";
import RelationService from "../services/RelationService";
import { useRouter } from 'next/router';

type Props = {
    relation: Relation;
}

const ShowRelation: FC<Props> = ({ relation }) => {
    // const renderRows = () => {
    //     let matrix: number[][] = Array.from(Array(relation.source.length), _ => Array(relation.target.length).fill(0));
    //     relation.relationPairs.forEach(pair => {
    //         matrix[relation.source.indexOf(pair.source)][relation.target.indexOf(pair.target)] = 1;
    //     });
    //     let txt = "[Lattice]\n" + relation.source.length + "\n" + relation.target.length + "\n[Objects]\n";
    //     relation.source.forEach(s => txt += s + "\n");
    //     txt += "[Attributes]\n";
    //     relation.target.forEach(t => txt += t + "\n");
    //     txt += "[Relation]\n";
    //     for (let i = 0; i < matrix.length; i++) {
    //         for (let j = 0; j < matrix[i].length; j++) {
    //             txt += matrix[i][j] + " ";
    //         }
    //         txt += "\n";
    //     }
    //     const file = new Blob([txt], {type: 'text/plain'});
    //     const element = document.createElement("a");
    //     element.href = URL.createObjectURL(file);
    //     element.download = relation.relationInfo.id + ".txt";
    //     document.body.appendChild(element); // Required for this to work in FireFox
    //     element.click();
    //     let rows: any = [];
    //     return rows;
    //     let headers: any = [];
    //     headers.push(<th/>)
    //     for (let j = 0; j < relation.target.length; j++) {
    //         headers.push(<th className="w-1 h-1 border-none">{relation.target[j]}</th>);
    //     }
    //     rows.push(<tr>{headers}</tr>);
    //     for (let i = 0; i < relation.source.length; i++) {
    //         let cols: any = [];
    //         cols.push(<th className="w-1 h-1 border-none">{relation.source[i]}</th>)
    //         for (let j = 0; j < relation.target.length; j++) {
    //             cols.push(<td key={j} className={"w-1 h-1 border-none " + (matrix[i][j] === 1 ? "bg-black" : "bg-gray-200")}/>);
    //         }
    //         rows.push(<tr key={i}>{cols}</tr>);
    //     }
    //     return rows;
    // };
    //
    // const renderProperties = () => {
    //     let properties: any = [];
    //     for (const property in relation.properties) {
    //         properties.push(<div>{property}: {relation.properties[property] ? '✔' : '✖'}</div>)
    //     }
    //     return properties;
    // }

    return (
        <div className="w-3/4 pl-8">
            <table className="my-2">
                {/*{renderRows()}*/}
            </table>
            <div>
                {/*{renderProperties()}*/}
            </div>
        </div>
    );
}

export default ShowRelation;