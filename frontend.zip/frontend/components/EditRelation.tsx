import React, {FC, useEffect} from 'react';

type Props = {
    relation: RelationInfo;
    onClose(): void;
    open: boolean;
    loadRelations(): void;
}

import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle, Divider,
    Fab, FormControl, FormControlLabel, FormLabel, RadioGroup, Radio,
    TextField, Checkbox, FormGroup
} from "@mui/material";
import {Upload} from "@mui/icons-material";
import RelationService from "../services/RelationService";
import {Relation, RelationInfo} from "../types/RelationTypes";


const EditRelation: FC<Props> = ({ relation, onClose, open, loadRelations }) => {

    const [name, setName] = React.useState(relation.name);
    const handleName = (event: React.ChangeEvent<HTMLInputElement>) => {
        setName(event.target.value);
    };

    const [symbol, setSymbol] = React.useState(relation.symbol);
    const handleSymbol = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSymbol(event.target.value);
    };

    // useEffect(() => {
    //     setName(relation.name);
    //     setSymbol(relation.symbol);
    // }, [relation]);

    // const resetFields = () => {
    //     setName('');
    // }

    const handleCancel = () => {
        handleClose();
        // resetFields();
    };

    const edit = async () => {
        await RelationService.editRelation({
            relationId: relation.id,
            name,
            symbol,
        });
        loadRelations();
        // resetFields();
        handleClose();
    };

    const handleClose = () => {
        onClose();
    };

    return (
        <Dialog open={open} onClose={handleClose}>
            <DialogTitle>Edit Relation</DialogTitle>
            <DialogContent>
                <TextField
                    autoFocus
                    margin="dense"
                    fullWidth
                    id="name"
                    label="Name"
                    variant="standard"
                    value={name}
                    onChange={handleName}
                />
                <TextField
                    margin="dense"
                    id="symbol"
                    label="Symbol"
                    variant="standard"
                    value={symbol}
                    onChange={handleSymbol}
                />
            </DialogContent>
            <DialogActions>
                <Button onClick={handleCancel}>Cancel</Button>
                <Button onClick={edit}>Edit</Button>
            </DialogActions>
        </Dialog>
    );
}

export default EditRelation;