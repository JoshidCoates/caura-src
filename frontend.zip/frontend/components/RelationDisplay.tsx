import React, {FC, useEffect, useRef, useState} from 'react';


import {Box, Button, CircularProgress, Divider, Skeleton, Tab, Tabs, Tooltip, Typography} from "@mui/material";
import {Relation, RelationInfo} from "../types/RelationTypes";
import CalculationBox from "./CalculationBox";
import FCABox from "./FCABox";
import RCABox from "./RCABox";
import RelationService from "../services/RelationService";
import {height, width} from "@mui/system";
import {Download, OpenInNew} from "@mui/icons-material";

type Props = {
    relation: RelationInfo;
}

type Dimensions = {
    width: number;
    height: number;
}

const RelationDisplay: FC<Props> = ({relation}) => {
    const [imageData, setImageData] = useState<string | null>(null);
    const [beforeShowLoad, setBeforeShowLoad] = useState(true);
    const [time, setTime] = useState<number | null>(null);
    const [dimensions, setDimensions] = useState<Dimensions>({width: 0, height: 0});
    const [showInTab, setShowInTab] = useState(false);
    // const imageDiv = useRef();

    useEffect(() => {
        const startTime = new Date().getTime();
        const timer = setTimeout(() => setBeforeShowLoad(false), 50);

        RelationService.getImage(relation.id).then(
            response => {
                const img = document.createElement('img');
                const src = URL.createObjectURL(response.data);
                clearTimeout(timer);
                setImageData(src);
                img.src = src;
                img.onload = function () {
                    setDimensions({width: img.width, height: img.height});
                    if (img.width > 600 || img.height > 400) {
                        setShowInTab(true);
                    }
                }
                const endTime = new Date().getTime();
                setTime(Math.round((endTime - startTime) / 10) / 100);
            }
        );
        return () => clearTimeout(timer);
    }, [relation]);

    const openImage = () => {
        if (imageData) window.open(imageData);
    }

    // const onLoad = (el: any) => {
    //     console.log(el.target.offsetWidth);
    //     setDimensions({
    //         height: el.target.offsetHeight,
    //         width: el.target.offsetWidth
    //     });
    // }

    return (
        <div className="">{
            imageData ? (
                <div className="px-5 pb-1">
                    <div className="w-full flex items-center -mb-4">
                        <div className="flex"><p className="font-bold mr-1">Display Relation:</p><p>{relation.name}</p></div>
                        <div className="flex-grow"></div>
                        {/*{time ?*/}
                            <div className="italic">~{time}s</div>
                            {/*:*/}
                            {/*<Skeleton width="50" height="30"/>*/}
                        {/*}*/}
                    </div>
                    <div className="p-2 flex justify-center">{
                        showInTab ?
                            <Button className="" variant="outlined" endIcon={<OpenInNew/>} onClick={openImage}>Open in new
                                tab</Button>
                            : <img src={imageData} alt={relation.name + ' image'}
                                   className="object-scale-down" height={dimensions.height} width={dimensions.width}/>
                    }
                    </div>
                </div>
            )
            :
            (!beforeShowLoad &&
                <div className="flex justify-center p-5">
                    <CircularProgress />
                </div>
            )
        }
            <Divider flexItem/>
        </div>
    );
}

export default RelationDisplay;