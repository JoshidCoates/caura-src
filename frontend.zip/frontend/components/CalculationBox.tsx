import React, {FC, ReactElement} from 'react';
import {RelationInfo} from "../types/RelationTypes";
import {Button, Fab, TextField, Tooltip} from "@mui/material";
import DeleteIcon from '@mui/icons-material/Delete';
import {Download, GridOn, Help, HelpOutline, InfoOutlined, QuestionMark, Upload} from "@mui/icons-material";
import RelationService from "../services/RelationService";
import AddIcon from "@mui/icons-material/Add";
import AddRelation from "./AddRelation";
import CalculationHelp from "./CalculationHelp";
import FCADisplay from "./FCADisplay";
import CalculationDisplay from "./CalculationDisplay";

type Props = {
    relations: RelationInfo[];
    loadRelations(): void;
    addToFeed(element: ReactElement): void;
}


const CalculationBox: FC<Props> = ({relations, loadRelations, addToFeed}) => {
    const [calculation, setCalculation] = React.useState('');
    const handleCalculation = (event: React.ChangeEvent<HTMLInputElement>) => {
        let text = event.target.value;
        text = text.replace('u', '∪');
        text = text.replace('n', '∩');
        text = text.replace('!', '~');
        text = text.replace(/([A-Z])'/, "~$1");
        text = text.replaceAll('/\\', 'Δ');
        text = text.replace('^+', '⁺');
        text = text.replace('+', '†');
        text = text.replace('|', ';');
        // text = text.replace(';', '⨾');
        // text = text.replace('.', '∘');
        text = text.replace('^-1', 'ᵀ');
        text = text.replace('^T', 'ᵀ');
        text = text.replace('-1', 'ᵀ');
        text = text.replace('^d', 'ᵈ');
        text = text.replace('<=', '⊆');
        text = text.replace('<<', '⊂');
        setCalculation(text);
    };

    const [helpOpen, setHelpOpen] = React.useState(false);
    const handleClickHelpOpen = () => {
        setHelpOpen(true);
    };
    const handleHelpClose = () => {
        setHelpOpen(false);
    };

    const perform = () => {
        if (calculation.length) {
            addToFeed(<CalculationDisplay calculation={calculation} loadRelations={loadRelations} key={new Date().getTime()}></CalculationDisplay>);
            setCalculation('');
        }
    }

    return (
        <div className="mb-1">
            <CalculationHelp open={helpOpen} onClose={handleHelpClose}/>
            <div className="flex items-center">
                <TextField
                    className="mt-1"
                    autoFocus
                    margin="dense"
                    fullWidth
                    id="calculation"
                    label="Calculation"
                    variant="standard"
                    value={calculation}
                    onChange={handleCalculation}
                />
                <Button className="mx-3" variant="contained" onClick={perform}>
                    Go
                </Button>
                <Button className="ml-3 shrink-0" variant="outlined" endIcon={<InfoOutlined />} onClick={handleClickHelpOpen} color="secondary">Help</Button>
            </div>
        </div>
    );
}

export default CalculationBox;