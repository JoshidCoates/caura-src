import React, {FC} from 'react';

type Props = {
    onClose(): void;
    open: boolean;
}

import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle, Divider,
    Fab, FormControl, FormControlLabel, FormLabel, RadioGroup, Radio,
    TextField, Checkbox, FormGroup
} from "@mui/material";
import {Upload} from "@mui/icons-material";
import RelationService from "../services/RelationService";


const RCAHelp: FC<Props> = ({ onClose, open }) => {
    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>RCA Help</DialogTitle>
            <DialogContent>
                <DialogContentText>Perform Relation Concept Analysis (RCA) on a Relational Context Family (RCF). As with FCA, AOC-posets are used to visualise concepts.</DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Close</Button>
            </DialogActions>
        </Dialog>
    );
}

export default RCAHelp;