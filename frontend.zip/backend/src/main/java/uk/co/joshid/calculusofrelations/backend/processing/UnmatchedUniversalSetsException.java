package uk.co.joshid.calculusofrelations.backend.processing;

public class UnmatchedUniversalSetsException extends RuntimeException {
}
