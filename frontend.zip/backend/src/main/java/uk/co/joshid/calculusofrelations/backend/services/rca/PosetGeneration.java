package uk.co.joshid.calculusofrelations.backend.services.rca;

import lombok.Data;

import java.util.List;

@Data
public class PosetGeneration {
    private final boolean[][] edges;
    private final String[] source;
    private final String[] target;
    private final List<Concept> concepts;
}
