package uk.co.joshid.calculusofrelations.backend.repository;

import org.springframework.stereotype.Repository;
import uk.co.joshid.calculusofrelations.backend.exception.RelationNotFound;
import uk.co.joshid.calculusofrelations.backend.model.Relation;
import uk.co.joshid.calculusofrelations.backend.model.RelationInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class RelationRepository {
    private final List<Relation> relations = new ArrayList<>();

    public Optional<Relation> findById(int id) {
        return relations.stream().filter(r -> r.getRelationInfo().getId() == id).findFirst();
    }

    public Optional<RelationInfo> findInfoById(int id) {
        return relations.stream().filter(r -> r.getRelationInfo().getId() == id).findFirst().map(Relation::getRelationInfo);
    }

    public Optional<Relation> findBySymbol(char symbol) {
        return relations.stream().filter(r -> r.getRelationInfo().getSymbol() == symbol).findFirst();
    }

    public List<Relation> findAll() {
        return relations;
    }

    public List<RelationInfo> findAllInfo() {
        return relations.stream().map(Relation::getRelationInfo).toList();
    }

    public Relation save(Relation relation) {
        relations.add(relation);
        return relation;
    }

    public void delete(Relation relation) {
        relations.remove(relation);
    }

    public void delete(int relationId) {
        relations.remove(findById(relationId).orElseThrow(RelationNotFound::new));
    }

    public void deleteAll() {
        relations.clear();
    }


}
