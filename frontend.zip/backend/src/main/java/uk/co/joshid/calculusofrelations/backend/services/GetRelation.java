package uk.co.joshid.calculusofrelations.backend.services;

import lombok.RequiredArgsConstructor;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Service;
import uk.co.joshid.calculusofrelations.backend.exception.RelationNotFound;
import uk.co.joshid.calculusofrelations.backend.model.*;
import uk.co.joshid.calculusofrelations.backend.processing.HeatChart;
import uk.co.joshid.calculusofrelations.backend.processing.RelationType;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;
import uk.co.joshid.calculusofrelations.backend.repository.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class GetRelation {
    // todo use for getting bitmap view, properties, etc.

    private final RelationRepository relationRepository;

    public Relation execute(char symbol) {
        return relationRepository.findBySymbol(symbol).orElseThrow(RelationNotFound::new);
    }

    public String download(int relationId) {
        Relation relation = relationRepository.findById(relationId).orElseThrow(RelationNotFound::new);
        StringBuilder text = new StringBuilder("[Lattice]\n");
        text.append(relation.getRelationInfo().getRows())
                .append("\n")
                .append(relation.getRelationInfo().getCols())
                .append("\n[Objects]\n");
        for (String object : relation.getRelation().getSource()) {
            text.append(object).append("\n");
        }
        text.append("[Attributes]\n");
        for (String attribute : relation.getRelation().getTarget()) {
            text.append(attribute).append("\n");
        }
        text.append("[Relation]\n").append(relation.getRelation().getMatrixText());
        return text.toString();
    }

    public byte[] image(int relationId) throws IOException {
        Relation relation = relationRepository.findById(relationId).orElseThrow(RelationNotFound::new);




// Step 1: Create our heat map chart using our data.
        HeatChart map = new HeatChart(relation.getRelation().getDoubleMatrix());
        map.setAxisValuesFont(new Font("Sans-Serif", Font.PLAIN, 14));

// Step 2: Customise the chart.
        map.setXValuesHorizontal(relation.getRelation().getTarget().stream().noneMatch(s -> s.length() > 1));
        map.setYValues(relation.getRelation().getSource().toArray());
        map.setXValues(relation.getRelation().getTarget().toArray());
        map.saveToFile(new File("java-heat-chart.jpeg"));


// Step 3: Output the chart to a file.
        BufferedImage image = (BufferedImage) map.getChartImage();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(image, "jpeg", baos);
        byte[] bytes = baos.toByteArray();
        return bytes;

//        InputStream in = getClass()
//                .getResourceAsStream("java-heat-chart.png");
//        return IOUtils.toByteArray(in);
    }
}
