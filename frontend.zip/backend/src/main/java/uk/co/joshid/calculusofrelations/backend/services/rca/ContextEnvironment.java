package uk.co.joshid.calculusofrelations.backend.services.rca;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import uk.co.joshid.calculusofrelations.backend.processing.RelationType;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.*;
import uk.co.joshid.calculusofrelations.backend.services.PosetBuilder;

import java.util.*;
import java.util.stream.Collectors;

@AllArgsConstructor
@Getter
@Setter
public class ContextEnvironment {

    private List<ContextAndPoset> contexts; // object sets must be distinct
    private Map<IRelation, ObjRelationData> objToObjRelations; // must use object sets from contexts
    private PosetBuilder posetBuilder;

    private List<IRelation> rel(ContextAndPoset context) {
        return objToObjRelations.keySet().stream().filter(r -> r.getSource().equals(context.originalContext().getSource())).toList();
    }

    public List<List<ContextAndPoset>> execute(boolean reduceLabels, RelationType relationType) {
        List<List<ContextAndPoset>> allContexts = new ArrayList<>();
        allContexts.add(contexts);
        boolean completed = false;
        int count = 0;
        while (!completed) {
            completed = true;
            List<ContextAndPoset> scaledContexts = new ArrayList<>();
            for (ContextAndPoset context : contexts) {
                ContextAndPoset scaledContext = scaleContext(context, relationType);
                scaledContexts.add(scaledContext);
                if (!scaledContext.equals(context)) {
//                if (count < 7) {
                    completed = false;
                    System.out.println(count + " " + context.name() + " not equal");
                } else {
                    System.out.println(count + " " + context.name() + " equal");
                }
            }
            if (!completed) allContexts.add(scaledContexts);
            count++;
            contexts = scaledContexts;
        }

        return reduceLabels ? performLabelReduction(allContexts) : allContexts;
//        List<ContextAndLattice> scaledContexts = new ArrayList<>();
//        for (ContextAndLattice context : contexts) {
//            boolean halt = false;
//            while (!halt) {
//                ContextAndLattice scaledContext = scaleContext(context);
//                if (scaledContext.equals(context)) {
//                    scaledContexts.add(context);
//                    halt = true;
//                }
//            }
//        }
//        return scaledContexts;
    }

    public ContextAndPoset scaleContext(ContextAndPoset context, RelationType relationType) {     // will need to use eoprelation for union to make scaled context
        IRelation newContext = context.originalContext();
        List<IRelation> relK = rel(context);
        for (IRelation objRelation : relK) {

            ContextAndPoset associatedCxtAndPoset = contexts.stream().filter(cxt -> cxt.originalContext().getSource().equals(objRelation.getTarget())).findFirst().orElseThrow(RuntimeException::new); // todo make actual exception
            ObjRelationData objRelationData = objToObjRelations.get(objRelation);
            ScalingOperator scalingOperator = objRelationData.getScalingOperator();

            HashSet<String> objectSet = context.originalContext().getSource();
            HashSet<String> attributeSet = associatedCxtAndPoset.poset().getConcepts().stream().map(c -> scalingOperator.toAttributeString(c, objRelationData, associatedCxtAndPoset.name())).collect(Collectors.toCollection(HashSet::new));
            HashSet<SPair> pairs = new HashSet<>();
            for (String o : objectSet) {
                IRelation oRange = objRelation.getElRange(o);
                for (Concept concept : associatedCxtAndPoset.poset().getConcepts()) {
                    if (scalingOperator.matchesConstraint(oRange, concept)) {
                        pairs.add(new SPair(o, scalingOperator.toAttributeString(concept, objRelationData, associatedCxtAndPoset.name())));
                    }

                }
            }
            
            IRelation derivedContext = switch (relationType) {
                case EO_PAIR_RELATION -> new EOPRelation(new SFormat(objectSet, attributeSet), new RSet(pairs));
                case PAIR_RELATION, SHARED_SET_RELATION -> null;
                case EO_SHARED_SET_RELATION -> new EOSSRelation(new SFormat(objectSet, attributeSet), new RSet(pairs));
            };
            newContext = newContext.union(derivedContext);

        }

        StringBuilder text = new StringBuilder();
        text.append("\n[Objects]\n");
        for (String object : newContext.getSource()) {
            text.append(object).append("\n");
        }
        text.append("[Attributes]\n");
        for (String attribute : newContext.getTarget()) {
            text.append(attribute).append("\n");
        }
        text.append("[Relation]\n").append(newContext.getMatrixText());
        String str = text.toString();
        System.out.println(context.name());
        System.out.println(context.step());
        System.out.println(str);
        System.out.println();
//        System.out.println(context.lattice().getName());
        PosetGeneration poset = posetBuilder.execute(newContext, context.name());
        renameConcepts(context, poset);
//        System.out.println(posetBuilder.buildDot(lg));
        return new ContextAndPoset(context.originalContext(), newContext, poset, context.name(), context.step() + 1);
    }

    private void renameConcepts(ContextAndPoset prevContext, PosetGeneration newPoset) {

        HashMap<HashSet<String>, Concept> extentMapping = new HashMap<>();
        newPoset.getConcepts().forEach(c -> extentMapping.put(c.getObjects().getDomain(), c));

        List<HashSet<String>> extents = new ArrayList<>(extentMapping.keySet().stream().toList());
        extents.sort(new ExtentSorter());

        for (int i = 0; i < extents.size(); i++) {
            extentMapping.get(extents.get(i)).setName("c_" + prevContext.name() + i);
        }

//        HashMap<Concept, String> newNames = new HashMap<>();
//        for (Concept oldConcept : prevContext.poset().getConcepts()) {
//            for (Concept newConcept : newPoset.getConcepts()) {
//                if (newConcept.getObjects().equals(oldConcept.getObjects()) && newConcept.getAttributes().equals(oldConcept.getAttributes())) {
//                    newNames.put(newConcept, oldConcept.getName());
//                }
//            }
//        }
//        int count = 0;
//        for (Concept newConcept : newPoset.getConcepts()) {
//            String newName = newNames.get(newConcept);
//            if (newName == null) {
//                newConcept.setName("c_" + prevContext.name() + (prevContext.poset().getConcepts().size() + count++));
//            } else {
//                newConcept.setName(newName);
//            }
//
//        }
//        return newPoset;
    }

    static class ExtentSorter implements Comparator<HashSet<String>> {
        public int compare(HashSet<String> a, HashSet<String> b) {
            if (a.equals(b)) return 0;
            if (a.size() != b.size()) return a.size() - b.size();
            for (String aEl : a) {
                if (!b.contains(aEl)) return 1;
            }
            return -1;
        }
    }

    private List<List<ContextAndPoset>> performLabelReduction(List<List<ContextAndPoset>> contexts) {
        List<ContextAndPoset> finalStep = contexts.get(contexts.size() - 1);



        HashMap<String, List<String>> conceptParents = new HashMap<>();
        for (ContextAndPoset finalContext : finalStep) {
            List<Concept> poset = finalContext.poset().getConcepts();
            for (int i = 0; i < poset.size(); i++) {
                for (int j = i + 1; j < poset.size(); j++) {
                    if (poset.get(i).getAttributes().isProperSubsetOf(poset.get(j).getAttributes())) {
                        if (conceptParents.get(poset.get(i).getName()) == null) {
                            conceptParents.put(poset.get(i).getName(), new ArrayList<>(List.of(poset.get(j).getName())));
                        } else {
                            conceptParents.get(poset.get(i).getName()).add(poset.get(j).getName());
                        }
                    } else if (poset.get(j).getAttributes().isProperSubsetOf(poset.get(i).getAttributes())) {
                        if (conceptParents.get(poset.get(j).getName()) == null) {
                            conceptParents.put(poset.get(j).getName(), new ArrayList<>(List.of(poset.get(i).getName())));
                        } else {
                            conceptParents.get(poset.get(j).getName()).add(poset.get(i).getName());
                        }
                    }
                }
            }


        }

        for (ContextAndPoset finalContext : finalStep) {
            for (Concept concept : finalContext.poset().getConcepts()) {
                List<String> aToRemove = new ArrayList<>();
                for (String attribute : concept.getA()) {
                    String[] parts = attribute.split(": ");
                    if (parts.length == 2) {
                        if (conceptParents.get(parts[1]) != null) {
                            for (String parent : conceptParents.get(parts[1])) {
                                if (concept.getA().contains(parts[0] + ": " + parent)) {
                                    aToRemove.add(attribute);
                                }
                            }
                        }
                    }
                }
                concept.getA().removeAll(aToRemove);
            }
        }

        contexts.set(contexts.size() - 1, finalStep);
        return  contexts;
    }





}
