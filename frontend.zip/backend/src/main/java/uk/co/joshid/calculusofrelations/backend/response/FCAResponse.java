package uk.co.joshid.calculusofrelations.backend.response;

public record FCAResponse(byte[] latticeImage, String xml) {
}
