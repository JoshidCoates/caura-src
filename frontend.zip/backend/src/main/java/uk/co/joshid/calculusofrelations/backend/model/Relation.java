package uk.co.joshid.calculusofrelations.backend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;

@Data
@AllArgsConstructor
public class Relation {
    private RelationInfo relationInfo;
    private IRelation relation;
}
