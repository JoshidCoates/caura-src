package uk.co.joshid.calculusofrelations.backend.services.rca;

import java.util.HashSet;

public class HashSetPlus<T> extends HashSet<T> {


}
