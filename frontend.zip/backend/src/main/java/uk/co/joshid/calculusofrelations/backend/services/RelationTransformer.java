package uk.co.joshid.calculusofrelations.backend.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.joshid.calculusofrelations.backend.model.*;
import uk.co.joshid.calculusofrelations.backend.processing.RelationType;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.*;
import uk.co.joshid.calculusofrelations.backend.repository.*;

import java.util.HashSet;

@Deprecated
@Service
@RequiredArgsConstructor
public class RelationTransformer {

//    private final RelationSPairRepository relationSPairRepository;
//    private final RelationInfoRepository relationInfoRepository;
//    private final UniversalSetElementRepository universalSetElementRepository;
//    private final UniversalSetRepository universalSetRepository;
//
//    public PRelation toPRelation(HashSet<RelationSPair> relationPairs,
//                                  HashSet<String> source,
//                                  HashSet<String> target) {
////        System.out.println("Get 4.5");
////        System.out.println(System.currentTimeMillis());
//        return new PRelation(new Format(source, target), new RSet(relationPairs.stream().map(relationPair -> {
////            System.out.println(System.currentTimeMillis());
//            return new SPair(relationPair.getSource(), relationPair.getTarget());
//        }).toList()));
//    }
//
//    public PRelation toPRelation(Relation relation) {
//        return toPRelation(relation.relationPairs(), relation.source(), relation.target());
//    }
//
//    public EOPRelation toEOPRelation(HashSet<RelationSPair> relationPairs,
//                                 HashSet<String> source,
//                                 HashSet<String> target) {
//        return new EOPRelation(new Format(source, target), new RSet(relationPairs.stream().map(relationPair -> new SPair(relationPair.getSource(), relationPair.getTarget())).toList()));
//    }
//
//    public EOPRelation toEOPRelation(Relation relation) {
//        return toEOPRelation(relation.relationPairs(), relation.source(), relation.target());
//    }
//
//    public IRelation toIRelation(Relation relation, RelationType relationType) {
//        if (relationType == RelationType.PAIR_RELATION) {
//            return toPRelation(relation);
//        } else if (relationType == RelationType.EO_PAIR_RELATION) {
//            return toEOPRelation(relation);
//        } else {
//            return null;
//        }
//    }
//
//    public IRelation toIRelation(HashSet<RelationSPair> relationPairs,
//                                 HashSet<String> source,
//                                 HashSet<String> target, RelationType relationType) {
//        if (relationType == RelationType.PAIR_RELATION) {
//            return toPRelation(relationPairs, source, target);
//        } else if (relationType == RelationType.EO_PAIR_RELATION) {
//            return toEOPRelation(relationPairs, source, target);
//        } else {
//            return null;
//        }
//    }
//
//    public RelationInfo saveIRelation(IRelation pRelation, char symbol, String name) {
//        RelationInfo relationInfo = relationInfoRepository.save(new RelationInfo(name, symbol));
//        UniversalSet source = universalSetRepository.save(new UniversalSet(relationInfo.getId(), true));
//        UniversalSet target = universalSetRepository.save(new UniversalSet(relationInfo.getId(), false));
//        pRelation.getFormat().getSource().forEach(sourceEl -> universalSetElementRepository.save(new UniversalSetElement(source.getId(), sourceEl)));
//        pRelation.getFormat().getTarget().forEach(targetEl -> universalSetElementRepository.save(new UniversalSetElement(target.getId(), targetEl)));
//        pRelation.getPairs().forEach(pair -> relationSPairRepository.save(new RelationSPair(relationInfo.getId(), pair.getSourceEl(), pair.getTargetEl())));
//        return relationInfo;
//    }

}
