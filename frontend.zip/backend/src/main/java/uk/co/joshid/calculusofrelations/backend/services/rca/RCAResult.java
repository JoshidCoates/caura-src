package uk.co.joshid.calculusofrelations.backend.services.rca;

public record RCAResult(String name, int step, String xml, int posetId) {
}
