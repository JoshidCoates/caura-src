package uk.co.joshid.calculusofrelations.backend.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.joshid.calculusofrelations.backend.exception.CalculationBadFormat;
import uk.co.joshid.calculusofrelations.backend.model.Relation;
import uk.co.joshid.calculusofrelations.backend.model.RelationInfo;
import uk.co.joshid.calculusofrelations.backend.processing.RelationType;
import uk.co.joshid.calculusofrelations.backend.processing.UnmatchedUniversalSetsException;
import uk.co.joshid.calculusofrelations.backend.processing.calculation.BooleanCalculationResult;
import uk.co.joshid.calculusofrelations.backend.processing.calculation.Calculation;
import uk.co.joshid.calculusofrelations.backend.processing.calculation.CalculationResult;
import uk.co.joshid.calculusofrelations.backend.processing.calculation.RelationCalculationResult;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.PRelation;
import uk.co.joshid.calculusofrelations.backend.repository.RelationRepository;
import uk.co.joshid.calculusofrelations.backend.repository.SessionRepository;

@Service
@RequiredArgsConstructor
public class PerformCalculation {

    private final SymbolService symbolService;
    private final GetRelation getRelation;
    private final RelationRepository relationRepository;
//    private final RelationTransformer relationTransformer;
//    private final SessionRepository sessionRepository;

    public CalculationResult execute(String calculationStr) {
        try {
            Calculation calculation = new Calculation(calculationStr, getRelation);
            if (calculation.getCalculationStr().equals("true")) return new BooleanCalculationResult(true);
            if (calculation.getCalculationStr().equals("false")) return new BooleanCalculationResult(false);
            if (calculation.getStepRelations().size() == 0) throw new CalculationBadFormat();
            IRelation resultRelation = calculation.getStepRelations().get(calculation.getStepRelations().size() - 1).relation();
            char newSymbol = symbolService.getNewSymbol();
            Relation relation = relationRepository.save(new Relation(new RelationInfo(newSymbol + " = " + calculationStr, newSymbol, resultRelation.getSource().size(), resultRelation.getTarget().size()), resultRelation));
            return new RelationCalculationResult(relation);
        } catch (UnmatchedUniversalSetsException e) {
            throw new CalculationBadFormat();
        }
    }

//    public void execute(String calculation) {
//        ArrayList<PRelation> stepRelations = new ArrayList<>();
//        System.out.println(calculation);
//        calculation = calculation.replaceAll("\\s+","");
//        Pattern unionPattern = Pattern.compile("[A-Z]∪[A-Z]");
//        Pattern complementPattern = Pattern.compile("~[A-Z]");
//        Pattern leftResidualPattern = Pattern.compile("[A-Z]\\\\[A-Z]");
//        Pattern rightResidualPattern = Pattern.compile("[A-Z]/[A-Z]"); // todo check this regex works
//        Pattern intersectionPattern = Pattern.compile("[A-Z]∩[A-Z]");
//        Pattern differencePattern = Pattern.compile("[A-Z]-[A-Z]"); // todo check this regex works
//        Pattern symmetricDifferencePattern = Pattern.compile("[A-Z]Δ[A-Z]");
//        Pattern compositionPattern = Pattern.compile("[A-Z]\\|[A-Z]");
//        Pattern sumPattern = Pattern.compile("[A-Z]†[A-Z]");
//        Pattern equalPattern = Pattern.compile("^[A-Z]=[A-Z]$"); // todo check this works
//        Pattern subsetPattern = Pattern.compile("^[A-Z]⊆[A-Z]$"); // todo check this works
//        Pattern conversePattern = Pattern.compile("[A-Z]⁻¹");
//        Pattern dualPattern = Pattern.compile("[A-Z]ᵈ");
//        Pattern symmetricQuotientPattern = Pattern.compile("syq\\([A-Z],[A-Z]\\)");
//        Pattern conjugatedQuasiProjectionPattern = Pattern.compile("^cqp\\([A-Z],[A-Z]\\)$");// todo check this works
//        String previousCalculation = calculation;
//        boolean calculating = true;
//        while (calculating) {
//            calculation = calculation.replaceAll("\\(([A-Z]|)\\)","$1");
//            System.out.println(calculation);
//
//            // todo put these in order of operations and use different symbols for difference and complement
//
//            Matcher dualMatcher = dualPattern.matcher(calculation);
//            if (dualMatcher.find()) {
//                calculation = performSingleRelationSubOperation(calculation, PRelation::dual, dualMatcher, true);
//                continue;
//            }
//            Matcher converseMatcher = conversePattern.matcher(calculation);
//            if (converseMatcher.find()) {
//                calculation = performSingleRelationSubOperation(calculation, PRelation::converse, converseMatcher, true);
//                continue;
//            }
//            Matcher complementMatcher = complementPattern.matcher(calculation);
//            if (complementMatcher.find()) {
//                calculation = performSingleRelationSubOperation(calculation, PRelation::complement, complementMatcher, false);
//                continue;
//            }
//            Matcher compositionMatcher = compositionPattern.matcher(calculation);
//            if (compositionMatcher.find()) {
//                calculation = performDoubleRelationSubOperation(calculation, PRelation::composition, compositionMatcher);
//                continue;
//            }
//            Matcher leftResidualMatcher = leftResidualPattern.matcher(calculation);
//            if (leftResidualMatcher.find()) {
//                calculation = performDoubleRelationSubOperation(calculation, PRelation::leftResidual, leftResidualMatcher);
//                continue;
//            }
//            Matcher rightResidualMatcher = rightResidualPattern.matcher(calculation);
//            if (rightResidualMatcher.find()) {
//                calculation = performDoubleRelationSubOperation(calculation, PRelation::rightResidual, rightResidualMatcher);
//                continue;
//            }
//            Matcher symmetricQuotientMatcher = symmetricQuotientPattern.matcher(calculation);
//            if (symmetricQuotientMatcher.find()) {
//                calculation = performDoubleRelationSubOperation(calculation, PRelation::symmetricQuotient, symmetricQuotientMatcher);
//                continue;
//            }
//            Matcher intersectionMatcher = intersectionPattern.matcher(calculation);
//            if (intersectionMatcher.find()) {
//                calculation = performDoubleRelationSubOperation(calculation, PRelation::intersection, intersectionMatcher);
//                continue;
//            }
//            Matcher differenceMatcher = differencePattern.matcher(calculation);
//            if (differenceMatcher.find()) {
//                calculation = performDoubleRelationSubOperation(calculation, PRelation::difference, differenceMatcher);
//                continue;
//            }
//            Matcher symmetricDifferenceMatcher = symmetricDifferencePattern.matcher(calculation);
//            if (symmetricDifferenceMatcher.find()) {
//                calculation = performDoubleRelationSubOperation(calculation, PRelation::symmetricDifference, symmetricDifferenceMatcher);
//                continue;
//            }
//            Matcher sumMatcher = sumPattern.matcher(calculation);
//            if (sumMatcher.find()) {
//                calculation = performDoubleRelationSubOperation(calculation, PRelation::sum, sumMatcher);
//                continue;
//            }
//            Matcher unionMatcher = unionPattern.matcher(calculation);
//            if (unionMatcher.find()) {
//                calculation = performDoubleRelationSubOperation(calculation, PRelation::union, unionMatcher);
//                continue;
//            }
//            Matcher equalMatcher = equalPattern.matcher(calculation);
//            if (equalMatcher.find()) {
//                calculation = performDoubleRelationBooleanSubOperation(calculation, PRelation::isEqual, equalMatcher);
//                continue;
//            }
//            Matcher subsetMatcher = subsetPattern.matcher(calculation);
//            if (subsetMatcher.find()) {
//                calculation = performDoubleRelationBooleanSubOperation(calculation, PRelation::isSubsetOf, subsetMatcher);
//                continue;
//            }
//            Matcher conjugatedQuasiProjectionMatcher = conjugatedQuasiProjectionPattern.matcher(calculation);
//            if (conjugatedQuasiProjectionMatcher.find()) {
//                calculation = performDoubleRelationBooleanSubOperation(calculation, PRelation::conjugatedQuasiProjection, conjugatedQuasiProjectionMatcher);
//                continue;
//            }
//
//            if (calculation.length() == 1 || calculation.equals("true") || calculation.equals("false")) {
//                calculating = false;
//            }
//            if (calculation.equals(previousCalculation)) {
//                throw new CalculationBadFormat();
//            }
//            previousCalculation = calculation;
//
//        }
//    }
//
//    private String performDoubleRelationSubOperation(String calculation, BiFunction<PRelation, PRelation, PRelation> operation, Matcher matcher, ArrayList<PRelation> stepRelations) {
//        PRelation relationA = relationTransformer.toPRelation(getRelation.execute(calculation.charAt(matcher.start())));
//        PRelation relationB = relationTransformer.toPRelation(getRelation.execute(calculation.charAt(matcher.end() - 1)));
//        char newSymbol = symbolService.getNewSymbol();
//        relationTransformer.savePRelation(operation.apply(relationA, relationB), newSymbol, newSymbol + " = " + calculation.substring(matcher.start(), matcher.end()));
//        return calculation.substring(0, matcher.start()) + newSymbol + calculation.substring(matcher.end());
//    }
//
//    private String performSingleRelationSubOperation(String calculation, Function<PRelation, PRelation> operation, Matcher matcher, boolean relationSymbolAtStart) {
//        PRelation relation = relationTransformer.toPRelation(getRelation.execute(calculation.charAt(relationSymbolAtStart ? matcher.start() : matcher.end() - 1)));
//        char newSymbol = symbolService.getNewSymbol();
//        relationTransformer.savePRelation(operation.apply(relation), newSymbol, newSymbol + " = " + calculation.substring(matcher.start(), matcher.end()));
//        return calculation.substring(0, matcher.start()) + newSymbol + calculation.substring(matcher.end());
//    }
//
//    private String performDoubleRelationBooleanSubOperation(String calculation, BiFunction<PRelation, PRelation, Boolean> operation, Matcher matcher) {
//        PRelation relationA = relationTransformer.toPRelation(getRelation.execute(calculation.charAt(matcher.start())));
//        PRelation relationB = relationTransformer.toPRelation(getRelation.execute(calculation.charAt(matcher.end() - 1)));
//        return String.valueOf(operation.apply(relationA, relationB));
//    }

}
