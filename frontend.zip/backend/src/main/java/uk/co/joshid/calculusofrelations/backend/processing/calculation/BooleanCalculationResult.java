package uk.co.joshid.calculusofrelations.backend.processing.calculation;

import java.util.List;
import java.util.Objects;

public record BooleanCalculationResult(boolean result) implements CalculationResult {

}
