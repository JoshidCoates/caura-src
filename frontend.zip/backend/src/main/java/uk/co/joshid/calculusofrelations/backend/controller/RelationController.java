package uk.co.joshid.calculusofrelations.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import uk.co.joshid.calculusofrelations.backend.command.*;
import uk.co.joshid.calculusofrelations.backend.exception.RelationNotFound;
import uk.co.joshid.calculusofrelations.backend.model.Relation;
import uk.co.joshid.calculusofrelations.backend.model.RelationInfo;
import uk.co.joshid.calculusofrelations.backend.processing.RelationType;
import uk.co.joshid.calculusofrelations.backend.processing.calculation.BooleanCalculationResult;
import uk.co.joshid.calculusofrelations.backend.processing.calculation.CalculationResult;
import uk.co.joshid.calculusofrelations.backend.processing.calculation.RelationCalculationResult;
import uk.co.joshid.calculusofrelations.backend.repository.PosetRepository;
import uk.co.joshid.calculusofrelations.backend.repository.RelationRepository;
import uk.co.joshid.calculusofrelations.backend.repository.SessionRepository;
import uk.co.joshid.calculusofrelations.backend.repository.XMLRepository;
import uk.co.joshid.calculusofrelations.backend.response.CalculationResponse;
import uk.co.joshid.calculusofrelations.backend.response.ConceptResponse;
import uk.co.joshid.calculusofrelations.backend.response.FCAResponse;
import uk.co.joshid.calculusofrelations.backend.response.RCAResponse;
import uk.co.joshid.calculusofrelations.backend.services.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/relation")
public class RelationController {

    private final RelationRepository relationRepository;
    private final SessionRepository sessionRepository;
    private final ParseRelation parseRelation;
    private final GetRelation getRelation;
    private final PerformCalculation performCalculation;
    private final FCA fca;
    private final RCA rca;
    private final XMLRepository xmlRepository;
    private final PosetRepository posetRepository;

    @Autowired
    public RelationController(RelationRepository relationRepository, SessionRepository sessionRepository, ParseRelation parseRelation, GetRelation getRelation, PerformCalculation performCalculation, FCA fca, RCA rca, XMLRepository xmlRepository, PosetRepository posetRepository) {
        this.relationRepository = relationRepository;
        this.sessionRepository = sessionRepository;
        this.parseRelation = parseRelation;
        this.getRelation = getRelation;
        this.performCalculation = performCalculation;
        this.fca = fca;
        this.rca = rca;
        this.xmlRepository = xmlRepository;
        this.posetRepository = posetRepository;
    }

    @PostMapping("/relation-type")
    public void setRelationType(@RequestParam("relationType") RelationType relationType) {
        sessionRepository.getSessionData().setRelationType(relationType);
        relationRepository.deleteAll();
        xmlRepository.deleteAll();
    }

    @GetMapping
    public List<RelationInfo> getAllRelations() {
        return relationRepository.findAllInfo();
    }

    @PostMapping
    public void saveRelation(@RequestBody RelationCommand relationCommand) {
        parseRelation.execute(relationCommand);
    }

    @PatchMapping
    public void editRelation(@RequestBody EditCommand editCommand) {
        String name = editCommand.getName().isEmpty() ? String.valueOf(editCommand.getSymbol()) : editCommand.getName();
        Relation relation = relationRepository.findById(editCommand.getRelationId()).orElseThrow(RelationNotFound::new);
        relation.getRelationInfo().setName(name);
        relation.getRelationInfo().setSymbol(editCommand.getSymbol());
    }

    @GetMapping("/txt/{id}")
    public String getRelationDownload(@PathVariable("id") int relationId) {
        return getRelation.download(relationId);
    }

    @GetMapping(
            value = "/img/{id}",
            produces = MediaType.IMAGE_JPEG_VALUE
    )
    public @ResponseBody byte[] getRelationImage(@PathVariable("id") int relationId) throws IOException {
        return getRelation.image(relationId);
    }

    @GetMapping(value = "/fca/{id}",
            produces = MediaType.IMAGE_PNG_VALUE
    )
    public @ResponseBody byte[] performFCA(@PathVariable("id") int relationId) throws IOException {
        return fca.execute(relationId);
    }

    @GetMapping("/xml/{id}")
    public String getXml(@PathVariable("id") int relationId) {
        return xmlRepository.getById(relationId);
    }

    @PostMapping("/calculation")
    public CalculationResponse performCalculation(@RequestBody CalculationCommand calculationCommand) {
        CalculationResult calculationResult = performCalculation.execute(calculationCommand.calculation());
        if (calculationResult instanceof BooleanCalculationResult boolResult) {
            return CalculationResponse.builder().booleanResult(boolResult.result()).build();
        } else {
            RelationCalculationResult relationResult = (RelationCalculationResult) calculationResult;
            return CalculationResponse.builder().resultSymbol(relationResult.relation().getRelationInfo().getSymbol()).build();
        }
    }

    @DeleteMapping("/{id}")
    public void deleteRelation(@PathVariable("id") int relationId) {
        relationRepository.delete(relationId);
        xmlRepository.delete(relationId);
    }

    @GetMapping("/properties/{id}")
    public LinkedHashMap<String, Boolean> getProperties(@PathVariable("id") int relationId) {
        Relation relation = relationRepository.findById(relationId).orElseThrow(RelationNotFound::new);
        return relation.getRelation().getProperties();
    }

    @PostMapping("/rca")
    public RCAResponse performRCA(@RequestBody RCACommand rcaCommand) throws IOException {
        return rca.execute(rcaCommand);
    }

    @GetMapping(value = "/poset/{id}",
            produces = MediaType.IMAGE_PNG_VALUE
    )
    public @ResponseBody byte[] getPoset(@PathVariable("id") int posetId) {
        return posetRepository.get(posetId);
    }

    @Deprecated
    @PostMapping("/concepts")
    public ConceptResponse generateConcepts() {
//        List<ContextAndLattice> contextAndLattices = new ArrayList<>();
//        IRelation context1 = relationTransformer.toEOPRelation(getRelation.execute(378, RelationType.EO_PAIR_RELATION));
//        contextAndLattices.add(new ContextAndLattice(context1, new Lattice(GenerateConcepts.execute(context1).getLatticeConcepts(), "Drugs")));
//        IRelation context2 = relationTransformer.toEOPRelation(getRelation.execute(381, RelationType.EO_PAIR_RELATION));
//        contextAndLattices.add(new ContextAndLattice(context2, new Lattice(GenerateConcepts.execute(context2).getLatticeConcepts(), "Patients")));
//        HashMap<IRelation, ObjRelationData> objRelationMap = new HashMap<>();
//        IRelation objRelation3 = relationTransformer.toEOPRelation(getRelation.execute(387, RelationType.EO_PAIR_RELATION));
//        objRelationMap.put(objRelation3, new ObjRelationData(new ExistentialOperator(), "takes"));
//        IRelation objRelation1 = relationTransformer.toEOPRelation(getRelation.execute(393, RelationType.EO_PAIR_RELATION));
//        objRelationMap.put(objRelation1, new ObjRelationData(new ExistentialOperator(), "itb"));
//        IRelation objRelation2 = relationTransformer.toEOPRelation(getRelation.execute(390, RelationType.EO_PAIR_RELATION));
//        objRelationMap.put(objRelation2, new ObjRelationData(new ExistentialOperator(), "iw"));
//        ContextEnvironment contextEnvironment = new ContextEnvironment(contextAndLattices, objRelationMap);
//        List<ContextAndLattice> result = contextEnvironment.execute();
//        System.out.println("Done!");
//        return generateConcepts.execute(conceptsCommand);
        return null;
    }

}
