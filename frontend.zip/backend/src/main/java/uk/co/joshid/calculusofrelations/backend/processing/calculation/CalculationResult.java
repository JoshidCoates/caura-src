package uk.co.joshid.calculusofrelations.backend.processing.calculation;

import java.util.List;

public interface CalculationResult {
}
