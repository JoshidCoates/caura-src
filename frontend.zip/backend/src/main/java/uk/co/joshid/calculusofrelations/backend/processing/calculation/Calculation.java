package uk.co.joshid.calculusofrelations.backend.processing.calculation;

import uk.co.joshid.calculusofrelations.backend.exception.CalculationBadFormat;
import uk.co.joshid.calculusofrelations.backend.processing.RelationType;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;
import uk.co.joshid.calculusofrelations.backend.services.GetRelation;
import uk.co.joshid.calculusofrelations.backend.services.RelationTransformer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Calculation {

    private final String relationIdentifier = "([A-Z]|\\d+)";
    private final Pattern justRelationPattern = Pattern.compile("^" + relationIdentifier + "$");
    private final Pattern unionPattern = Pattern.compile(relationIdentifier + "∪" + relationIdentifier);
    private final Pattern complementPattern = Pattern.compile("~" + relationIdentifier);
//    private final Pattern extentOrIntentClosurePattern = Pattern.compile(relationIdentifier + "'"); // todo check this works
    private final Pattern transitiveClosurePattern = Pattern.compile(relationIdentifier + "⁺"); // todo check this works
    private final Pattern reflexiveTransitiveClosurePattern = Pattern.compile(relationIdentifier + "\\*"); // todo check this works
    private final Pattern leftResidualPattern = Pattern.compile(relationIdentifier + "\\\\" + relationIdentifier);
    private final Pattern rightResidualPattern = Pattern.compile(relationIdentifier + "/" + relationIdentifier); // todo check this regex works
    private final Pattern intersectionPattern = Pattern.compile(relationIdentifier + "∩" + relationIdentifier);
    private final Pattern differencePattern = Pattern.compile(relationIdentifier + "-" + relationIdentifier); // todo check this regex works
    private final Pattern symmetricDifferencePattern = Pattern.compile(relationIdentifier + "Δ" + relationIdentifier);
    private final Pattern compositionPattern = Pattern.compile(relationIdentifier + ";" + relationIdentifier);
    private final Pattern sumPattern = Pattern.compile(relationIdentifier + "†" + relationIdentifier);
    private final Pattern equalPattern = Pattern.compile("^" + relationIdentifier + "=" + relationIdentifier + "$"); // todo check this works
    private final Pattern subsetPattern = Pattern.compile("^" + relationIdentifier + "⊆" + relationIdentifier + "$"); // todo check this works
    private final Pattern properSubsetPattern = Pattern.compile("^" + relationIdentifier + "⊂" + relationIdentifier + "$");
    private final Pattern conversePattern = Pattern.compile(relationIdentifier + "ᵀ");
    private final Pattern dualPattern = Pattern.compile(relationIdentifier + "ᵈ");
    private final Pattern symmetricQuotientPattern = Pattern.compile("syq\\(" + relationIdentifier + "," + relationIdentifier + "\\)");
    private final Pattern sourceIdentityPattern = Pattern.compile("sid\\(" + relationIdentifier + "\\)");
    private final Pattern targetIdentityPattern = Pattern.compile("tid\\(" + relationIdentifier + "\\)");
//    private final Pattern conjugatedQuasiProjectionPattern = Pattern.compile("^cqp\\(" + relationIdentifier + "," + relationIdentifier + "\\)$");// todo check this works

    private final GetRelation getRelation;

    private final ArrayList<StepRelation> stepRelations;

    private String calculationStr;

    public Calculation(String calculationStr, GetRelation getRelation) {
        this.calculationStr = calculationStr;
        this.getRelation = getRelation;
        this.stepRelations = new ArrayList<>();
        execute();
    }

    public String getCalculationStr() {
        return calculationStr;
    }

    public List<StepRelation> getStepRelations() {
        return stepRelations;
    }

    public List<String> getSteps() {
        return stepRelations.stream().map(StepRelation::calculation).toList();
    }

    private void execute() {
        calculationStr = calculationStr.replaceAll("\\s+","");

        String previousCalculation = calculationStr;
        boolean calculating = true;
        while (calculating) {
            Matcher sourceIdentityMatcher = sourceIdentityPattern.matcher(calculationStr);
            if (sourceIdentityMatcher.find()) {
                performSingleRelationSubOperation(IRelation::sourceIdentityRelation, sourceIdentityMatcher);
                continue;
            }
            Matcher targetIdentityMatcher = targetIdentityPattern.matcher(calculationStr);
            if (targetIdentityMatcher.find()) {
                performSingleRelationSubOperation(IRelation::targetIdentityRelation, targetIdentityMatcher);
                continue;
            }

            calculationStr = calculationStr.replaceAll("\\(([A-Z]|\\d+|)\\)","$1");
//            System.out.println(calculationStr);

            Matcher dualMatcher = dualPattern.matcher(calculationStr);
            if (dualMatcher.find()) {
                performSingleRelationSubOperation(IRelation::dual, dualMatcher);
                continue;
            }
            Matcher converseMatcher = conversePattern.matcher(calculationStr);
            if (converseMatcher.find()) {
                performSingleRelationSubOperation(IRelation::converse, converseMatcher);
                continue;
            }
            Matcher complementMatcher = complementPattern.matcher(calculationStr);
            if (complementMatcher.find()) {
                performSingleRelationSubOperation(IRelation::complement, complementMatcher);
                continue;
            }
//            Matcher extentOrIntentClosureMatcher = extentOrIntentClosurePattern.matcher(calculationStr);
//            if (extentOrIntentClosureMatcher.find()) {
//                performSingleRelationSubOperation(IRelation::extent, extentOrIntentClosureMatcher);
//                continue;
//            } // TODO this needs know the relation it is with respective to
            Matcher transitiveClosureMatcher = transitiveClosurePattern.matcher(calculationStr);
            if (transitiveClosureMatcher.find()) {
                performSingleRelationSubOperation(IRelation::transitiveClosure, transitiveClosureMatcher);
                continue;
            }
            Matcher reflexiveTransitiveClosureMatcher = reflexiveTransitiveClosurePattern.matcher(calculationStr);
            if (reflexiveTransitiveClosureMatcher.find()) {
                performSingleRelationSubOperation(IRelation::reflexiveTransitiveClosure, reflexiveTransitiveClosureMatcher);
                continue;
            }

            Matcher compositionMatcher = compositionPattern.matcher(calculationStr);
            if (compositionMatcher.find()) {
                performDoubleRelationSubOperation(IRelation::composition, compositionMatcher);
                continue;
            }
            Matcher leftResidualMatcher = leftResidualPattern.matcher(calculationStr);
            if (leftResidualMatcher.find()) {
                performDoubleRelationSubOperation(IRelation::leftResidual, leftResidualMatcher);
                continue;
            }
            Matcher rightResidualMatcher = rightResidualPattern.matcher(calculationStr);
            if (rightResidualMatcher.find()) {
                performDoubleRelationSubOperation(IRelation::rightResidual, rightResidualMatcher);
                continue;
            }
            Matcher symmetricQuotientMatcher = symmetricQuotientPattern.matcher(calculationStr);
            if (symmetricQuotientMatcher.find()) {
                performDoubleRelationSubOperation(IRelation::symmetricQuotient, symmetricQuotientMatcher);
                continue;
            }
            Matcher intersectionMatcher = intersectionPattern.matcher(calculationStr);
            if (intersectionMatcher.find()) {
                performDoubleRelationSubOperation(IRelation::intersection, intersectionMatcher);
                continue;
            }
            Matcher symmetricDifferenceMatcher = symmetricDifferencePattern.matcher(calculationStr);
            if (symmetricDifferenceMatcher.find()) {
                performDoubleRelationSubOperation(IRelation::symmetricDifference, symmetricDifferenceMatcher);
                continue;
            }
            Matcher differenceMatcher = differencePattern.matcher(calculationStr);
            if (differenceMatcher.find()) {
                performDoubleRelationSubOperation(IRelation::difference, differenceMatcher);
                continue;
            }
            Matcher sumMatcher = sumPattern.matcher(calculationStr);
            if (sumMatcher.find()) {
                performDoubleRelationSubOperation(IRelation::sum, sumMatcher);
                continue;
            }
            Matcher unionMatcher = unionPattern.matcher(calculationStr);
            if (unionMatcher.find()) {
                performDoubleRelationSubOperation(IRelation::union, unionMatcher);
                continue;
            }
            Matcher equalMatcher = equalPattern.matcher(calculationStr);
            if (equalMatcher.find()) {
                performDoubleRelationBooleanSubOperation(IRelation::isEqual, equalMatcher);
                continue;
            }
            Matcher subsetMatcher = subsetPattern.matcher(calculationStr);
            if (subsetMatcher.find()) {
                performDoubleRelationBooleanSubOperation(IRelation::isSubsetOf, subsetMatcher);
                continue;
            }
            Matcher properSubsetMatcher = properSubsetPattern.matcher(calculationStr);
            if (properSubsetMatcher.find()) {
                performDoubleRelationBooleanSubOperation(IRelation::isProperSubsetOf, properSubsetMatcher);
                continue;
            }
//            Matcher conjugatedQuasiProjectionMatcher = conjugatedQuasiProjectionPattern.matcher(calculationStr);
//            if (conjugatedQuasiProjectionMatcher.find()) {
//                performDoubleRelationBooleanSubOperation(IRelation::conjugatedQuasiProjection, conjugatedQuasiProjectionMatcher);
//                continue;
//            }

            if (justRelationPattern.matcher(calculationStr).find() || calculationStr.equals("true") || calculationStr.equals("false")) {
                calculating = false;
            }
            if (calculationStr.equals(previousCalculation)) {
                throw new CalculationBadFormat();
            }
            previousCalculation = calculationStr;

        }
    }

    private void performDoubleRelationSubOperation(BiFunction<IRelation, IRelation, IRelation> operation, Matcher matcher) {
        String firstRelation = matcher.group(1);
        IRelation relationA;
        if (Character.isUpperCase(firstRelation.charAt(0))) {
            relationA = getRelation.execute(firstRelation.charAt(0)).getRelation();
        } else {
            relationA = stepRelations.get(Integer.parseInt(firstRelation)).relation();
        }
        String secondRelation = matcher.group(2);
        IRelation relationB;
        if (Character.isUpperCase(secondRelation.charAt(0))) {
            relationB = getRelation.execute(secondRelation.charAt(0)).getRelation();
        } else {
            relationB = stepRelations.get(Integer.parseInt(secondRelation)).relation();
        }
        int nextStepIndex = stepRelations.size();
        stepRelations.add(new StepRelation(operation.apply(relationA, relationB), nextStepIndex + " = " + calculationStr.substring(matcher.start(), matcher.end())));
        calculationStr = calculationStr.substring(0, matcher.start()) + nextStepIndex + calculationStr.substring(matcher.end());
    }

    private void performSingleRelationSubOperation(Function<IRelation, IRelation> operation, Matcher matcher) {
        String relationSymbol = matcher.group(1);
        IRelation relation;
        if (Character.isUpperCase(relationSymbol.charAt(0))) {
            relation = getRelation.execute(relationSymbol.charAt(0)).getRelation();
        } else {
            relation = stepRelations.get(Integer.parseInt(relationSymbol)).relation();
        }
        int nextStepIndex = stepRelations.size();
        stepRelations.add(new StepRelation(operation.apply(relation), nextStepIndex + " = " + calculationStr.substring(matcher.start(), matcher.end())));
        calculationStr = calculationStr.substring(0, matcher.start()) + nextStepIndex + calculationStr.substring(matcher.end());
    }

    private void performDoubleRelationBooleanSubOperation(BiFunction<IRelation, IRelation, Boolean> operation, Matcher matcher) {
        String firstRelation = matcher.group(1);
        IRelation relationA;
        if (Character.isUpperCase(firstRelation.charAt(0))) {
            relationA = getRelation.execute(firstRelation.charAt(0)).getRelation();
        } else {
            relationA = stepRelations.get(Integer.parseInt(firstRelation)).relation();
        }
        String secondRelation = matcher.group(2);
        IRelation relationB;
        if (Character.isUpperCase(secondRelation.charAt(0))) {
            relationB = getRelation.execute(secondRelation.charAt(0)).getRelation();
        } else {
            relationB = stepRelations.get(Integer.parseInt(secondRelation)).relation();
        }
        calculationStr = String.valueOf(operation.apply(relationA, relationB));
    }
}
