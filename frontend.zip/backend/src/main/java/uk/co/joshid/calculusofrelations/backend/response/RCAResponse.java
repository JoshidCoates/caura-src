package uk.co.joshid.calculusofrelations.backend.response;

import uk.co.joshid.calculusofrelations.backend.services.rca.RCAResult;

import java.util.List;

public record RCAResponse(List<RCAResult> results) {
}
