package uk.co.joshid.calculusofrelations.backend.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.PRelation;
import uk.co.joshid.calculusofrelations.backend.repository.*;

@Deprecated
@Service
@RequiredArgsConstructor
public class ResetRelations {

    private final RelationRepository relationRepository;

    public void execute() {
        relationRepository.deleteAll();
    }
}
