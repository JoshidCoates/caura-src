package uk.co.joshid.calculusofrelations.backend.processing.nonmatrix;


import lombok.Value;

import java.util.HashSet;

@Value
public class SFormat {

    HashSet<String> source;
    HashSet<String> target;

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof SFormat p))
            return false;
        if (obj == this)
            return true;

        return source.equals(p.source)
                && target.equals(p.target);
    }

    public boolean isHomogeneous() {
        return source.equals(target);
    }

    public boolean isHeterogeneous() {
        return !isHomogeneous();
    }

    public SFormat union(SFormat otherFormat) {
        HashSet<String> unionUniversalDomain = new HashSet<>(source);
        unionUniversalDomain.addAll(otherFormat.source);
        HashSet<String> unionCodomain = new HashSet<>(target);
        unionCodomain.addAll(otherFormat.target);
        return new SFormat(unionUniversalDomain, unionCodomain);
    }

    public SFormat intersection(SFormat otherFormat) {
        HashSet<String> unionUniversalDomain = new HashSet<>(source);
        unionUniversalDomain.retainAll(otherFormat.source);
        HashSet<String> unionCodomain = new HashSet<>(target);
        unionCodomain.retainAll(otherFormat.target);
        return new SFormat(unionUniversalDomain, unionCodomain);
    }

    public int rows() {
        return source.size();
    }

    public int cols() {
        return target.size();
    }
}
