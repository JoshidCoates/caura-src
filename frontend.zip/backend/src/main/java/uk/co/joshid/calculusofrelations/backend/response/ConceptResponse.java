package uk.co.joshid.calculusofrelations.backend.response;

import lombok.AllArgsConstructor;

public record ConceptResponse(String dot, String xml) {
}
