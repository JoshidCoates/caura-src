package uk.co.joshid.calculusofrelations.backend.processing.nonmatrix;


import lombok.Value;

import java.util.HashSet;

@Value
public class IntFormat {

    HashSet<Integer> source;
    HashSet<Integer> target;

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof IntFormat p))
            return false;
        if (obj == this)
            return true;

        return source.equals(p.source)
                && target.equals(p.target);
    }

    public boolean isHomogeneous() {
        return source.equals(target);
    }

    public boolean isHeterogeneous() {
        return !isHomogeneous();
    }

    public IntFormat union(IntFormat otherFormat) {
        HashSet<Integer> unionUniversalDomain = new HashSet<>(source);
        unionUniversalDomain.addAll(otherFormat.source);
        HashSet<Integer> unionCodomain = new HashSet<>(target);
        unionCodomain.addAll(otherFormat.target);
        return new IntFormat(unionUniversalDomain, unionCodomain);
    }

    public IntFormat intersection(IntFormat otherFormat) {
        HashSet<Integer> unionUniversalDomain = new HashSet<>(source);
        unionUniversalDomain.retainAll(otherFormat.source);
        HashSet<Integer> unionCodomain = new HashSet<>(target);
        unionCodomain.retainAll(otherFormat.target);
        return new IntFormat(unionUniversalDomain, unionCodomain);
    }

    public int rows() {
        return source.size();
    }

    public int cols() {
        return target.size();
    }
}
