package uk.co.joshid.calculusofrelations.backend.command;

import lombok.Data;
import uk.co.joshid.calculusofrelations.backend.processing.RelationType;

@Deprecated
@Data
public class IdentityCommand {
    private int relationId;
    private boolean generateSourceIdentity;
    private RelationType relationType;
}
