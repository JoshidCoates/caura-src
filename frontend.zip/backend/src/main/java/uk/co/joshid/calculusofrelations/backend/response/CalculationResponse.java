package uk.co.joshid.calculusofrelations.backend.response;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import uk.co.joshid.calculusofrelations.backend.model.Relation;
import uk.co.joshid.calculusofrelations.backend.model.RelationInfo;

import java.util.List;

@Builder
@Getter
public class CalculationResponse {

    char resultSymbol;
    boolean booleanResult;
}
