package uk.co.joshid.calculusofrelations.backend.services.rca;

import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;

public record ContextAndPoset(IRelation originalContext, IRelation currentContext, PosetGeneration poset, String name, int step) {
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof ContextAndPoset c))
            return false;
        if (obj == this)
            return true;
        return c.currentContext().isEqual(currentContext);
//        return c.currentContext().getTarget().size() == currentContext.getTarget().size();
    }
}
