package uk.co.joshid.calculusofrelations.backend.services.rca;

import lombok.AllArgsConstructor;
import lombok.Data;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;

import java.util.List;

@Data
@AllArgsConstructor
public class Concept {
    private final IRelation objects;
    private final IRelation attributes;
    private final List<String> o;
    private final List<String> a;
    private String name;
}
