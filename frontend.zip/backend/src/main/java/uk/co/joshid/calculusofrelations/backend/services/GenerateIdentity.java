package uk.co.joshid.calculusofrelations.backend.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.joshid.calculusofrelations.backend.command.IdentityCommand;
import uk.co.joshid.calculusofrelations.backend.model.Relation;
import uk.co.joshid.calculusofrelations.backend.model.RelationInfo;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;

@Deprecated
@Service
@RequiredArgsConstructor
public class GenerateIdentity {

    private final GetRelation getRelation;
    private final SymbolService symbolService;
    private final RelationTransformer relationTransformer;

    public Relation execute(IdentityCommand identityCommand) {
//        Relation relation = getRelation.execute(identityCommand.getRelationId(), identityCommand.getRelationType());
//        char newSymbol = symbolService.getNewSymbol();
//        IRelation iRelation = relationTransformer.toIRelation(relation, identityCommand.getRelationType());
//        IRelation identityIRelation = identityCommand.isGenerateSourceIdentity() ?
//                iRelation.identityRelation(iRelation.getFormat().getSource()) :
//                iRelation.identityRelation(iRelation.getFormat().getTarget());
//        RelationInfo newRelationInfo = relationTransformer.saveIRelation(identityIRelation, newSymbol,
//        "sourceId(" + relation.relationInfo().getSymbol() + ")");
//        return getRelation.execute(newRelationInfo.getId(), identityCommand.getRelationType());
        return null;
    }
}
