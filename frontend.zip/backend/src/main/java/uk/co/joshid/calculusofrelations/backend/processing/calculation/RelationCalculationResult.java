package uk.co.joshid.calculusofrelations.backend.processing.calculation;

import uk.co.joshid.calculusofrelations.backend.model.Relation;
import uk.co.joshid.calculusofrelations.backend.model.RelationInfo;

import java.util.List;
import java.util.Objects;

public record RelationCalculationResult(Relation relation) implements CalculationResult {

}
