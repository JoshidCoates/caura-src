package uk.co.joshid.calculusofrelations.backend.services;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import uk.co.joshid.calculusofrelations.backend.command.RelationCommand;
import uk.co.joshid.calculusofrelations.backend.exception.RelationBadFormat;
import uk.co.joshid.calculusofrelations.backend.model.*;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.*;
import uk.co.joshid.calculusofrelations.backend.repository.*;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class ParseRelation {

    private final RelationRepository relationRepository;
    private final SessionRepository sessionRepository;

    private enum InputType {
        MATRIX,
        PAIR_LIST
    }

    public void execute(RelationCommand relationCommand) {
        String name = relationCommand.getName().isEmpty() ? String.valueOf(relationCommand.getSymbol()) : relationCommand.getName();

        // todo check source and target els are unique
        String[] sourceElements = relationCommand.getSourceData().replaceAll(",", " ").strip().split("\\s+");
        String[] targetElements = relationCommand.getTargetData().replaceAll(",", " ").strip().split("\\s+");
        int sourceSize = sourceElements.length;
        int targetSize = targetElements.length;
//        System.out.println("Save 2");
//        System.out.println(System.currentTimeMillis());
        RelationInfo relationInfo = new RelationInfo(name, relationCommand.getSymbol(), sourceSize, targetSize);

        HashSet<SPair> relationPairs = new HashSet<>();
        if (relationCommand.isGenerateRelation()) {
            if (relationCommand.getDensity() < 0 || relationCommand.getDensity() > 1) {
                throw new RelationBadFormat();
            }

            Random rand = new Random();
            for (String sourceElement : sourceElements) {
                for (String targetElement : targetElements) {
                   if (rand.nextDouble() < relationCommand.getDensity()) {
                        relationPairs.add(new SPair(sourceElement, targetElement));
                    }
                }
            }
//            System.out.println("Save 3.75");
//            System.out.println(System.currentTimeMillis());

            relationRepository.save(new Relation(relationInfo, buildRelation(sourceElements, targetElements, relationPairs)));
            return;
        }
//        System.out.println("Save 4");
//        System.out.println(System.currentTimeMillis());

        if (relationCommand.getRelationData().isEmpty()) return;
        String[] lines = relationCommand.getRelationData().strip().replaceAll("\\)\\s*,\\s*\\(", ")\n(").replaceAll("[(){}]", "").replaceAll(",", " ").split("(\\r\\n|\\r|\\n)");

        String firstLine = lines[0].strip();
        InputType inputType;
        String pairListPattern = "^\\S+\\s+\\S+$";
        if (Pattern.compile(pairListPattern).matcher(firstLine).find()) {
            inputType = InputType.PAIR_LIST;
        } else if (lines.length == sourceSize) {
            inputType = InputType.MATRIX;
        } else {
            throw new RelationBadFormat();
        }
        for (int i = 0; i < lines.length; i++) {
            if (inputType == InputType.MATRIX) {
                String[] lineElements = lines[i].strip().replaceAll("\\s+", "").split("");
                for (int j = 0; j < targetSize; j++) {
                    if (Integer.parseInt(lineElements[j]) == 1) {
                        relationPairs.add(new SPair(sourceElements[i], targetElements[j]));
                    }
                }
            } else if (inputType == InputType.PAIR_LIST) {
                String[] lineElements = lines[i].strip().split("\\s+");
                ArrayList<String> sourceList = new ArrayList<>(Arrays.asList(sourceElements));
                ArrayList<String> targetList = new ArrayList<>(Arrays.asList(targetElements));
//                if (StringUtils.isAlpha(lineElements[0]) || StringUtils.isAlpha(lineElements[1])) {
                    if (sourceList.contains(lineElements[0]) && targetList.contains(lineElements[1])) {
                        relationPairs.add(new SPair(lineElements[0], lineElements[1]));
                    } else {
                        throw new RelationBadFormat();
                    }
//                } else {
//                    relationPairs.add(new SPair(sourceElements[Integer.parseInt(lineElements[0])], targetElements[Integer.parseInt(lineElements[1])]));
//                }
            }
        }
//        System.out.println("Save 4");
//        System.out.println(System.currentTimeMillis());

        relationRepository.save(new Relation(relationInfo, buildRelation(sourceElements, targetElements, relationPairs)));


    }

    private IRelation buildRelation(String[] source, String[] target, HashSet<SPair> pairs) {
        return switch (sessionRepository.getSessionData().getRelationType()) {
            case PAIR_RELATION ->  new PRelation(new SFormat(new HashSet<>(Arrays.asList(source)), new HashSet<>(Arrays.asList(target))), new RSet(pairs));
            case EO_PAIR_RELATION -> new EOPRelation(new SFormat(new HashSet<>(Arrays.asList(source)), new HashSet<>(Arrays.asList(target))), new RSet(pairs));
            case SHARED_SET_RELATION -> new SSRelation(new SFormat(new HashSet<>(Arrays.asList(source)), new HashSet<>(Arrays.asList(target))), new RSet(pairs));
            case EO_SHARED_SET_RELATION -> new EOSSRelation(new SFormat(new HashSet<>(Arrays.asList(source)), new HashSet<>(Arrays.asList(target))), new RSet(pairs));
        };

    }
}
