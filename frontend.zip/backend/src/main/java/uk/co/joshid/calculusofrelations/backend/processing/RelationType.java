package uk.co.joshid.calculusofrelations.backend.processing;

public enum RelationType {
    EO_PAIR_RELATION,
    PAIR_RELATION,
    SHARED_SET_RELATION,
    EO_SHARED_SET_RELATION
}
