package uk.co.joshid.calculusofrelations.backend.model;

import lombok.*;

@Data
public class RelationInfo {

    private static int counter = 0;
    private final int id;

    private String name;
    private char symbol;
    private int rows;
    private int cols;

    public RelationInfo(String name, char symbol, int rows, int cols) {
        this.id = counter++;
        this.name = name;
        this.symbol = symbol;
        this.rows = rows;
        this.cols = cols;
    }
}
