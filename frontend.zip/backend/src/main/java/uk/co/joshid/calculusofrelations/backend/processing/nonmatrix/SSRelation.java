package uk.co.joshid.calculusofrelations.backend.processing.nonmatrix;

import org.springframework.cglib.core.CollectionUtils;
import uk.co.joshid.calculusofrelations.backend.processing.UnmatchedUniversalSetsException;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class SSRelation extends IRelation {

    private static final ArrayList<String> universalSet = new ArrayList<>();

    private final IntFormat format;

    protected final IntPairSet pairs;

    public SSRelation(SFormat format, RSet pairs) {
        HashSet<Integer> source = new HashSet<>();
        HashSet<Integer> target = new HashSet<>();
        for (String sourceEl : format.getSource()) {
            source.add(addToUniversal(sourceEl));
        }
        for (String targetEl : format.getTarget()) {
            target.add(addToUniversal(targetEl));
        }
        this.format = new IntFormat(source, target);
        this.pairs = new IntPairSet(pairs.getElements().stream().map(
                p -> new IntPair(universalSet.indexOf(p.getSourceEl()), universalSet.indexOf(p.getTargetEl())))
                .collect(Collectors.toCollection(HashSet::new)));
    }

    public SSRelation(IntFormat format, IntPairSet pairs) {
        this.format = format;
        this.pairs = pairs;
    }

    private int addToUniversal(String el) {
        int idx = universalSet.indexOf(el);
        if (idx == -1) {
            universalSet.add(el);
            idx = universalSet.size() - 1;
        }
        return idx;
    }

    @Override
    public IRelation union(IRelation otherRelation) {
        SSRelation otherSSRelation = (SSRelation) otherRelation;
        if (!format.equals(otherSSRelation.format)) throw new UnmatchedUniversalSetsException();
        return new SSRelation(format, pairs.union(otherSSRelation.pairs));
    }

    @Override
    public IRelation complement() {
        return new SSRelation(format, ((SSRelation) universalRelation()).pairs.relativeComplement(pairs));
    }

    @Override
    public IRelation intersection(IRelation otherRelation) {
        SSRelation otherSSRelation = (SSRelation) otherRelation;
        if (!format.equals(otherSSRelation.format)) throw new UnmatchedUniversalSetsException();
        return new SSRelation(format, pairs.intersection(otherSSRelation.pairs));
    }

    @Override
    public IRelation difference(IRelation otherRelation) {
        SSRelation otherSSRelation = (SSRelation) otherRelation;
        if (!format.equals(otherSSRelation.format)) throw new UnmatchedUniversalSetsException();
        return new SSRelation(format, pairs.relativeComplement(otherSSRelation.pairs));
    }

    @Override
    public IRelation composition(IRelation otherRelation) {
        SSRelation otherSSRelation = (SSRelation) otherRelation;
        if (!format.getTarget().equals(otherSSRelation.format.getSource())) throw new UnmatchedUniversalSetsException();
        HashMap<Integer, HashSet<Integer>> partitions = new HashMap<>();
        HashSet<IntPair> composedElements = new HashSet<>();
        if (otherSSRelation.pairs.size() < pairs.size()) {
            for (IntPair otherPair : otherSSRelation.pairs.getElements()) {
                HashSet<Integer> elRange = partitions.get(otherPair.getSourceEl());
                if (elRange == null) elRange = new HashSet<>();
                elRange.add(otherPair.getTargetEl());
                partitions.put(otherPair.getSourceEl(), elRange);
            }
            for (IntPair selfPair : pairs.getElements()) {
                HashSet<Integer> targetsToCompose = partitions.get(selfPair.getTargetEl());
                if (targetsToCompose != null) {
                    for (int otherTarget : targetsToCompose) {
                        composedElements.add(new IntPair(selfPair.getSourceEl(), otherTarget));
                    }
                }
            }
        } else {
            for (IntPair selfPair : pairs.getElements()) {
                HashSet<Integer> elSource = partitions.get(selfPair.getTargetEl());
                if (elSource == null) elSource = new HashSet<>();
                elSource.add(selfPair.getSourceEl());
                partitions.put(selfPair.getTargetEl(), elSource);
            }
            for (IntPair otherPair : otherSSRelation.pairs.getElements()) {
                HashSet<Integer> sourcesToCompose = partitions.get(otherPair.getSourceEl());
                if (sourcesToCompose != null) {
                    for (int selfSource : sourcesToCompose) {
                        composedElements.add(new IntPair(selfSource, otherPair.getTargetEl()));
                    }
                }

            }
        }

        return new SSRelation(new IntFormat(format.getSource(), otherSSRelation.format.getTarget()), new IntPairSet(composedElements));
    }

    @Override
    public IRelation converse() {
        HashSet<IntPair> reversedSet = new HashSet<>(pairs.getElements().stream().map(IntPair::reverse).toList());
        return new SSRelation(new IntFormat(format.getTarget(), format.getSource()), new IntPairSet(reversedSet));
    }

    @Override
    public IRelation transitiveClosure() {
        if (format.isHeterogeneous()) throw new UnmatchedUniversalSetsException();
        IRelation closure = this;
        boolean findingClosure = true;
        int step = 1;
//        System.out.println("hi");
        while (findingClosure) {
//            System.out.println(step);
            IRelation newPart = this;
            for (int i = 0; i < step; i++) {
                newPart = composition(newPart);
            }
            IRelation newClosure = closure.union(newPart);
            if (closure.isEqual(newClosure)) {
                findingClosure = false;
            } else {
                closure = newClosure;
            }
            step++;
        }
        return closure;
    }

    @Override
    public IRelation reflexiveTransitiveClosure() {
        if (format.isHeterogeneous()) throw new UnmatchedUniversalSetsException();
        return sourceIdentityRelation().union(transitiveClosure());
    }

    @Override
    public boolean isSubsetOf(IRelation otherRelation) {
        SSRelation otherSSRelation = (SSRelation) otherRelation;
        return otherSSRelation.pairs.contains(pairs);
    }

    @Override
    public boolean isProperSubsetOf(IRelation otherRelation) {
        SSRelation otherSSRelation = (SSRelation) otherRelation;
        return otherSSRelation.pairs.contains(pairs) && !otherSSRelation.pairs.equals(pairs);
    }

    @Override
    public boolean isEqual(IRelation otherRelation) {
        SSRelation otherSSRelation = (SSRelation) otherRelation;
        return format.equals(otherSSRelation.format) && pairs.equals(otherSSRelation.pairs);
    }

    @Override
    public boolean isEmpty() {
        return pairs.size() == 0;
    }

    @Override
    public IRelation sourceIdentityRelation() {
        HashSet<IntPair> identityPairs = new HashSet<>();
        for (int el : format.getSource()) {
            identityPairs.add(new IntPair(el, el));
        }
        return new SSRelation(new IntFormat(format.getSource(), format.getSource()), new IntPairSet(identityPairs));
    }
    @Override
    public IRelation targetIdentityRelation() {
        HashSet<IntPair> identityPairs = new HashSet<>();
        for (int el : format.getTarget()) {
            identityPairs.add(new IntPair(el, el));
        }
        return new SSRelation(new IntFormat(format.getTarget(), format.getTarget()), new IntPairSet(identityPairs));
    }

    @Override
    public IRelation sourceEmptyRelation() {
        return new SSRelation(new IntFormat(format.getSource(), format.getSource()), new IntPairSet());
    }
    @Override
    public IRelation targetEmptyRelation() {
        return new SSRelation(new IntFormat(format.getTarget(), format.getTarget()), new IntPairSet());
    }

    public IRelation universalRelation() {
        HashSet<IntPair> allPairs = new HashSet<>();
        for (int sourceEl : format.getSource()) {
            for (int targetEl : format.getTarget()) {
                allPairs.add(new IntPair(sourceEl, targetEl));
            }
        }
        return new SSRelation(format, new IntPairSet(allPairs));
    }

    @Override
    public IRelation sourceUniversalRelation() {
        HashSet<IntPair> allPairs = new HashSet<>();
        for (int sourceEl : format.getSource()) {
            for (int targetEl : format.getSource()) {
                allPairs.add(new IntPair(sourceEl, targetEl));
            }
        }
        return new SSRelation(new IntFormat(format.getSource(), format.getSource()), new IntPairSet(allPairs));
    }
    @Override
    public IRelation targetUniversalRelation() {
        HashSet<IntPair> allPairs = new HashSet<>();
        for (int sourceEl : format.getTarget()) {
            for (int targetEl : format.getTarget()) {
                allPairs.add(new IntPair(sourceEl, targetEl));
            }
        }
        return new SSRelation(new IntFormat(format.getTarget(), format.getTarget()), new IntPairSet(allPairs));
    }

    @Override
    public IRelation sourceDiversityRelation() {
        return sourceIdentityRelation().complement();
    }
    @Override
    public IRelation targetDiversityRelation() {
        return targetIdentityRelation().complement();
    }
    


    

    @Override
    public HashSet<String> getDomain() {
        return pairs.getElements().stream().map(el -> universalSet.get(el.getSourceEl())).collect(Collectors.toCollection(HashSet::new));
    }

    @Override
    public HashSet<String> getRange() {
        return pairs.getElements().stream().map(el -> universalSet.get(el.getTargetEl())).collect(Collectors.toCollection(HashSet::new));
    }

    @Override
    public HashSet<String> getSource() {
        return format.getSource().stream().map(universalSet::get).collect(Collectors.toCollection(HashSet::new));
    }

    @Override
    public HashSet<String> getTarget() {
        return format.getTarget().stream().map(universalSet::get).collect(Collectors.toCollection(HashSet::new));
    }

    @Override
    public IRelation getElRange(String el) {
        int elIdx = universalSet.indexOf(el);
        int eIdx = addToUniversal("e");
        return new SSRelation(
                new IntFormat(new HashSet<>(List.of(eIdx)), format.getTarget()),
                new IntPairSet(pairs.getElements().stream().filter(pair -> pair.getSourceEl() == elIdx).map(pair -> new IntPair(eIdx, pair.getTargetEl())).collect(Collectors.toCollection(HashSet::new)))
        );
    }

    @Override
    public boolean isHomogeneous() {
        return format.isHomogeneous();
    }

    @Override
    public double getDensity() {
        return pairs.size() * 1d / (format.rows() * format.cols());
    }

    @Override
    public String getMatrixText() {
        StringBuilder matrixText = new StringBuilder();
        for (String object : getSource()) {
            for (String attribute : getTarget()) {
                if (pairs.contains(new IntPair(universalSet.indexOf(object), universalSet.indexOf(attribute)))) {
                    matrixText.append("1 ");
                } else {
                    matrixText.append("0 ");
                }
            }
            matrixText.append("\n");
        }
        return matrixText.toString();
    }

    @Override
    public double[][] getDoubleMatrix() {
        double[][] data = new double[format.rows()][format.cols()];
        String[] source = getSource().toArray(new String[0]);
        String[] target = getTarget().toArray(new String[0]);

        for (int i = 0; i < source.length; i++) {
            for (int j = 0; j < target.length; j++) {
                if (pairs.contains(new IntPair(universalSet.indexOf(source[i]), universalSet.indexOf(target[j])))) {
                    data[i][j] = 1;
                } else {
                    data[i][j] = 0;
                }
            }
        }
        return data;
    }
}
