package uk.co.joshid.calculusofrelations.backend.repository;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class PosetRepository {
    private final List<byte[]> posets = new ArrayList<>();

    public byte[] get(int id) {
        return posets.get(id);
    }

    public int save(byte[] poset) {
        posets.add(poset);
        return posets.size() - 1;
    }

    public void deleteAll() {
        posets.clear();
    }

}
