package uk.co.joshid.calculusofrelations.backend.services.rca;

import lombok.Data;

@Data
public class ObjRelationData {

    private final ScalingOperator scalingOperator;
    private final String name;
}
