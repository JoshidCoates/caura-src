package uk.co.joshid.calculusofrelations.backend.processing.nonmatrix;


import lombok.Value;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Value
public class IntPair {

    int sourceEl;
    int targetEl;

    public IntPair reverse() {
        return new IntPair(targetEl, sourceEl);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 31).append(sourceEl).append(targetEl).toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof IntPair p))
            return false;
        if (obj == this)
            return true;

        return p.sourceEl == sourceEl && targetEl == p.targetEl;
    }

}
