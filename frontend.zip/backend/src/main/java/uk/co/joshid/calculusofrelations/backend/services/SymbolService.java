package uk.co.joshid.calculusofrelations.backend.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.joshid.calculusofrelations.backend.model.RelationInfo;
import uk.co.joshid.calculusofrelations.backend.repository.RelationRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SymbolService {

    private final RelationRepository relationRepository;

    public List<Character> usedSymbols() {
        return relationRepository.findAllInfo().stream().map(RelationInfo::getSymbol).toList();
    }

    public char getNewSymbol() {
        List<Character> usedSymbols = usedSymbols();
        for (char symbol = 'A'; symbol <= 'Z'; symbol++) {
            if (!usedSymbols.contains(symbol)) {
                return symbol;
            }
        }
        return '!';
    }
}
