package uk.co.joshid.calculusofrelations.backend.processing.nonmatrix;


import lombok.Value;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Value
public class SPair {

    String sourceEl;
    String targetEl;

    public SPair reverse() {
        return new SPair(targetEl, sourceEl);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 31).append(sourceEl).append(targetEl).toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof SPair p))
            return false;
        if (obj == this)
            return true;

        return new EqualsBuilder().append(sourceEl, p.sourceEl).append(targetEl, p.targetEl).isEquals();
    }

}
