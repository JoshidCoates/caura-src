package uk.co.joshid.calculusofrelations.backend.command;

import lombok.Data;
import uk.co.joshid.calculusofrelations.backend.processing.RelationType;

@Deprecated
@Data
public class ConceptsCommand {
    private int relationId;
    private RelationType relationType;
}
