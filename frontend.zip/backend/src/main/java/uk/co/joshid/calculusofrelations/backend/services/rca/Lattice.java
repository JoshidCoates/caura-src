package uk.co.joshid.calculusofrelations.backend.services.rca;

import lombok.Data;

@Deprecated
@Data
public class Lattice {


}
