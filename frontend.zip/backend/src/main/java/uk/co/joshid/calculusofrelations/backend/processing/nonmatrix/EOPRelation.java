package uk.co.joshid.calculusofrelations.backend.processing.nonmatrix;

import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class EOPRelation extends IRelation {

    protected final RSet pairs;
    protected final SFormat format;

    public EOPRelation(SFormat format, RSet pairs) {
        this.format = format;
        this.pairs = pairs;
    }

    @Override
    public IRelation union(IRelation otherRelation) {
        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
        return new EOPRelation(format.union(otherEOPRelation.format), pairs.union(otherEOPRelation.pairs));
    }

    @Override
    public IRelation complement() {
        return new EOPRelation(format, ((EOPRelation) universalRelation()).pairs.relativeComplement(pairs));
    }

    @Override
    public IRelation intersection(IRelation otherRelation) {
        // todo work out if format should have intersection or union
        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
        return new EOPRelation(format.intersection(otherEOPRelation.format), pairs.intersection(otherEOPRelation.pairs));
    }

    @Override
    public IRelation difference(IRelation otherRelation)  {
        return intersection(otherRelation.complement());
    }
//
//    @Override
//    public IRelation symmetricDifference(IRelation otherRelation) {
//        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
//        return difference(otherEOPRelation).union(otherEOPRelation.difference(this));
//    }

    @Override
    public IRelation composition(IRelation otherRelation) {
        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
        HashSet<SPair> selfElements = new HashSet<>(pairs.getElements());
        HashSet<SPair> otherElements = new HashSet<>(otherEOPRelation.pairs.getElements());
        HashSet<SPair> composedElements = new HashSet<>();
        for (SPair selfPair : selfElements) {
            for (SPair otherPair : otherElements) {
                if (selfPair.getTargetEl().equals(otherPair.getSourceEl())) {
                    composedElements.add(new SPair(selfPair.getSourceEl(), otherPair.getTargetEl()));
                }
            }
        }
        return new EOPRelation(new SFormat(format.getSource(), otherEOPRelation.format.getTarget()), new RSet(composedElements));
    }

//    @Override
//    public IRelation sum(IRelation otherRelation) {
//        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
//        return complement().composition(otherEOPRelation.complement()).complement(); // todo this might not work for different U
//    }

    @Override
    public IRelation converse() {
        HashSet<SPair> reversedSet = new HashSet<>(pairs.getElements().stream().map(SPair::reverse).toList());
        return new EOPRelation(new SFormat(format.getTarget(), format.getSource()), new RSet(reversedSet));
    }

//    @Override
//    public IRelation leftResidual(IRelation otherRelation) {
//        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
//        return converse().composition(otherEOPRelation.complement()).complement();
//    }
//
//    @Override
//    public IRelation rightResidual(IRelation otherRelation) {
//        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
//        return complement().composition(otherEOPRelation.converse()).complement();
//    }
//
//    @Override
//    public IRelation symmetricQuotient(IRelation otherRelation) {
//        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
//        return leftResidual(otherEOPRelation).intersection(complement().leftResidual(otherEOPRelation.complement()));
//    }
//
//
//    @Override
//    public IRelation dual() {
//        return complement().converse();
//    }

    @Override
    public IRelation transitiveClosure() {
        IRelation closure = this;
        boolean findingClosure = true;
        int step = 1;
        while (findingClosure) {
            IRelation newPart = this;
            for (int i = 0; i < step; i++) {
                newPart = composition(newPart);
            }
            IRelation newClosure = closure.union(newPart);
            if (closure.isEqual(newClosure)) {
                findingClosure = false;
            } else {
                closure = newClosure;
            }
            step++;
        }
        return closure;
    }
    // todo these closures might not work
    @Override
    public IRelation reflexiveTransitiveClosure() { // todo this will definitely give an odd result
        return sourceIdentityRelation().union(transitiveClosure());
    }

    @Override
    public boolean isSubsetOf(IRelation otherRelation) {
        // todo maybe use R ⊆ S if and only if R ∪ S = S
        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
        return otherEOPRelation.pairs.contains(pairs);
    }

    @Override
    public boolean isProperSubsetOf(IRelation otherRelation) {
        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
        return otherEOPRelation.pairs.contains(pairs) && !otherEOPRelation.pairs.equals(pairs);
    }

    @Override
    public boolean isEqual(IRelation otherRelation) {
        // todo should this return false for different U?
        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
        return pairs.equals(otherEOPRelation.pairs);
    }

    @Override
    public boolean isEmpty() {
        return pairs.size() == 0;
    }




//    @Override
//    public boolean conjugatedQuasiProjection(IRelation otherRelation) {
//        EOPRelation otherEOPRelation = (EOPRelation) otherRelation;
//        return isUnivalent() && otherEOPRelation.isUnivalent() && converse().composition(otherEOPRelation).isEqual(universalRelation(format)); // todo this definitely won't work
//    }

    @Override
    public IRelation sourceIdentityRelation() {
        HashSet<SPair> identityPairs = new HashSet<>();
        for (String el : format.getSource()) {
            identityPairs.add(new SPair(el, el));
        }
        return new EOPRelation(new SFormat(format.getSource(), format.getSource()), new RSet(identityPairs));
    }
    @Override
    public IRelation targetIdentityRelation() {
        HashSet<SPair> identityPairs = new HashSet<>();
        for (String el : format.getTarget()) {
            identityPairs.add(new SPair(el, el));
        }
        return new EOPRelation(new SFormat(format.getTarget(), format.getTarget()), new RSet(identityPairs));
    }

    @Override
    public IRelation sourceEmptyRelation() {
        return new EOPRelation(new SFormat(format.getSource(), format.getSource()), new RSet());
    }
    @Override
    public IRelation targetEmptyRelation() {
        return new EOPRelation(new SFormat(format.getTarget(), format.getTarget()), new RSet());
    }

    public IRelation universalRelation() {
        HashSet<SPair> allPairs = new HashSet<>();
        for (String sourceEl : format.getSource()) {
            for (String targetEl : format.getTarget()) {
                allPairs.add(new SPair(sourceEl, targetEl));
            }
        }
        return new EOPRelation(format, new RSet(allPairs));
    }

    @Override
    public IRelation sourceUniversalRelation() {
        HashSet<SPair> allPairs = new HashSet<>();
        for (String sourceEl : format.getSource()) {
            for (String targetEl : format.getSource()) {
                allPairs.add(new SPair(sourceEl, targetEl));
            }
        }
        return new EOPRelation(new SFormat(format.getSource(), format.getSource()), new RSet(allPairs));
    }
    @Override
    public IRelation targetUniversalRelation() {
        HashSet<SPair> allPairs = new HashSet<>();
        for (String sourceEl : format.getTarget()) {
            for (String targetEl : format.getTarget()) {
                allPairs.add(new SPair(sourceEl, targetEl));
            }
        }
        return new EOPRelation(new SFormat(format.getTarget(), format.getTarget()), new RSet(allPairs));
    }

    @Override
    public IRelation sourceDiversityRelation() {
        return sourceIdentityRelation().complement();
    }
    @Override
    public IRelation targetDiversityRelation() {
        return targetIdentityRelation().complement();
    }

    @Override
    public HashSet<String> getDomain() {
        return pairs.getElements().stream().map(SPair::getSourceEl).collect(Collectors.toCollection(HashSet::new));

    }

    @Override
    public HashSet<String> getRange() {
        return pairs.getElements().stream().map(SPair::getTargetEl).collect(Collectors.toCollection(HashSet::new));
    }

    @Override
    public HashSet<String> getSource() {
        return format.getSource();
    }

    @Override
    public HashSet<String> getTarget() {
        return format.getTarget();
    }

    @Override
    public IRelation getElRange(String el) {
        IRelation h = new EOPRelation(new SFormat(format.getSource(), new HashSet<>(List.of("e"))), new RSet(List.of(new SPair(el, "e"))));
        return h.converse().composition(this);
//        return new EOPRelation(
//                new SFormat(new HashSet<>(List.of("e")), format.getTarget()),
//                new RSet(pairs.getElements().stream().filter(pair -> pair.getSourceEl().equals(el)).map(pair -> new SPair("e", pair.getTargetEl())).collect(Collectors.toCollection(HashSet::new)))
//        );
    }

    @Override
    public boolean isHomogeneous() {
        return format.isHomogeneous();
    }

    @Override
    public double getDensity() {
        return pairs.size() * 1d / (format.rows() * format.cols());
    }

    @Override
    public String getMatrixText() {
        StringBuilder matrixText = new StringBuilder();
        for (String object : format.getSource()) {
            for (String attribute : format.getTarget()) {
                if (pairs.contains(new SPair(object, attribute))) {
                    matrixText.append("1 ");
                } else {
                    matrixText.append("0 ");
                }
            }
            matrixText.append("\n");
        }
        return matrixText.toString();
    }

    @Override
    public double[][] getDoubleMatrix() {
        double[][] data = new double[format.rows()][format.cols()];
        List<String> source = format.getSource().stream().toList();
        List<String> target = format.getTarget().stream().toList();

        for (int i = 0; i < source.size(); i++) {
            for (int j = 0; j < target.size(); j++) {
                if (pairs.contains(new SPair(source.get(i), target.get(j)))) {
                    data[i][j] = 1;
                } else {
                    data[i][j] = 0;
                }
            }
        }
        return data;
    }

}
