package uk.co.joshid.calculusofrelations.backend.repository;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Repository;
import uk.co.joshid.calculusofrelations.backend.model.SessionData;

@Repository
@Getter
@Setter
public class SessionRepository {
    private SessionData sessionData = new SessionData();
}
