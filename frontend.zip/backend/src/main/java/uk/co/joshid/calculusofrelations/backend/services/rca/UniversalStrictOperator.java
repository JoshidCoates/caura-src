package uk.co.joshid.calculusofrelations.backend.services.rca;

import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;

public class UniversalStrictOperator implements ScalingOperator {

    @Override
    public String getSymbol() {
        return "&forall;&exist;";
    }
    @Override
    public String toAttributeString(Concept concept, ObjRelationData objRelationData, String latticeName) {
        return getSymbol() + objRelationData.getName() + " : " + concept.getName();
    }

    @Override
    public boolean matchesConstraint(IRelation objRange, Concept concept) {
        return objRange.getRange().size() > 0 && objRange.converse().isSubsetOf(concept.getObjects());
    }
}
