package uk.co.joshid.calculusofrelations.backend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import uk.co.joshid.calculusofrelations.backend.processing.RelationType;

@Data
@AllArgsConstructor
public class SessionData {
    private RelationType relationType;
    public SessionData() {
        this.relationType = RelationType.SHARED_SET_RELATION;
    }
}
