package uk.co.joshid.calculusofrelations.backend.processing.calculation;

import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.PRelation;

public record StepRelation(IRelation relation,
                           String calculation) {
}
