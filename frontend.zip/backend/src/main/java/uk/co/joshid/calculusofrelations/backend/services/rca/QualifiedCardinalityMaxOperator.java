package uk.co.joshid.calculusofrelations.backend.services.rca;

import lombok.AllArgsConstructor;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;

@AllArgsConstructor
public class QualifiedCardinalityMaxOperator implements ScalingOperator {
    private int n;

    @Override
    public String getSymbol() {
        return "≥" + n;
    }
    @Override
    public String toAttributeString(Concept concept, ObjRelationData objRelationData, String latticeName) {
        return getSymbol() + " " + objRelationData.getName() + " : " + concept.getName();
    }

    @Override
    public boolean matchesConstraint(IRelation objRange, Concept concept) {
        return objRange.getRange().size() >= n && objRange.converse().isSubsetOf(concept.getObjects());
    }
}
