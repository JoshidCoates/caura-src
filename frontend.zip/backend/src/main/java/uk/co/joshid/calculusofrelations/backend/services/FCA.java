package uk.co.joshid.calculusofrelations.backend.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.joshid.calculusofrelations.backend.exception.RelationNotFound;
import uk.co.joshid.calculusofrelations.backend.graphviz.GraphViz;
import uk.co.joshid.calculusofrelations.backend.model.Relation;
import uk.co.joshid.calculusofrelations.backend.repository.RelationRepository;
import uk.co.joshid.calculusofrelations.backend.repository.XMLRepository;
import uk.co.joshid.calculusofrelations.backend.services.rca.PosetGeneration;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

@Service
@RequiredArgsConstructor
public class FCA {
    private final PosetBuilder posetBuilder;
    private final RelationRepository relationRepository;
    private final XMLRepository xmlRepository;

    public byte[] execute(int relationId) throws IOException {
        Relation relation = relationRepository.findById(relationId).orElseThrow(RelationNotFound::new);
        PosetGeneration posetGeneration = posetBuilder.execute(relation.getRelation());
        String xml = posetBuilder.buildXML(posetGeneration);
        xmlRepository.save(relationId, xml);
        if (relation.getRelationInfo().getRows() * relation.getRelationInfo().getCols() <= 4000) {
            String dot = posetBuilder.buildDot(posetGeneration, false);
            GraphViz gv = new GraphViz();
            gv.add(dot);
            String type = "png";
            File out = new File("out." + type);
            gv.writeGraphToFile(gv.getGraph(gv.getDotSource(), type, "dot"), out);
            return Files.readAllBytes(out.toPath());
        }
        return new byte[1];
    }
}
