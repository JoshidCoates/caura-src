package uk.co.joshid.calculusofrelations.backend.command;

import lombok.Data;
import uk.co.joshid.calculusofrelations.backend.processing.RelationType;
import uk.co.joshid.calculusofrelations.backend.services.rca.ScalingOperatorType;

import java.util.List;

@Data
public class RCACommand {
    private List<Integer> contexts;
    private List<Integer> objToObjRelations;
    private List<ScalingOperatorType> scalingOperators;
    private boolean performLabelReduction;
}
