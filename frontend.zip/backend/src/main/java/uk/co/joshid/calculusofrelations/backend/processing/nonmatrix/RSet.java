package uk.co.joshid.calculusofrelations.backend.processing.nonmatrix;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;

public class RSet {

    private final HashSet<SPair> elements;

    public RSet(HashSet<SPair> elements) {
        this.elements = elements;
    }

    public RSet(Collection<SPair> elements) {
//        System.out.println("Get 4.75");
//        System.out.println(System.currentTimeMillis());
        this.elements = new HashSet<>(elements);
//        System.out.println("Get 4.8");
//        System.out.println(System.currentTimeMillis());
    }

    public RSet(SPair[] elements) {
        this.elements = new HashSet<>(Arrays.asList(elements));
    }


    public RSet() {
        this.elements = new HashSet<>();
    }

    public HashSet<SPair> getElements() {
        return elements;
    }

    public int size() {
        return elements.size();
    }

    /**
     * @param otherSet S
     * @return self ∪ S
     */
    public RSet union(RSet otherSet) {
        HashSet<SPair> unionSet = new HashSet<>(elements);
        unionSet.addAll(otherSet.elements);
        return new RSet(unionSet);
    }
    @Deprecated
    public RSet union(HashSet<SPair> otherSet) {
        HashSet<SPair> unionSet = new HashSet<>(elements);
        unionSet.addAll(otherSet);
        return new RSet(unionSet);
    }


    /**
     * @param otherSet S
     * @return self ∩ S
     */
    public RSet intersection(RSet otherSet) {
        HashSet<SPair> intersectSet = new HashSet<>(elements);
        intersectSet.retainAll(otherSet.elements);
        return new RSet(intersectSet);
    }

    /**
     * @param otherSet S
     * @return self \ S
     */
    public RSet relativeComplement(RSet otherSet) {
        HashSet<SPair> differenceSet = new HashSet<>(elements);
        differenceSet.removeAll(otherSet.elements);
        return new RSet(differenceSet);
    }


    /**
     * S ⊆ R
     * @param otherSet S
     * @return S ⊆ self
     */
    public boolean contains(RSet otherSet) {
        return elements.containsAll(otherSet.elements);
    }

    public boolean contains(SPair el) {
        return elements.contains(el);
    }

    /**
     * R = S
     * @param otherSet S
     * @return self = S
     */
    public boolean equals(RSet otherSet) {
        return elements.equals(otherSet.elements);
    }

}
