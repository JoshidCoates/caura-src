package uk.co.joshid.calculusofrelations.backend.repository;

import org.springframework.stereotype.Repository;
import uk.co.joshid.calculusofrelations.backend.exception.RelationNotFound;
import uk.co.joshid.calculusofrelations.backend.model.Relation;
import uk.co.joshid.calculusofrelations.backend.model.RelationInfo;

import java.util.*;

@Repository
public class XMLRepository {
    private final Map<Integer, String> xmls = new HashMap<>();

    public String getById(int id) {
        return xmls.get(id);
    }

    public void save(int relationId, String xml) {
        xmls.put(relationId, xml);
    }

    public void delete(int relationId) {
        xmls.remove(relationId);
    }

    public void deleteAll() {
        xmls.clear();
    }


}
