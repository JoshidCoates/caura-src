package uk.co.joshid.calculusofrelations.backend.command;

public record CalculationCommand(String calculation) {
}
