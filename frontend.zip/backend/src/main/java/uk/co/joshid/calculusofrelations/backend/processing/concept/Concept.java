package uk.co.joshid.calculusofrelations.backend.processing.concept;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;

import java.util.List;
import java.util.Set;

@RequiredArgsConstructor
@Getter
public class Concept {

    private final Set<Concept> superConcepts;
    private final IRelation relation;
    private final String el;

    public void addSuperConcept(Concept superConcept) {
        superConcepts.add(superConcept);
    }

}
