package uk.co.joshid.calculusofrelations.backend.processing.nonmatrix;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;

public class IntPairSet {

    private final HashSet<IntPair> elements;

    public IntPairSet(HashSet<IntPair> elements) {
        this.elements = elements;
    }

    public IntPairSet(Collection<IntPair> elements) {
        this.elements = new HashSet<>(elements);
    }

    public IntPairSet(IntPair[] elements) {
        this.elements = new HashSet<>(Arrays.asList(elements));
    }


    public IntPairSet() {
        this.elements = new HashSet<>();
    }

    public HashSet<IntPair> getElements() {
        return elements;
    }

    public int size() {
        return elements.size();
    }

    /**
     * @param otherSet S
     * @return self ∪ S
     */
    public IntPairSet union(IntPairSet otherSet) {
        HashSet<IntPair> unionSet = new HashSet<>(elements);
        unionSet.addAll(otherSet.elements);
        return new IntPairSet(unionSet);
    }
    @Deprecated
    public IntPairSet union(HashSet<IntPair> otherSet) {
        HashSet<IntPair> unionSet = new HashSet<>(elements);
        unionSet.addAll(otherSet);
        return new IntPairSet(unionSet);
    }


    /**
     * @param otherSet S
     * @return self ∩ S
     */
    public IntPairSet intersection(IntPairSet otherSet) {
        HashSet<IntPair> intersectSet = new HashSet<>(elements);
        intersectSet.retainAll(otherSet.elements);
        return new IntPairSet(intersectSet);
    }

    /**
     * @param otherSet S
     * @return self \ S
     */
    public IntPairSet relativeComplement(IntPairSet otherSet) {
        HashSet<IntPair> differenceSet = new HashSet<>(elements);
        differenceSet.removeAll(otherSet.elements);
        return new IntPairSet(differenceSet);
    }


    /**
     * S ⊆ R
     * @param otherSet S
     * @return S ⊆ self
     */
    public boolean contains(IntPairSet otherSet) {
        return elements.containsAll(otherSet.elements);
    }

    public boolean contains(IntPair el) {
        return elements.contains(el);
    }

    /**
     * R = S
     * @param otherSet S
     * @return self = S
     */
    public boolean equals(IntPairSet otherSet) {
        return elements.equals(otherSet.elements);
    }

}
