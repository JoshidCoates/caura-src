package uk.co.joshid.calculusofrelations.backend.processing.nonmatrix;

@Deprecated
public interface RelPair {


     RelPair reverse();
}
