package uk.co.joshid.calculusofrelations.backend.services.rca;

import lombok.AllArgsConstructor;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;

@AllArgsConstructor
public class CardinalityMinOperator implements ScalingOperator {
    private int n;

    @Override
    public String getSymbol() {
        return "≤" + n;
    }

    @Override
    public String toAttributeString(Concept concept, ObjRelationData objRelationData, String latticeName) {
        return getSymbol() + " " + objRelationData.getName() + " : T" + latticeName;
    }

    @Override
    public boolean matchesConstraint(IRelation objRange, Concept concept) {
        return objRange.getRange().size() <= n;
    }
}
