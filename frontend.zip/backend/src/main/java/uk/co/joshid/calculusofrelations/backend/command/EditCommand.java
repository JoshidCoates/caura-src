package uk.co.joshid.calculusofrelations.backend.command;

import lombok.Data;

@Data
public class EditCommand {
    private final int relationId;
    private final char symbol;
    private final String name;
}
