package uk.co.joshid.calculusofrelations.backend.services.rca;

import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;

public class ExistentialOperator implements ScalingOperator {

    @Override
    public String getSymbol() {
        return "&#8707;";
    }
    @Override
    public String toAttributeString(Concept concept, ObjRelationData objRelationData, String latticeName) {
        return getSymbol() + objRelationData.getName() + " : " + concept.getName();
    }

    @Override
    public boolean matchesConstraint(IRelation objRange, Concept concept) {
//        IRelation one = objRange.converse();
//        IRelation two = concept.getObjects();
//        IRelation three = one.intersection(two);
//        boolean four = three.isEmpty();
//        boolean five = !four;
//        if (concept.getName().equals("c_F3")) {
//            System.out.println("hi");
//        }

        return !objRange.converse().intersection(concept.getObjects()).isEmpty();
    }
}
