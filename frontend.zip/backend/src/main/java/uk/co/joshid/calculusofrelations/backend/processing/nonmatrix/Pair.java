package uk.co.joshid.calculusofrelations.backend.processing.nonmatrix;


import lombok.Value;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Value
public class Pair {

    int rowNo;
    int colNo;

    public Pair reverse() {
        return new Pair(colNo, rowNo);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 31).append(rowNo).append(colNo).toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Pair p))
            return false;
        if (obj == this)
            return true;

        return new EqualsBuilder().append(rowNo, p.rowNo).append(colNo, p.colNo).isEquals();
    }

}
