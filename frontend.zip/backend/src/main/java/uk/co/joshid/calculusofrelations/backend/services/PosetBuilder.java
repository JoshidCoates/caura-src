package uk.co.joshid.calculusofrelations.backend.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.*;
import uk.co.joshid.calculusofrelations.backend.repository.SessionRepository;
import uk.co.joshid.calculusofrelations.backend.services.rca.Concept;
import uk.co.joshid.calculusofrelations.backend.services.rca.PosetGeneration;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PosetBuilder {

    private final SessionRepository sessionRepository;

//    private static long oneTime = 0;
//    private static long twoTime = 0;
//    private static long threeTime = 0;
//    private static long fourTime = 0;
//    private static long cTime = System.currentTimeMillis();

    public PosetGeneration execute(IRelation iRelation) {
        return execute(iRelation, "");
    }

    public PosetGeneration execute(IRelation iRelation, String name) {
        String[] source = iRelation.getSource().toArray(new String[0]);
        String[] target = iRelation.getTarget().toArray(new String[0]);

        long outerTime = System.currentTimeMillis();

        List<Concept> poset = new ArrayList<>();
//        long firstTime = 0;
//        long secondTime = 0;
//        long thirdTime = 0;
//        long fourthTime = 0;
//        long currentTime = System.currentTimeMillis();
        int nameCounter = 0;
        IRelation iRelationComplement = iRelation.complement();
        for (String sourceEl : source) {
            IRelation h = switch (sessionRepository.getSessionData().getRelationType()) {
                case PAIR_RELATION -> new PRelation(new SFormat(iRelation.getSource(), new HashSet<>(List.of("e"))), new RSet(List.of(new SPair(sourceEl, "e"))));
                case EO_PAIR_RELATION -> new EOPRelation(new SFormat(iRelation.getSource(), new HashSet<>(List.of("e"))), new RSet(List.of(new SPair(sourceEl, "e"))));
                case SHARED_SET_RELATION -> new SSRelation(new SFormat(iRelation.getSource(), new HashSet<>(List.of("e"))), new RSet(List.of(new SPair(sourceEl, "e"))));
                case EO_SHARED_SET_RELATION -> new EOSSRelation(new SFormat(iRelation.getSource(), new HashSet<>(List.of("e"))), new RSet(List.of(new SPair(sourceEl, "e"))));
            };

//            currentTime = System.currentTimeMillis();
            IRelation derivation = objectDerivationOperator(h, iRelationComplement);
//            firstTime += System.currentTimeMillis() - currentTime;
//            currentTime = System.currentTimeMillis();
            IRelation extentClosure = attributeDerivationOperator(derivation, iRelationComplement);
//            secondTime += System.currentTimeMillis() - currentTime;

            boolean conceptExists = false;
            for (Concept concept : poset) {
                if (extentClosure.isEqual(concept.getObjects())) {
                    concept.getO().add(sourceEl);
                    conceptExists = true;
                    break;
                }
            }

            if (!conceptExists) {
                poset.add(new Concept(extentClosure, derivation, new ArrayList<>(List.of(sourceEl)), new ArrayList<>(), "c_" + name + nameCounter));
                nameCounter++;
            }
        }
        System.out.println("source " + (System.currentTimeMillis() - outerTime));
        outerTime = System.currentTimeMillis();


        for (String targetEl : target) {
            IRelation n = switch (sessionRepository.getSessionData().getRelationType()) {
                case PAIR_RELATION -> new PRelation(new SFormat(new HashSet<>(List.of("e")), iRelation.getTarget()), new RSet(List.of(new SPair("e", targetEl))));
                case EO_PAIR_RELATION -> new EOPRelation(new SFormat(new HashSet<>(List.of("e")), iRelation.getTarget()), new RSet(List.of(new SPair("e", targetEl))));
                case SHARED_SET_RELATION -> new SSRelation(new SFormat(new HashSet<>(List.of("e")), iRelation.getTarget()), new RSet(List.of(new SPair("e", targetEl))));
                case EO_SHARED_SET_RELATION -> new EOSSRelation(new SFormat(new HashSet<>(List.of("e")), iRelation.getTarget()), new RSet(List.of(new SPair("e", targetEl))));
            };



//            currentTime = System.currentTimeMillis();
            IRelation derivation = attributeDerivationOperator(n, iRelationComplement);
//            thirdTime += System.currentTimeMillis() - currentTime;
//            currentTime = System.currentTimeMillis();
//            fourthTime += System.currentTimeMillis() - currentTime;


            boolean conceptExists = false;
            for (Concept concept : poset) {
                if (concept.getObjects().isEqual(derivation)) {
                    concept.getA().add(targetEl);
                    conceptExists = true;
                    break;
                }
            }

            IRelation intentClosure = objectDerivationOperator(derivation, iRelationComplement);


            if (!conceptExists) {
                poset.add(new Concept(derivation, intentClosure, new ArrayList<>(), new ArrayList<>(List.of(targetEl)), "c_" + name + nameCounter));
                nameCounter++;
            }
        }
//        System.out.println("1 " + firstTime);
//        System.out.println("2 " + secondTime);
//        System.out.println("3 " + thirdTime);
//        System.out.println("4 " + fourthTime);
//        System.out.println("1o " + oneTime);
//        System.out.println("2o " + twoTime);
//        System.out.println("3o " + threeTime);
//        System.out.println("4o " + fourTime);
        System.out.println("target " + (System.currentTimeMillis() - outerTime));
        outerTime = System.currentTimeMillis();


        boolean[][] edges = new boolean[poset.size()][poset.size()];


        for (int i = 0; i < poset.size(); i++) {
            for (int j = i + 1; j < poset.size(); j++) {
                if (poset.get(i).getObjects().isProperSubsetOf(poset.get(j).getObjects())) {
                    edges[i][j] = true;
                } else if (poset.get(j).getObjects().isProperSubsetOf(poset.get(i).getObjects())) {
                    edges[j][i] = true;
                }

            }

        }
        System.out.println("subset " + (System.currentTimeMillis() - outerTime));
        outerTime = System.currentTimeMillis();

//        // transitive closure
//        for (int i = 0; i < edges.length; i++) {
//            for (int j = 0; j < edges.length; j++) {
//                for (int l = 0; l < edges.length; l++) {
//                    edges[j][l] = edges[j][l] || (edges[j][i] && edges[i][l]);
//                }
//            }
//        }

        // transitive reduction
        for (int i = 0; i < edges.length; i++) {
            for (int j = 0; j < edges.length; j++) {
                if (edges[j][i]) {
                    for (int l = 0; l < edges.length; l++) {
                        if (edges[i][l]) {
                            edges[j][l] = false;
                        }
                    }
                }

            }
        }


        System.out.println("reduction " + (System.currentTimeMillis() - outerTime));
        outerTime = System.currentTimeMillis();
        return new PosetGeneration(edges, source, target, poset);
    }

//    public ConceptResponse execute(ConceptsCommand conceptsCommand) {
////        System.out.println(System.currentTimeMillis());
////        System.out.println(1);
//        Relation relation = getRelation.execute(conceptsCommand.getRelationId(), conceptsCommand.getRelationType());
//        IRelation iRelation = relationTransformer.toIRelation(relation, conceptsCommand.getRelationType());
//        LatticeGeneration latticeGeneration = execute(iRelation);
//
//
//        String dot = buildDot(latticeGeneration.getLatticeConcepts(), latticeGeneration.getEdges());
//        String xml = buildXML(latticeGeneration.getSource(), latticeGeneration.getTarget(), latticeGeneration.getLatticeConcepts(), latticeGeneration.getEdges());
////        System.out.println(6);
////        System.out.println(System.currentTimeMillis());
//
//        return new ConceptResponse(dot, xml);
//
//    }



    private IRelation objectDerivationOperator(IRelation objects, IRelation iCompl) {
//        cTime = System.currentTimeMillis();
//        IRelation one = objects.converse();
//        oneTime += System.currentTimeMillis() - cTime;
//        cTime = System.currentTimeMillis();
//        IRelation two = iCompl;
//        twoTime += System.currentTimeMillis() - cTime;
//        cTime = System.currentTimeMillis();
//        IRelation three = one.composition(two);
//        threeTime += System.currentTimeMillis() - cTime;
//        cTime = System.currentTimeMillis();
//        IRelation four = three.complement();
//        fourTime += System.currentTimeMillis() - cTime;
//        cTime = System.currentTimeMillis();
//        return four;
        return objects.converse().composition(iCompl).complement();
    }

    private IRelation attributeDerivationOperator(IRelation attributes, IRelation iCompl) {
        return iCompl.composition(attributes.converse()).complement();
    }

    public String buildDot(PosetGeneration posetGeneration, boolean showConceptNames) {
        StringBuilder dot = new StringBuilder("digraph G { node[fontname=\"Segoe UI\",shape=record,color=black]; edge[arrowhead=none]; rankdir=BT;");

        for (int i = 0; i < posetGeneration.getConcepts().size(); i++) {
            StringBuilder oText = new StringBuilder();
            StringBuilder aText = new StringBuilder();
            posetGeneration.getConcepts().get(i).getO().forEach(o -> oText.append(o).append("\\n"));
            posetGeneration.getConcepts().get(i).getA().forEach(a -> aText.append(a).append("\\n"));

            if (showConceptNames) {
                dot.append(i).append(" [label=\"{").append(posetGeneration.getConcepts().get(i).getName()).append("|").append(aText).append("|").append(oText).append("}\"]; ");
            } else {
                dot.append(i).append(" [label=\"{").append(aText).append("|").append(oText).append("}\"]; ");
            }
        }
        for (int i = 0; i < posetGeneration.getEdges().length; i++) {
            for (int j = 0; j < posetGeneration.getEdges().length; j++) {
                if (posetGeneration.getEdges()[i][j]) dot.append(i).append(" -> ").append(j).append(";");
            }
        }
        dot.append("}");

        return dot.toString();

    }

    public String buildXML(PosetGeneration posetGeneration) {
        StringBuilder xml = new StringBuilder("<GSH numberObj=\"" + posetGeneration.getSource().length + "\" numberAtt=\"" + posetGeneration.getTarget().length + "\" numberCpt=\"" + posetGeneration.getConcepts().size() + "\">\n");
        for (String s : posetGeneration.getSource()) {
            xml.append("<Object>").append(s).append("</Object>\n");
        }
        for (String t : posetGeneration.getTarget()) {
            xml.append("<Attribute>").append(t).append("</Attribute>\n");
        }
        for (int i = 0; i < posetGeneration.getConcepts().size(); i++) {
            xml.append("<Concept>\n<ID>").append(i).append("</ID>\n<Extent>\n");
            for (String o : posetGeneration.getConcepts().get(i).getObjects().getDomain()) {
                xml.append("<Object_Ref>").append(o).append("</Object_Ref>\n");
            }
            xml.append("</Extent>\n<Intent>\n");
            for (String a : posetGeneration.getConcepts().get(i).getAttributes().getRange()) {
                xml.append("<Attribute_Ref>").append(a).append("</Attribute_Ref>\n");
            }
            xml.append("</Intent>\n<UpperCovers>\n");
            for (int j = 0; j < posetGeneration.getConcepts().size(); j++) {
                if (posetGeneration.getEdges()[i][j]) xml.append("<Concept_Ref>").append(j).append("</Concept_Ref>\n");
            }
            xml.append("</UpperCovers>\n</Concept>\n");

        }
        xml.append("</GSH>");
        return xml.toString();
    }
}
