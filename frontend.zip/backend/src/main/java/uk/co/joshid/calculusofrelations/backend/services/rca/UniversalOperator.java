package uk.co.joshid.calculusofrelations.backend.services.rca;

import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;

public class UniversalOperator implements ScalingOperator {

    @Override
    public String getSymbol() {
        return "∀";
    }
    @Override
    public String toAttributeString(Concept concept, ObjRelationData objRelationData, String latticeName) {
        return getSymbol() + " " + objRelationData.getName() + " : " + concept.getName();
    }

    @Override
    public boolean matchesConstraint(IRelation objRange, Concept concept) {
        return objRange.converse().isSubsetOf(concept.getObjects());
    }

}
