package uk.co.joshid.calculusofrelations.backend.processing.nonmatrix;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;

@Getter
@RequiredArgsConstructor
public abstract class IRelation {

    /**
     * R ∪ S = {(α, β):(α, β) ∈ R or (α, β) ∈ S}
     * @param otherRelation S
     * @return self ∪ S
     */
    public abstract IRelation union(IRelation otherRelation);

    /**
     * ∼R = {(α, β):(α, β) ∈ U × U and (α, β) ∉ R}
     * @return ∼self
     */
    public abstract IRelation complement();

    /**
     * R ∩ S = {(α, β):(α, β) ∈ R and (α, β) ∈ S}
     * R ∩ S = ∼(∼R ∪ ∼S)
     * @param otherRelation S
     * @return self ∩ S
     */
    public abstract IRelation intersection(IRelation otherRelation);

    /**
     * R ∼ S = {(α, β):(α, β) ∈ R and (α, β) ∉ S}
     * R ∼ S = R ∩ ∼S = ∼(∼R ∪ S)
     * @param otherRelation S
     * @return self ∼ S
     */
    public abstract IRelation difference(IRelation otherRelation);

    /**
     * R Δ S = {(α, β):(α, β) ∈ R ∼ S or (α, β) ∈ S ∼ R}
     * R Δ S = (R ∼ S) ∪ (S ∼ R)
     * @param otherRelation S
     * @return self Δ S
     */
    public IRelation symmetricDifference(IRelation otherRelation) {
        return difference(otherRelation).union(otherRelation.difference(this));
    }

    /**
     * R | S = {(α, β):(α, γ) ∈ R and (γ,β) ∈ S for some γ ∈ U}
     * @param otherRelation S
     * @return self | S
     */
    public abstract IRelation composition(IRelation otherRelation);

    /**
     * R † S = {(α, β):(α, γ) ∈ R or (γ,β) ∈ S for all γ ∈ U}
     * R † S = ∼(∼R | ∼S)
     * @param otherRelation S
     * @return self † S
     */
    public IRelation sum(IRelation otherRelation) {
        return complement().composition(otherRelation.complement()).complement();
    }

    /**
     * R⁻¹ = {(α, β):(β,α) ∈ R}
     * @return self⁻¹
     */
    public abstract IRelation converse();

    /**
     * R \ S = ∼(R⁻¹ | ∼S)
     * @param otherRelation S
     * @return self \ S
     */
    public IRelation leftResidual(IRelation otherRelation) {
        return converse().composition(otherRelation.complement()).complement();
    }

    /**
     * R / S = ∼(∼R | S⁻¹)
     * @param otherRelation S
     * @return self / S
     */
    public IRelation rightResidual(IRelation otherRelation) {
        return complement().composition(otherRelation.converse()).complement();
    }

    /**
     * syq(R,S) = (R \ S) ∩ (∼R \ ∼S)
     * @param otherRelation S
     * @return syq(self,S)
     */
    public IRelation symmetricQuotient(IRelation otherRelation) {
        return leftResidual(otherRelation).intersection(dual().composition(otherRelation).complement());
    }


    /**
     * Rᵈ = (∼R)⁻¹
     * @return selfᵈ
     */
    public IRelation dual() {
        return complement().converse();
    }

    public abstract IRelation transitiveClosure();

    public abstract IRelation reflexiveTransitiveClosure();

    /**
     * R ⊆ S
     * @param otherRelation S
     * @return self ⊆ S
     */
    public abstract boolean isSubsetOf(IRelation otherRelation);

    public abstract boolean isProperSubsetOf(IRelation otherRelation);
    
    /**
     * R = S
     * @param otherRelation S
     * @return self = S
     */
    public abstract boolean isEqual(IRelation otherRelation);

    public abstract boolean isEmpty();

//    /**
//     * The pair (α, α) is in R for every element α in U
//     * idU ⊆ R
//     * @return idU ⊆ self
//     */
//    public abstract boolean isReflexive();
//
//    /**
//     * (α, β) ∈ R implies (β,α) ∈ R
//     * R⁻¹ ⊆ R
//     * @return self⁻¹ ⊆ self
//     */
//    public abstract boolean isSymmetric();
//
//    /**
//     * (α, γ) ∈ R and (γ,β) ∈ R implies (α, β) ∈ R
//     * R | R ⊆ R
//     * @return self | self ⊆ self
//     */
//    public abstract boolean isTransitive();
//
//    /**
//     * idU ∪ R⁻¹ ∪ (R | R) ⊆ R
//     * idU ∪ (R | R⁻¹) = R
//     * @return whether it is an equivalence relation
//     */
//    public abstract boolean isEquivalence();
//
//    /**
//     * (α, β) ∈ R and (β,α) ∈ R implies α = β
//     * R ∩ R⁻¹ ⊆ idU
//     * @return self ∩ self⁻¹ ⊆ idU
//     */
//    public abstract boolean isAntiSymmetric();
//
//
//    /**
//     * [(idU ∪ (R | R)) ∼ R] ∪ [(R ∩ R⁻¹) ∼ idU ] = ∅
//     * (idU ∪ (R | R)) ∼ R = ∅ and (R ∩ R⁻¹) ∼ idU = ∅
//     * idU ∪ (R | R) ⊆ R and R ∩ R⁻¹ ⊆ idU
//     * @return whether it is a partial order
//     */
//    public abstract boolean isOrder();

    public boolean isReflexive() {
        return sourceIdentityRelation().isSubsetOf(this);
    }

    public boolean isIrreflexive() { return isSubsetOf(sourceDiversityRelation()); }

    public boolean isSymmetric() {
        return converse().isEqual(this);
    }

    public boolean isAntiSymmetric() {
        return intersection(converse()).isSubsetOf(sourceIdentityRelation());
    }

    public boolean isAsymmetric() {
        return intersection(converse()).isEqual(sourceEmptyRelation());
    }

    public boolean isTransitive() {
        return composition(this).isSubsetOf(this);
    }

    public boolean isEquivalence() {
        return isReflexive() && isSymmetric() && isTransitive();
    }

    public boolean isPreorder() { return isReflexive() && isTransitive(); }

    public boolean isOrder() {
        return isPreorder() && isAntiSymmetric();
    }

    public boolean isStrictOrder() { return isAsymmetric() && isTransitive(); }

    public boolean isSemiConnex() { return sourceDiversityRelation().isSubsetOf(union(converse())); }

    public boolean isConnex() { return union(converse()).isEqual(sourceUniversalRelation()); }

    public boolean isTournament() { return isAsymmetric() && isSemiConnex(); }

    public boolean isLinearOrder() { return isOrder() && isConnex(); }

    public boolean isLinearStrictOrder() { return isStrictOrder() && isSemiConnex(); }

    public boolean isIdempotent() { return isEqual(composition(this)); }

//    /**
//     * (α, β) ∈ R and (α, γ) ∈ R implies β = γ
//     * R⁻¹ | R ⊆ idU
//     * AKA univalent
//     * @return self⁻¹ | self ⊆ idU
//     */
//    public abstract boolean isUnivalent();
//
//    /**
//     * (α, γ) ∈ R and (β, γ) ∈ R implies α = β
//     * R | R⁻¹ ⊆ idU
//     * @return self | self⁻¹ ⊆ idU
//     */
//    public abstract boolean isInjective();
//
//    /**
//     * injective and functional
//     * AKA matching
//     * @return whether it is a one-to-one relation
//     */
//    public abstract boolean isOneToOne();
//
//    /**
//     * not injective and functional
//     * @return whether it is a many-to-one relation
//     */
//    public abstract boolean isManyToOne();
//
//    /**
//     * injective and not functional
//     * @return whether it is a one-to-many relation
//     */
//    public abstract boolean isOneToMany();
//
//    /**
//     * not injective and not functional
//     * @return whether it is a many-to-many relation
//     */
//    public abstract boolean isManyToMany();
//
//    /**
//     * U×U = R | (U×U)
//     * idU ⊆ R | R⁻¹
//     * ~R ⊆ R | diU
//     * @return whether it is a total relation
//     */
//    public abstract boolean isTotal();
//
//    /**
//     * U×U = (U×U) | R
//     * idU ⊆ R⁻¹ | R
//     * ~R ⊆ diU | R
//     * AKA onto
//     * @return whether it is an onto relation
//     */
//    public abstract boolean isSurjective();
//
//    /**
//     * R | diU = ~R
//     * total and functional
//     * AKA function
//     * @return whether it is a mapping relation
//     */
//    public abstract boolean isMapping();
//
//    /**
//     * surjective and injective
//     * @return whether it is a bijective relation
//     */
//    public abstract boolean isBijective();
//
//    public abstract boolean isDifunctional();

    public boolean isUnivalent() {
        return converse().composition(this).isSubsetOf(targetIdentityRelation());
    }

    public boolean isInjective() {
        return composition(converse()).isSubsetOf(sourceIdentityRelation()); // todo check that this is the same as the converse being univalent
    }

    public boolean isOneToOne() {
        return isUnivalent() && isInjective();
    }

    public boolean isManyToOne() {
        return isUnivalent() && !isInjective();
    }

    public boolean isOneToMany() {
        return !isUnivalent() && isInjective();
    }

    public boolean isManyToMany() {
        return !isUnivalent() && !isInjective();
    }

    public boolean isTotal() {
//        IRelation universalRelation = universalRelation(format);
////        return composition(universalRelation).isEqual(universalRelation);
        return sourceIdentityRelation().isSubsetOf(composition(converse()));
    }

    public boolean isSurjective() {
//        IRelation universalRelation = universalRelation(format);
//        return universalRelation.composition(this).isEqual(universalRelation);
        return sourceIdentityRelation().isSubsetOf(converse().composition(this));
    }

    public boolean isMapping() {
        return isUnivalent() && isTotal();
    }

    public boolean isBijective() {
        return isSurjective() && isInjective();
    }

    public boolean isDifunctional() {
        return isEqual(composition(converse()).composition(this));
    }

//    /**
//     * R and S are functions with the property that, for any two elements α and β in U, there
//     * is always an element γ in U such that (γ,α) ∈ R and (γ,β) ∈ S
//     * ∼[(R⁻¹ | R) ∪ (S⁻¹ | S)] ∪ idU ] ∩ (R⁻¹ | S) = U × U
//     * ∼[(R⁻¹ | R) ∪ (S⁻¹ | S)] ∪ idU = U × U and R⁻¹ | S = U × U
//     * @param otherRelation S
//     * @return whether self and S are conjugated quasi-projections on U
//     */
//    public abstract boolean conjugatedQuasiProjection(IRelation otherRelation);

    /**
     * idU = {(α, β) : α, β ∈ U and α = β}
     * @return idU
     */
    public abstract IRelation sourceIdentityRelation();
    public abstract IRelation targetIdentityRelation();

    /**
     * ∅ = ∼(∼idU ∪ idU )
     * @return ∅
     */
    public abstract IRelation sourceEmptyRelation();
    public abstract IRelation targetEmptyRelation();


    /**
     * U × U = {(α, β) : α, β ∈ U}
     * U × U = ∼idU ∪ idU
     * @return U × U
     */
    public abstract IRelation sourceUniversalRelation();
    public abstract IRelation targetUniversalRelation();

    /**
     * diU = {(α, β) : α, β ∈ U and α ≠ β}
     * diU = ∼idU
     * @return diU
     */
    public abstract IRelation sourceDiversityRelation();
    public abstract IRelation targetDiversityRelation();

    /**
     * An element α belongs to the domain of an arbitrary relation R on a set U iff the
     * pair (α, α) belongs to the relation R | (U × U)
     * (R | (U × U)) ∩ idU
     * @return left-hand part of all element pairs
     */
    public abstract HashSet<String> getDomain();

    /**
     * An element α belongs to the range of an arbitrary relation R on a set U iff the
     * pair (α, α) belongs to the relation (U × U) | R
     * ((U × U) | R) ∩ idU
     * @return right-hand part of all element pairs
     */
    public abstract HashSet<String> getRange();

    public abstract HashSet<String> getSource();
    public abstract HashSet<String> getTarget();

    public abstract IRelation getElRange(String el);

    public abstract boolean isHomogeneous();

    public abstract double getDensity();

    public LinkedHashMap<String, Boolean> getProperties() {
        LinkedHashMap<String, Boolean> properties = new LinkedHashMap<>();

        if (isHomogeneous()) {
            properties.put("Reflexive", isReflexive());
            properties.put("Irreflexive", isIrreflexive());
            properties.put("Symmetric", isSymmetric());
            properties.put("Anti-symmetric", isAntiSymmetric());
            properties.put("Asymmetric", isAsymmetric());
            properties.put("Transitive", isTransitive());
            properties.put("Equivalence", isEquivalence());
            properties.put("Order", isOrder());
        }

        properties.put("Univalent", isUnivalent());
        properties.put("Injective", isInjective());
        properties.put("Total", isTotal());
        properties.put("Surjective", isSurjective());

        properties.put("One-to-one", isOneToOne());
        properties.put("Many-to-one", isManyToOne());
        properties.put("One-to-many", isOneToMany());
        properties.put("Many-to-many", isManyToMany());
        properties.put("Mapping", isMapping());
        properties.put("Bijective", isBijective());
        properties.put("Difunctional", isDifunctional());

        if (isHomogeneous()) {
            properties.put("Preorder", isPreorder());
            properties.put("Strict order", isStrictOrder());
            properties.put("Semi-connex", isSemiConnex());
            properties.put("Connex", isConnex());
            properties.put("Tournament", isTournament());
            properties.put("Linear order", isLinearOrder());
            properties.put("Linear strict order", isLinearStrictOrder());
            properties.put("Idempotent", isIdempotent());
        }

        return properties;
    }

    public abstract String getMatrixText();

    public abstract double[][] getDoubleMatrix();

}
