package uk.co.joshid.calculusofrelations.backend.services.rca;

public enum ScalingOperatorType {
    EXISTENTIAL,
    UNIVERSAL_STRICT
}
