package uk.co.joshid.calculusofrelations.backend.services.rca;

import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;

public interface ScalingOperator {

    String getSymbol();
    boolean matchesConstraint(IRelation objRange, Concept concept);
    String toAttributeString(Concept concept, ObjRelationData objRelationData, String latticeName);


}
