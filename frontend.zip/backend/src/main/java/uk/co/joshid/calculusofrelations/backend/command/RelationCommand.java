package uk.co.joshid.calculusofrelations.backend.command;

import lombok.Data;

@Data
public class RelationCommand {
    private final char symbol;
    private final String name;
    private final String sourceData;
    private final String targetData;
    private final boolean generateRelation;
    private Double density;
    private String relationData;
}
