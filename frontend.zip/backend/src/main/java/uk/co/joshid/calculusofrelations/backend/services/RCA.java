package uk.co.joshid.calculusofrelations.backend.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.joshid.calculusofrelations.backend.command.RCACommand;
import uk.co.joshid.calculusofrelations.backend.exception.RelationNotFound;
import uk.co.joshid.calculusofrelations.backend.graphviz.GraphViz;
import uk.co.joshid.calculusofrelations.backend.model.Relation;
import uk.co.joshid.calculusofrelations.backend.processing.nonmatrix.IRelation;
import uk.co.joshid.calculusofrelations.backend.repository.PosetRepository;
import uk.co.joshid.calculusofrelations.backend.repository.RelationRepository;
import uk.co.joshid.calculusofrelations.backend.repository.SessionRepository;
import uk.co.joshid.calculusofrelations.backend.response.RCAResponse;
import uk.co.joshid.calculusofrelations.backend.services.rca.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RCA {
    private final RelationRepository relationRepository;
    private final SessionRepository sessionRepository;

    private final PosetRepository posetRepository;

    private final PosetBuilder posetBuilder;

    public RCAResponse execute(RCACommand rcaCommand) throws IOException {
        HashMap<IRelation, ObjRelationData> objToObjRelations = new HashMap<>();
        List<ContextAndPoset> contexts = new ArrayList<>();
        for (int id : rcaCommand.getContexts()) {
            Relation relation = relationRepository.findById(id).orElseThrow(RelationNotFound::new);
            IRelation context = relation.getRelation();
            String name = relation.getRelationInfo().getName();
            contexts.add(new ContextAndPoset(context, context, posetBuilder.execute(context, name), name, 0));
        }

        List<Integer> toObjRelations = rcaCommand.getObjToObjRelations();
        for (int i = 0; i < toObjRelations.size(); i++) {
            int id = toObjRelations.get(i);
            ScalingOperator scalingOperator = switch (rcaCommand.getScalingOperators().get(i)) {
                case EXISTENTIAL -> new ExistentialOperator();
                case UNIVERSAL_STRICT -> new UniversalStrictOperator();
            };
            Relation relation = relationRepository.findById(id).orElseThrow(RelationNotFound::new);
            objToObjRelations.put(relation.getRelation(), new ObjRelationData(scalingOperator, relation.getRelationInfo().getName()));
        }

        ContextEnvironment contextEnvironment = new ContextEnvironment(contexts, objToObjRelations, posetBuilder);
        List<List<ContextAndPoset>> results = contextEnvironment.execute(rcaCommand.isPerformLabelReduction(), sessionRepository.getSessionData().getRelationType());
        List<RCAResult> response = new ArrayList<>();
        int stepNum = 0;
        for (List<ContextAndPoset> step : results) {
            for (ContextAndPoset context : step) {
                String xml = posetBuilder.buildXML(context.poset());
                String dot = posetBuilder.buildDot(context.poset(), true);
                GraphViz gv = new GraphViz();
                gv.add(dot);
                String type = "png";
                File out = new File("E^" + context.step() + "(" + context.name() + ")." + type);
                gv.writeGraphToFile(gv.getGraph(gv.getDotSource(), type, "dot"), out);
                byte[] bytes = Files.readAllBytes(out.toPath());
                int posetId = posetRepository.save(bytes);
                response.add(new RCAResult(context.name(), stepNum, xml, posetId));
            }
            stepNum++;
//            xmlRepository.save(relationId, xml);
//            return Files.readAllBytes(out.toPath());
        }
        return new RCAResponse(response);

    }
}
